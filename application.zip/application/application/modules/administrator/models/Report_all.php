<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* * *****************Report.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : Report
 * @description     : Manage all reports of the system.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

 class Report_all extends My_Controller {

    public function __construct() {
        parent::__construct();
        if($this->session->userdata('role_id') != SUPER_ADMIN){
            $school_id = $this->session->userdata('school_id');
       }
        $this->load->model('Report_all_Model', 'report_model', true);
      
    }

    public function index() {
        echo "<pre>";
        print_r($this->session);die;
        $g_id = $this->session->userdata('profile_id');
    
        if ($g_id) {
            $data['list_student'] = $this->report_model->get_student_g_id($g_id);
        }
    
        $selected_student_id = $this->input->post('student_id');
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($this->input->post('student_id')) {
                // die;
                $this->session->unset_userdata('G_student_id');                
                $this->session->set_userdata('G_student_id',$this->input->post('student_id')); 


                // $this->session->unset_userdata('G_student_id');                
                // $this->session->set_userdata('G_student_id',$this->input->post('student_id')); 

                $student_id = $this->input->post('student_id');
                $data_r = $this->report_model->get_student_data($student_id);
    
                if (!empty($data_r)) {
                    $class_id = $data_r[0]->class_id;
                    $school_id = $data_r[0]->school_id;
                    $subject_id = $data_r[0]->subject_id;
                    $student_user_id= $this->report_model->get_single('students', array('id' => $student_id));
    
                    $subjects = $this->report_model->get_subjects_by_class($class_id, $student_user_id->user_id);
    
                    // Calculate the total number of chakras
                    $totalChakras = 0;
                    foreach ($subjects as $subject) {
                        $totalChakras += $subject->chakra_count;
                    }
    
                    $data['subjects'] = $subjects;
                    $data['totalChakras'] = $totalChakras;
                    $data['selected_student_id'] = $selected_student_id;
                } 
            } else {
                $dataFilter['school_id'] = $this->input->post('school_id');
                $dataFilter['class_id'] = $this->input->post('class_id');
            }
    
            if ($this->session->userdata('role_id') == STUDENT) {
                $dataFilter['school_id'] = $this->session->userdata('school_id');
                $dataFilter['class_id'] = $this->session->userdata('class_id');
                $dataFilter['student_id'] = $this->session->userdata('id');
            }
        }
    
        $this->data['list'] = TRUE;
        $data['school_list'] = $this->report_model->get_school();
        $data['course_results'] = $this->report_model->report($dataFilter);
    
        // Load the view with the data
        $this->layout->title($this->lang->line('manage_report') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $data);
    }
    
    public function get_class($id) {
        $class_list = $this->report_model->get_class($id);
        echo json_encode($class_list);
    }
    

    public function get_students($id) {
        $class_list = $this->report_model->get_students($id);
        echo json_encode($students_list);
    }

    public function chakras($subject_id) {
        // print_r('nfjn');die;
         $school_id = $this->session->userdata('school_id');
         $student_id = $this->session->userdata('G_student_id');
         $student_user_data= $this->report_model->get_single('students', array('id' => $student_id));
         $student_user_id = $student_user_data->user_id;
        $chakras = $this->report_model->get_chakras_list($subject_id, $school_id,$student_user_id);       
        // echo"<pre>";
        // print_r($chakras);
        // die;
        
    
        if (!empty($chakras)) {
            $data['chakras'] = $chakras;
        } else {
            $data['chakras'] = array(); 
        }
    
        $this->layout->title($this->lang->line('chakras_title') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $data);
    }
    public function getChakras($subject_id){
       
         $school_id = $this->session->userdata('school_id');
         $student_id = $this->session->userdata('G_student_id');
         $student_user_data= $this->report_model->get_single('students', array('id' => $student_id));
         $student_user_id = $student_user_data->user_id;
         $chakras = $this->report_model->get_chakras_list($subject_id, $school_id,$student_user_id);       
        // echo"<pre>";
        // print_r($chakras);
        // die;
        
    
        if (!empty($chakras)) {
            $data['chakras'] = $chakras;
        }
        // echo "<pre>";
        // print_r($data);
        //     die;
        $this->layout->title($this->lang->line('chakras_title') . ' | ' . SMS);
        $this->load->view('administrator/report_all/index', $data);
    }
    
    public function chakra_details($chakra_id) {
        $chakra = $this->report_model->get_chakra_details($chakra_id);
    
        if (!empty($chakra)) {
            $this->layout->title($chakra->course_name . ' Details | ' . SMS);
            $this->layout->view('administrator/report_all/chakra_details', ['chakra' => $chakra]);
        } else {
            // Chakra details not found, show an error message or redirect
            // Redirect or show an error message
            redirect(site_url('administrator/report_all'));
        }
    }

    public function student_progress($student_id)
    {
        // echo "<pre>";
        // print_r($this->session);die;

        $this->session->unset_userdata('G_student_id');                
        $this->session->set_userdata('G_student_id',$this->input->post('student_id'));
        $g_id = $this->session->userdata('profile_id');

        if ($g_id) {
            $data['list_student'] = $this->report_model->get_student_g_id($g_id);
        }

        // echo "<pre>";
        // print_r( $data['list_student']);die;

        $selected_student_id = $student_id;


        // print_r("kjhkjh");die;

        if ($selected_student_id) {
            $student_id = $student_id;
            // print_r($student_id);die;

            $data_r = $this->report_model->get_student_data($student_id);

            if (!empty($data_r)) {
                // print_r($data_r);die;
                $class_id = $data_r[0]->class_id;
                $school_id = $data_r[0]->school_id;
                $subject_id = $data_r[0]->subject_id;
                $student_user_id = $this->report_model->get_single('students', array('id' => $student_id));


                $subjects = $this->report_model->get_subjects_by_class($class_id, $student_user_id->user_id);
                // echo "<pre>";
                // print_r($subjects);
                // exit();
                $this->data['subjects'] = $subjects;
                $data['selected_student_id'] = $selected_student_id;
            }
        } else {
            // $dataFilter['school_id'] = $this->input->post('school_id');
            // $dataFilter['class_id'] = $this->input->post('class_id');
        }

        if ($this->session->userdata('role_id') == STUDENT) {
            $dataFilter['school_id'] = $this->session->userdata('school_id');
            $dataFilter['class_id'] = $this->session->userdata('class_id');
            $dataFilter['student_id'] = $this->session->userdata('id');
        }


        $this->data['list'] = TRUE;
        $data['school_list'] = $this->report_model->get_school();
        $data['course_results'] = $this->report_model->report($dataFilter);
        // echo "<pre>";
        // print_r($data);
        // die;

        // Load the view with the data
        $this->data['new_progress'] = TRUE;
        $this->layout->title($this->lang->line('manage_report') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $this->data);
    }

    public function get_result($result_id)
    {
        // print_r($result_id);
        // die;
        $this->data['result_details'] = TRUE;
        $row = $this->report_model->get_result($result_id);
        echo "<pre>";
        print_r($row->student_id);
        die;
        if (!empty($row)) {
            $table = '
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                       <tr>
                            <td>Quiz Name</td>
                            <td>' . $row->quiz_name . '</td>
                       </tr>
                        <tr>
                            <td>Score</td>
                            <td>' . $row->score . '</td>
                        </tr>

                        <tr>
                            <td>Passing Score</td>
                            <td>' . $row->passing_score . '</td>
                        </tr>


                        <tr>
                            <td>Total Questions</td>
                            <td>' . $row->total_q . '</td>
                        </tr>


                        <tr>
                            <td>Incorrect Questions</td>
                            <td>' . $row->incorrect_q . '</td>
                        </tr>

                        <tr>
                        <td>Correct Questions</td>
                        <td>' . $row->correct_q . '</td>
                        </tr>
                    
                    </table>
                ';

            echo $table;
        } else {
            echo '<h3>No Data Found</h3>';
        }
    }

    // public function get_subjects($subject_id)
    // {
    //     //  print_r($_GET['student_id']);
    //     //  exit;=

    //     $student_id = $_GET['student_id'];
    //     $data_r = $this->report_model->get_student_data($student_id);

    //     if (!empty($data_r)) {
    //         // print_r($data_r);die;
    //         $class_id = $data_r[0]->class_id;
    //         $school_id = $data_r[0]->school_id;
    //         $subject_id = $data_r[0]->subject_id;
    //         $student_user_id = $this->report_model->get_single('students', array('id' => $student_id));


    //         $subjects = $this->report_model->get_subjects_by_class($class_id, $student_user_id->user_id);
    //         // echo "<pre>";
    //         // print_r($subjects);
    //         // exit();

    //         $val = '';
    //         foreach ($subjects as $sub) {
    //             $unit_name = $sub->unit_title;
    //             $total=$sub->chakra_count;
    //             $completed=$sub->chakra_count_complete;
    //             $progress = $completed/$total*100;
                
    //             if($progress==100 || $progress>100){
    //                 $status='completed';
    //             }else if($progress>50 || $progress==50){
    //                 $status='In Process';
    //             }else{
    //                 $status='In-completed';
    //             }
    //             $val .= '<li>
    //             <div class="itemWrap completed">
    //                 <div class="topData">
    //                     <h2>'.$unit_name.'</h2>
    //                     <h4>'.$status.'</h4>
    //                 </div>
    //                 <div class="middleData">
    //                     <h3><span>'.$completed.' / '.$total.' </span> <br /> Chakras</h3>
    //                     <div class="progress">
    //                         <div class="progress-bar" role="progressbar" aria-valuenow="'.$progress.'" aria-valuemin="0" aria-valuemax="7" style="max-width:100%">
    //                         </div>
    //                     </div>
    //                 </div>
    //                 <div class="btmData">
    //                     <a href="#">View Chakras</a>
    //                 </div>
    //             </div>
    //         </li>';
    //         }
    //         echo $val;
    //        // $this->data['subjects'] = $subjects;
    //     }
    // }

    
}