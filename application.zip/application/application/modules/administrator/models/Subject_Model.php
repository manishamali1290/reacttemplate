<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Subject_Model extends MY_Model
{

    public function __construct()
    {
        parent::__construct();
    }
    public function get_satate_list()
    {
        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();
    }
    public function get_subjects_new_list()
    {
        $this->db->select('m_state.title AS state_title, m_grade.title AS grade_title, m_board.title AS board_title, m_course.title AS course_title, m_section.title AS section_title, m_subject.*');
        $this->db->from('m_subject');
        $this->db->join('m_state', 'm_subject.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_subject.board_id = m_board.id', 'left');
        $this->db->join('m_course', 'm_subject.course_id = m_course.id', 'left');
        $this->db->join('m_grade', 'm_subject.grade_id = m_grade.id', 'left');
        $this->db->join('m_section', 'm_subject.section_id = m_section.id', 'left');
        return $this->db->get()->result();
    }

    public function insert_data($data)
    {

        $this->db->insert('m_subject', $data);
        return $this->db->insert_id();
    }
    public function delete_data($id)
    {

        $this->db->where('id', $id);
        $this->db->delete('m_subject');
        return $this->db->delete();
    }
    public function update_data($data)
    {
        $this->db->where('id', $data['id']);
        $this->db->update('m_subject', $data);
        return $this->db->affected_rows();
    }
}