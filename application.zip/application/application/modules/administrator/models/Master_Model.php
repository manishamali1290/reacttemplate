<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Master_Model extends MY_Model
{

    function __construct()
    {
        parent::__construct();
    }



    public function get_satate_list()
    {

        $this->db->select('*');
        $this->db->from('m_state');
        $this->db->where('status', 1);
        return $this->db->get()->result();
    }
    public function get_board_list_by_state_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_board');
        $this->db->where('state_id', $id);
        return $this->db->get()->result();
    }
    public function get_grade_list_by_course_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_grade');
        $this->db->where('course_id', $id);
        return $this->db->get()->result();
    }
    public function get_course_list_by_board_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_course');
        $this->db->where('board_id', $id);
        $this->db->where('status', 1);
        return $this->db->get()->result();
    }
    public function get_sections_by_grade_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_section');
        $this->db->where('grade_id', $id);
        // echo"<pre>"; print_r($this->db->get()->result()); die;
        return $this->db->get()->result();

      
    }

    public function get_subject_by_section_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_subject');
        $this->db->where('section_id', $id);
        return $this->db->get()->result();
    }
    public function get_volume_by_subject_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_volume');
        $this->db->where('subject_id', $id);
        return $this->db->get()->result();
    }
    public function get_unit_by_volume_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_unit');
        $this->db->where('volume_id', $id);
        return $this->db->get()->result();
    }
    public function get_lesson_by_unit_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_lessons');
        $this->db->where('unit_id', $id);
        return $this->db->get()->result();
    }
    public function get_cakra_by_lesson_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_chakra');
        $this->db->where('lessons_id', $id);
        return $this->db->get()->result();
    }




    public function insert_data($data)
    {

        $this->db->insert('m_state', $data);
        return $this->db->insert_id();
    }
    public function delete_data($id)
    {

        $data = array(
            'status' => 0,
        );

        $this->db->where('id', $id);
        $this->db->update('m_state', $data);
        return $this->db->affected_rows();

        // $this->db->where('id', $id);
        // $this->db->delete('m_state');
        // return $this->db->delete();
    }
    public function update_data($data)
    {
        $this->db->where('id', $data['id']);
        $this->db->update('m_state', $data);
        return $this->db->affected_rows();
    }
}
