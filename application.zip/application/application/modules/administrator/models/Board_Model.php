<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Board_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    
 
    
    public function get_satate_list() {

        $this->db->select('*');
        $this->db->from('m_state');
        $this->db->where('status',1);
        return $this->db->get()->result();
        
    } 
    public function get_board_list() {

        $this->db->select('m_state.title AS state_title, m_board.*');
        $this->db->from('m_board');
        $this->db->join('m_state', 'm_board.state_id = m_state.id', 'left');
        $this->db->where('m_board.status',1);
        return $this->db->get()->result();
        
    }
  
    public function insert_data($data){
        
        $this->db->insert('m_board',$data);
        return $this->db->insert_id();
    } 
    public function delete_data($id){
        

        $data = array(
            'status' => 0,
        );

        $this->db->where('id', $id);
        $this->db->update('m_board', $data);
        return $this->db->affected_rows();


        // $this->db->where('id', $id);
        // $this->db->delete('m_board');
        // return $this->db->delete();
    }
    public function update_data($data) {
        $this->db->where('id', $data['id']);
        $this->db->update('m_board', $data);
        return $this->db->affected_rows();
    }
}
