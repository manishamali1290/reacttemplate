<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lessons_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    
    public function get_satate_list() {

        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();
        
    }    
    
    public function get_lessons_list() {
        $this->db->select('m_state.title AS state_title,m_course.title AS course_title,  m_grade.title AS grade_title, m_board.title AS board_title, m_section.title AS section_title, m_subject.title AS subject_title, m_volume.title AS volume_title,m_unit.title AS  unit_title, m_lessons.*');
        $this->db->from('m_lessons');
        $this->db->join('m_state', 'm_lessons.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_lessons.board_id = m_board.id', 'left');
        $this->db->join('m_course', 'm_lessons.course_id = m_course.id', 'left');
        $this->db->join('m_grade', 'm_lessons.grade_id = m_grade.id', 'left');
        $this->db->join('m_section', 'm_lessons.section_id = m_section.id', 'left');
        $this->db->join('m_subject', 'm_lessons.subject_id = m_subject.id', 'left');
        $this->db->join('m_volume', 'm_lessons.volume_id = m_volume.id', 'left');
        $this->db->join('m_unit', 'm_lessons.unit_id = m_unit.id', 'left');
        return $this->db->get()->result();
        
    }
  
    public function insert_data($data){
        $this->db->insert('m_lessons',$data);
        return $this->db->insert_id();
    } 
    public function delete_data($id){
        
        $this->db->where('id', $id);
        $this->db->delete('m_lessons');
        return $this->db->delete();
    }
    public function update_data($data) {
       
        $this->db->where('id', $data['id']);
        $this->db->update('m_lessons', $data);
        return $this->db->affected_rows();
    }
}
