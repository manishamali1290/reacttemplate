<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Usercourse_Model extends MY_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_course_list_user()
    {
//  print
        $School_id = $this->session->userdata('school_id');
        $grade_id = $this->session->userdata('grade_id');

        
        $this->db->select('m_course_relation.*,m_subject.title AS _name,m_subject.description AS _description ');
        $this->db->from('m_course_relation');
        $this->db->where('m_course_relation.School_id', $School_id);
        $this->db->where('m_course_relation.grade_id', $grade_id);
        $this->db->group_by('m_course_relation.subject_id');
        $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
        $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
        $this->db->where('m_course_relation.deleted_by_admin', 1);
        $this->db->where('m_course_relation.status', 1);
        $this->db->where('m_subject.status', 1);
        $this->db->where('m_course.status', 1);
        
        // echo "<pre>";
        // print_r($this->db->get()->result());
        // die();
        return $this->db->get()->result();
    }
    public function get_volume_list_user($id = null)
    {

        if ($id) {
            $School_id = $this->session->userdata('school_id');
            $grade_id = $this->session->userdata('grade_id');


            $this->db->select('m_course_relation.*, m_volume.title AS _name, m_volume.description AS _description');
            $this->db->from('m_course_relation');
            $this->db->where('m_course_relation.School_id', $School_id);
            $this->db->where('m_course_relation.grade_id', $grade_id);
            $this->db->group_by('m_course_relation.volume_id');
            $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
            $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
            $this->db->where('m_course_relation.deleted_by_admin', 1);
            $this->db->where('m_course_relation.status', 1);
            $this->db->where('m_subject.status', 1);
            $this->db->where('m_volume.status', 1);
            $this->db->where('m_course.status', 1);
            $this->db->where('m_course_relation.subject_id', $id);

            return $this->db->get()->result();
        }
    }

    public function get_unit_list_user($id = null)
    {
        // echo "kkk<pre>";
        // print_r($this->session);
        //     die();  
        if ($id) {
            $School_id = $this->session->userdata('school_id');
            $grade_id = $this->session->userdata('grade_id');


            $this->db->select('m_course_relation.*, m_unit.title AS _name, m_unit.description AS _description,  COUNT(m_course_result.id) as result_count, COUNT(m_course_relation.id) AS total_chakra');
            $this->db->from('m_course_relation');
            $this->db->where('m_course_relation.School_id', $School_id);
            $this->db->where('m_course_relation.grade_id', $grade_id);

            // $this->db->group_by('m_course_relation.unit_id');  
              $student_id = $_SESSION['user_id'];
              
            $this->db->join('m_course_result', 'm_course_result.chakra_id = m_course_relation.chakra_id and m_course_result.student_id='.$student_id, 'left');
       
            $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
            $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
            $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');

            $this->db->where('m_course_relation.deleted_by_admin', 1);
            $this->db->where('m_course_relation.status', 1);
            $this->db->where('m_course.status', 1);
            $this->db->where('m_subject.status', 1);
            $this->db->where('m_volume.status', 1);
            $this->db->where('m_unit.status', 1);
            $this->db->where('m_course_relation.volume_id', $id);
            // echo "<pre>";
            // print_r($this->db->get()->result());

            return $this->db->get()->result();
        }
    }

    public function get_lessons_list_user($id = null)
    {

        if ($id) {
            $School_id = $this->session->userdata('school_id');
            $grade_id = $this->session->userdata('grade_id');


            $this->db->select('m_course_relation.*, m_lessons.title AS _name, m_lessons.description AS _description');
            $this->db->from('m_course_relation');
            $this->db->where('m_course_relation.School_id', $School_id);
            $this->db->where('m_course_relation.grade_id', $grade_id);

            $this->db->group_by('m_course_relation.unit_id');

            $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
            $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
            $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');
            $this->db->join('m_lessons', 'm_course_relation.lessons_id = m_lessons.id', 'left');

            $this->db->where('m_course_relation.deleted_by_admin', 1);
            // $this->db->where('m_course_relation.status', 1);
            $this->db->where('m_course.status', 1);
            $this->db->where('m_subject.status', 1);
            $this->db->where('m_volume.status', 1);
            $this->db->where('m_unit.status', 1);
            $this->db->where('m_lessons.status', 1);
            $this->db->where('m_course_relation.unit_id', $id);

            return $this->db->get()->result();
        }
    }

    public function todays_chakras()
    {

        $School_id = $this->session->userdata('school_id');
        $grade_id = $this->session->userdata('grade_id');
// echo "kkk<pre>";
//         print_r($this->session);
//             die(); 

        $this->db->select('m_course_relation.*, m_chakra.title AS _name, m_chakra.description AS _description');
        $this->db->from('m_course_relation');
        $this->db->where('m_course_relation.School_id', $School_id);
        $this->db->where('m_course_relation.grade_id', $grade_id);


        $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
        $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
        $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
        $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');
        $this->db->join('m_lessons', 'm_course_relation.lessons_id = m_lessons.id', 'left');
        $this->db->join('m_chakra', 'm_course_relation.chakra_id = m_chakra.id', 'left');

        $this->db->where('m_course_relation.deleted_by_admin', 1);
        $this->db->where('m_course_relation.status', 1);
        $this->db->where('m_course.status', 1);
        $this->db->where('m_subject.status', 1);
        $this->db->where('m_volume.status', 1);
        $this->db->where('m_unit.status', 1);
        $this->db->where('m_lessons.status', 1);
        $this->db->where('m_chakra.status', 1);
        $this->db->where('WEEK(m_course_relation.created_at) = WEEK(NOW())', null, false);


        return $this->db->get()->result();
    }

    public function get_chakra_list_user($id = null)
    {
        if ($id) {
            $School_id = $this->session->userdata('school_id');
            $grade_id = $this->session->userdata('grade_id');


            $this->db->select('m_course_relation.*, m_chakra.title AS _name, m_chakra.description AS _description');
            $this->db->from('m_course_relation');
            $this->db->where('m_course_relation.School_id', $School_id);
            $this->db->where('m_course_relation.grade_id', $grade_id);


            $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
            $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
            $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');
            $this->db->join('m_lessons', 'm_course_relation.lessons_id = m_lessons.id', 'left');
            $this->db->join('m_chakra', 'm_course_relation.chakra_id = m_chakra.id', 'left');

            $this->db->where('m_course_relation.deleted_by_admin', 1);
            // $this->db->where('m_course_relation.status', 1);
            $this->db->where('m_course.status', 1);
            $this->db->where('m_subject.status', 1);
            $this->db->where('m_volume.status', 1);
            $this->db->where('m_unit.status', 1);
            $this->db->where('m_lessons.status', 1);
            $this->db->where('m_chakra.status', 1);
            $this->db->where('m_course_relation.lessons_id', $id);
            

            // echo "kk<pre>";
            // //     // print_r($data);
            //     print_r($this->db->get()->result());
            //         die(); 
            return $this->db->get()->result();
        }
    }
    public function save_result($data)
    {
        // echo "kk<pre>";
        //         print_r($data);
        //         // print_r($this->data);
        //             die(); 
        $this->db->insert('m_course_result', $data);
        return $this->db->insert_id();
    }
    public function get_sub_id($id, $school_id){
        $this->db->select('id');
        $this->db->from('subjects');
        $this->db->where('school_id', $school_id);
        $this->db->where('m_subjects_id', $id);
        return $this->db->get()->row('id');
    }
     public function get_today_chackra_list_user(){
        //  echo "<pre>";
        //  print_r($this->session);
        $School_id = $this->session->userdata('school_id');
        $grade_id = $this->session->userdata('grade_id');
        $currentDate = date('Y-m-d');


        $this->db->select('m_course_relation.*, m_chakra.title AS name, m_chakra.description AS description,m_subject.title as subjectName');
        $this->db->from('m_course_relation');
        $this->db->where('m_course_relation.School_id', $School_id);
        $this->db->where('m_course_relation.grade_id', $grade_id);
        $this->db->where('DATE(m_course_relation.active_time)', $currentDate);

        $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
        $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
        $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
        $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');
        $this->db->join('m_lessons', 'm_course_relation.lessons_id = m_lessons.id', 'left');
        $this->db->join('m_chakra', 'm_course_relation.chakra_id = m_chakra.id', 'left');

        $this->db->where('m_course_relation.deleted_by_admin', 1);
        $this->db->where('m_course.status', 1);
        $this->db->where('m_subject.status', 1);
        $this->db->where('m_volume.status', 1);
        $this->db->where('m_unit.status', 1);
        $this->db->where('m_lessons.status', 1);
        $this->db->where('m_chakra.status', 1);
      
        return $this->db->get()->result();

    }
      public function get_total_chackra_list_user(){
        //  echo "<pre>";
        //  print_r($this->session);
        $School_id = $this->session->userdata('school_id');
        $grade_id = $this->session->userdata('grade_id');
        $currentDate = date('Y-m-d');


        $this->db->select('m_course_relation.*, m_chakra.title AS name, m_chakra.description AS description,m_subject.title as subjectName');
        $this->db->from('m_course_relation');
        $this->db->where('m_course_relation.School_id', $School_id);
        $this->db->where('m_course_relation.grade_id', $grade_id);
        // $this->db->where('DATE(m_course_relation.active_time)', $currentDate);

        $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
        $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
        $this->db->join('m_volume', 'm_course_relation.volume_id = m_volume.id', 'left');
        $this->db->join('m_unit', 'm_course_relation.unit_id = m_unit.id', 'left');
        $this->db->join('m_lessons', 'm_course_relation.lessons_id = m_lessons.id', 'left');
        $this->db->join('m_chakra', 'm_course_relation.chakra_id = m_chakra.id', 'left');

        $this->db->where('m_course_relation.deleted_by_admin', 1);
        $this->db->where('m_course.status', 1);
        $this->db->where('m_subject.status', 1);
        $this->db->where('m_volume.status', 1);
        $this->db->where('m_unit.status', 1);
        $this->db->where('m_lessons.status', 1);
        $this->db->where('m_chakra.status', 1);
      
        return $this->db->get()->result();

    }
    
}
