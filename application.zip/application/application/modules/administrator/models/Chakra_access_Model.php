<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class chakra_access_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    

    
    public function get_satate_list() {

        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();        
    }
    public function get_course_list($id) {
        $this->db->select('m_course.*, m_grade.title AS grade_title');
        $this->db->from('m_course'); 
        $this->db->join('m_grade', 'm_course.id = m_grade.course_id');       
        $this->db->where_in($id);
        return $this->db->get()->result();
    }
     
    public function get_course_by_grade_id($id) {
        // print_r($id);
        //     die();        
      
        $this->db->select('*');
        $this->db->from('m_course');
        $this->db->where_in($id);
        //$this->db->where('status', 1);
        return $this->db->get()->result();  
        
        
    } 
    public function get_single_course_file($id) {
        $this->db->select('*');
        $this->db->from('m_course_file');
        $this->db->where('course_id', $id);
        return $this->db->get()->result();        
    }
    
  
    
    
    public function insert_data($data){
        
        $this->db->insert('m_course',$data);
        return $this->db->insert_id();
    } 

    public function insert_course_file($data){
        
        $this->db->insert('m_course_file',$data);
        return $this->db->insert_id();
    } 
    public function delete_data($id){
        
        $this->db->where('id', $id);
        $this->db->delete('m_course');
        return $this->db->delete();
    }
    public function delete_data_file($id) {
        $file_url = $this->db->get_where('m_course_file', ['id' => $id])->row('path');    
        $this->db->where('id', $id);
        $this->db->delete('m_course_file');
        if ($this->db->affected_rows() > 0) {
           // $base_path = '/path/to/your/files/';
           //$full_path = $base_path . $file_url;

           $full_path = $file_url;

            if (file_exists($full_path)) {
        //         print_r($full_path);
        //    die();
                unlink($full_path);
            }
    
            return true; 
        }
    
        return false; 
    }
    public function update_data($data) {
//         print_r($data);
//         print_r($id);
// die();
        
        $this->db->where('id', $data['id']);
        $this->db->update('m_course', $data);
        return $this->db->affected_rows();
    }
    
    public function get_chakra_modal($id) {
        try {
            print_r("jkhsdvjk");
            print_r($id);
    die();
            $this->db->select('*');
            $this->db->from('m_course_relation');
            $this->db->where('school_id', $this->session->userdata('school_id'));
            $this->db->where('course_id', $id);
            $this->db->where('deleted_by_admin', 1);            
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');//
            // $this->db->join('m_subject', 'm_course_relation.subject_id = m_subject.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            // $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            return $this->db->get()->result();

        } catch (Exception $e) {
           
            log_message('error', 'Database error: ' . $e->getMessage());
            return false; // or handle the error in another way
        }
        
            }
            
            public function get_course_by_id($id) {
                        print_r("jkhsdvjk");
                        print_r($id);
                die();
                $this->db->select('*');
                $this->db->from('m_course_relation');
                $this->db->where('id', $id);
                return $this->db->get()->result();  

            //     $this->db->select('m_course_relation.*,m_course.*');
            //     $this->db->from('m_course_relation');
            //     $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
            //     $this->db->where('m_course_relation.id', $id);
            //    // $this->db->where('m_course_relation.deleted_by_admin', 1);
            //     $this->db->where('m_course.states', 1); 
                return $this->db->get()->result();  
                      
                    } 
            public function get_course_modal_by_shhool($id) {
                //  print_r($data);
        //           print_r($id);
        //   die();  
          $this->db->select(' m_grade.title AS grade_title,m_course.status,m_course_relation.*');
          $this->db->from('m_course_relation');
          $this->db->join('m_grade', 'm_course_relation.grade_id = m_grade.id', 'left');
          $this->db->join('m_course', 'm_course_relation.course_id = m_course.id', 'left');
          $this->db->where('m_course_relation.school_id', $id);
          $this->db->where('m_course_relation.deleted_by_admin', 1);
          $this->db->where('m_course.status', 1);
          return $this->db->get()->result();   
                
              } 
    public function get_course_relation_list($id) {
                //         print_r($data);
                //         print_r($id);
                // die();
                $this->db->select('*');
                $this->db->from('m_course_relation');
                $this->db->where('school_id', $id);
                return $this->db->get()->result();   
                      
                    }
                    
                    public function update_course_by_school($data) {
                        //         print_r($data);
                        //         print_r($data);
                        // die();
                        $this->db->where('id', $data['id']);
                        $this->db->update('m_course_relation', $data);
                        return $this->db->affected_rows(); 
                              
                }
                
                public function get_chakra_modal_list($id) {
                    print_r("jjjj");
                    print_r($id);
            die();
            $this->db->select('*');
            $this->db->from('m_course_relation');
            $this->db->where('course_id', $id);
            return $this->db->get()->result(); 
                  
    }
                
                public function get_list_chakra($id) {
                    print_r("jjjj");
                    print_r($id);
            die();
            $this->db->select('*');
            $this->db->from('m_course_relation');
            $this->db->where('course_id', $id);
            return $this->db->get()->result(); 
                  
    }
                public function get_single_course($id) {
        
       
                    $this->db->select('m_state.title AS state_title,  m_grade.title AS grade_title, m_board.title AS board_title, m_section.title AS section_title, m_subject.title AS subject_title, m_volume.title AS volume_title,m_unit.title AS  unit_title, m_lessons.title AS  lessons_title, m_chakra.title AS  chakra_title, m_course.*');
                    $this->db->from('m_course');
                    $this->db->join('m_state', 'm_course.state_id = m_state.id', 'left');
                    $this->db->join('m_board', 'm_course.board_id = m_board.id', 'left');
                    $this->db->join('m_grade', 'm_course.grade_id = m_grade.id', 'left');
                    $this->db->join('m_section', 'm_course.section_id = m_section.id', 'left');
                    $this->db->join('m_subject', 'm_course.subject_id = m_subject.id', 'left');
                    $this->db->join('m_volume', 'm_course.volume_id = m_volume.id', 'left');
                    $this->db->join('m_unit', 'm_course.unit_id = m_unit.id', 'left');
                    $this->db->join('m_lessons', 'm_course.lessons_id = m_lessons.id', 'left');
                    $this->db->join('m_chakra', 'm_course.chakra_id = m_chakra.id', 'left');
                    $this->db->where('m_course.id', $id);
                    return $this->db->get()->result();        
                } 
              
                
                
                  
}