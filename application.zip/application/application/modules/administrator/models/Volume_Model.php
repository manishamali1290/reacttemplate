<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Volume_Model extends MY_Model
{

    public function __construct()
    {
        parent::__construct();
    }
    public function get_satate_list()
    {

        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();

    }
    public function get_board_list_by_state_id($id)
    {

        $this->db->select('*');
        $this->db->from('m_board');
        $this->db->where('state_id', $id);
        return $this->db->get()->result();

    }

    public function get_grade_list_by_board_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_grade');
        $this->db->where('board_id', $id);
        return $this->db->get()->result();
    }

    public function get_sections_by_grade_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_section');
        $this->db->where('grade_id', $id);
        return $this->db->get()->result();
    }

    public function get_subject_by_sections_id($id)
    {
        $this->db->select('*');
        $this->db->from('m_subject');
        $this->db->where('section_id', $id);
        return $this->db->get()->result();
    }

    public function get_volumes_list()
    {
        $this->db->select('m_state.title AS state_title, m_grade.title AS grade_title, m_course.title AS course_title, m_board.title AS board_title, m_section.title AS section_title, m_subject.title as subject_title, m_volume.*');
        $this->db->from('m_volume');
        $this->db->join('m_state', 'm_volume.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_volume.board_id = m_board.id', 'left');
        $this->db->join('m_grade', 'm_volume.grade_id = m_grade.id', 'left');
        $this->db->join('m_course', 'm_volume.course_id = m_course.id', 'left');
        $this->db->join('m_section', 'm_volume.section_id = m_section.id', 'left');
        $this->db->join('m_subject', 'm_volume.subject_id = m_subject.id', 'left');
        return $this->db->get()->result();
    }

    public function insert_data($data)
    {

        $this->db->insert('m_volume', $data);
        return $this->db->insert_id();
    }
    public function delete_data($id)
    {

        $this->db->where('id', $id);
        $this->db->delete('m_volume');
        return $this->db->delete();
    }
    public function update_data($data)
    {
        $this->db->where('id', $data['id']);
        $this->db->update('m_volume', $data);
        return $this->db->affected_rows();
    }
}
