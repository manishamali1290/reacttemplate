<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

    class Report_all_Model extends MY_Model {
 
        function __construct() {
            parent::__construct();
        }
    
        public function report($data=null) {
            //     echo "<pre>";
            // print_r($this->session);
            // die;
            // $user_id = $this->session->userdata('user_id');
       
            $this->db->select('m_course_result.*, S.school_name as school_name, ST.name as student_name, C.name as class, m_chakra.title as chakreName, m_subject.title as subjectName');
            $this->db->from('m_course_result');
            $this->db->join('schools AS S', 'S.id = m_course_result.school_id', 'left');
            $this->db->join('students AS ST', 'ST.user_id = m_course_result.student_id', 'left');
            $this->db->join('classes AS C', 'C.id = m_course_result.class_id', 'left');
            $this->db->join('m_chakra', 'm_chakra.id = m_course_result.chakra_id', 'left');
            $this->db->join('m_subject', 'm_subject.id = m_course_result.subject_id', 'left');

            if($data){
   
                $this->db->where('m_course_result.school_id',$data['school_id']);
                $this->db->where('m_course_result.class_id',$data['class_id']);
                if($data['student_id']){
                $this->db->where('m_course_result.student_id',$data['student_id']);}

            //     echo "<pre>";
            // print_r( $this->db->get()->result());
            // die;

            }
            // echo "<pre>";
            // print_r( $this->db->get()->result());
            // die;

          
            return $this->db->get()->result();
        }
        public function get_school(){
            $this->db->select('*');
            $this->db->from('schools');
            $this->db->where('status', 1);
            return $this->db->get()->result();
        }
        public function get_class($id){
        //    print_r('hggdsk');die;
            $this->db->select('*');
            $this->db->from('classes');
            $this->db->where('school_id', $id);
            $this->db->where('status', 1);
            return $this->db->get()->result();
        }

        public function getChakras($id){
            //    print_r('hggdsk');die;
                $this->db->select('*');
                $this->db->from('classes');
                $this->db->where('school_id', $id);
                $this->db->where('status', 1);
                return $this->db->get()->result();
            }

       public function get_student_g_id($id){
            $this->db->select('*');
            $this->db->from('students');
            $this->db->where('guardian_id', $id);
            
            return $this->db->get()->result();
       }
       public function get_student_data($id){
        $this->db->select('school_id,class_id');
        $this->db->from('enrollments');
        $this->db->where('student_id', $id);        
        return $this->db->get()->result();

       }
       public function get_student_user_id($id){
        $this->db->select('user_id');
        $this->db->from('students');
        $this->db->where('id', $id);
        
        return $this->db->get()->result();
       }
       
       public function get_subjects_by_class($class_id, $student_id) {
        $this->db->select('subjects.*, COUNT(m_course_relation.subject_id) AS chakra_count, COUNT(DISTINCT m_course_result.id) AS chakra_count_complete');
        $this->db->from('subjects');
        $this->db->join('m_course_relation', 'm_course_relation.subject_id = subjects.id AND m_course_relation.school_id = subjects.school_id', 'left');
        $this->db->join('m_course_result', "m_course_result.subject_id = subjects.id AND m_course_result.student_id = '$student_id'", 'left');
        $this->db->where('subjects.class_id', $class_id);
        $this->db->group_by('subjects.id');
        // echo "<pre>";
        // print_r($this->db->get()->result());die;
        $result = $this->db->get()->result();
        return $result;
    }

    public function get_chakras_list($subject_id, $school_id,$student_id)
    {
            //   return $student_id;
        
        $this->db->select('m_course_relation.*, m_course_result.pt_score as result_pt, m_course_result.id as result_id ');
        $this->db->from('m_course_relation');
        $this->db->join('m_course_result', 'm_course_result.chakra_id = m_course_relation.chakra_id AND m_course_result.student_id = ' . $student_id, 'left');
        $this->db->where('m_course_relation.subject_id', $subject_id);
        $this->db->where('m_course_relation.school_id', $school_id);
        $this->db->group_by('m_course_relation.id'); 

        return $this->db->get()->result();
       
    }

}
    