<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Grade_Model extends MY_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_satate_list()
    {

        $this->db->select('*');
        $this->db->from('m_state');
        $this->db->where('status', 1);
        return $this->db->get()->result();
    }

    public function get_grade_list()
    {
        $this->db->select('m_state.title AS state_title, m_grade.*, m_board.title AS board_title, m_course.title AS course_title');
        $this->db->from('m_grade');
        $this->db->join('m_state', 'm_grade.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_grade.board_id = m_board.id', 'left');
        $this->db->join('m_course', 'm_grade.course_id = m_course.id', 'left');
        return $this->db->get()->result();
    }

    public function insert_data($data)
    {
        $this->db->select('*');
        $this->db->from('m_grade');
        $this->db->where('course_id', $data['course_id']);


        $gradeExist = $this->db->get()->result();


        if (count($gradeExist) > 0) {
            return 0;
        } else {
            $this->db->insert('m_grade', $data);
            return $this->db->insert_id();
        }
    }
    public function delete_data($id)
    {

        $this->db->where('id', $id);
        $this->db->delete('m_grade');
        return $this->db->delete();
    }
    public function update_data($data)
    {

        $this->db->where('id', $data['id']);
        $this->db->update('m_grade', $data);
        return $this->db->affected_rows();
    }
}
