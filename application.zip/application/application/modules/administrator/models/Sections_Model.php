<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sections_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    
    public function get_satate_list() {

        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();
        
    }    
    
    public function get_section_list() {
        $this->db->select('m_state.title AS state_title,  m_grade.title AS grade_title, m_board.title AS board_title, m_course.title AS course_title, m_section.*');
        $this->db->from('m_section');
        $this->db->join('m_state', 'm_section.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_section.board_id = m_board.id', 'left');
        $this->db->join('m_course', 'm_section.course_id = m_course.id', 'left');
        $this->db->join('m_grade', 'm_section.grade_id = m_grade.id', 'left');
        return $this->db->get()->result();
        
    }
  
    public function insert_data($data){
        $this->db->insert('m_section',$data);
        return $this->db->insert_id();
    } 
    public function delete_data($id){
        
        $this->db->where('id', $id);
        $this->db->delete('m_section');
        return $this->db->delete();
    }
    public function update_data($data) {
       
        $this->db->where('id', $data['id']);
        $this->db->update('m_section', $data);
        return $this->db->affected_rows();
    }
}
