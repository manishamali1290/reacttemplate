<style>
    .x_panel {
    position: relative;
    width: 100%;
    min-height: 100vh;
    margin-bottom: 10px;
    padding: 5px 17px;
    display: inline-block;
    background: #fff;
    border: 1px solid #E6E9ED;
    -webkit-column-break-inside: avoid;
    -moz-column-break-inside: avoid;
    column-break-inside: avoid;
    opacity: 1;
    transition: all .2s ease;
}
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small>
                        <?php echo $this->lang->line('manage_course'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content quick-link">
                <?php $this->load->view('quick-link');?>
            </div>

            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">

                    <ul class="nav nav-tabs bordered">
                        <?php if (has_permission(VIEW, 'master', 'course')) {?>
                        <?php if (isset($list_chakra)) {?>
                        <li class=""><a href="<?php echo site_url('administrator/course_access/index'); ?>"
                                aria-expanded="false"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php } else {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?> "><a href="#tab_school_list" role="tab"
                                data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php }}?>

                        <?php if (has_permission(ADD, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <!-- <li  class="<?php if (isset($add)) {echo 'active';}?>"><a href="<?php echo site_url('administrator/course_access/index/#tab_add_state'); ?>"  aria-expanded="false"><i class="fa fa-refresh"></i> Syn Course</a> </li>                           -->
                        <?php } else {?>
                        <li class="<?php if (isset($add)) {echo 'active';}?>"><a href="#tab_add_state" role="tab"
                                data-toggle="tab" aria-expanded="false"><i class="fa fa-refresh"></i> Synchronous
                                Course</a> </li>
                        <?php }?>
                        <?php }?>

                        <?php if (has_permission(EDIT, 'master', 'course')) {?>
                        <?php if (isset($list_chakra)) {?>
                        <li class="active"><a href="#tab_chakra" role="tab" data-toggle="tab" aria-expanded="false"><i
                                    class="fa fa-pencil-square-o"></i>
                                Chakra List </a> </li>
                        <?php }
}?>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_school_list">

                            <div class="x_content">
                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('name'); ?></th>
                                            <th><?php echo $this->lang->line('description'); ?></th>
                                            <th><?php echo $this->lang->line('class'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1; if(isset($courses_list) && !empty($courses_list)){ ?>
                                        <?php foreach($courses_list as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->title; ?></td>
                                            <td><?php echo $obj->description; ?></td>
                                            <td><?php echo $obj->grade_title; ?></td>
                                            <td><?php echo $obj->status ? $this->lang->line('active') : $this->lang->line('in_active'); ?>
                                            </td>
                                            <td>
                                                <?php if(has_permission(VIEW, 'master', 'course')){?>
                                                <a onclick="get_chakra_modal(<?php echo $obj->id; ?>);"
                                                    data-toggle="modal" data-target=".bs-school-modal-lg"
                                                    class="btn btn-success btn-xs"><i class="fa fa-eye"></i>
                                                    <?php echo $this->lang->line('view'); ?> </a>
                                                <?php } ?>
                                                <?php ?>
                                                <a href="<?php echo site_url('administrator/course_access/list_chakra/'.$obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a>
                                                <?php  ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade in <?php if (isset($add)) {echo 'active';}?>" id="tab_add_state">
                            <div class="x_content">
                                <form method="post" action="<?php echo site_url('administrator/course_access/add') ?>"
                                    enctype="multipart/form-data">
                                    <div class="x_content">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong>Select <?php echo $this->lang->line('school'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- Your form fields here -->
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="school_id"><?php echo $this->lang->line('school'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="school_id" id="school_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>
                                                        <?php foreach ($schools as $sp) {?>
                                                        <option value="<?php echo $sp->id; ?>">
                                                            <?php echo $sp->school_name; ?>
                                                        </option>
                                                        <?php }?>
                                                    </select>

                                                    <div class="help-block"><?php echo form_error('school_id'); ?></div>
                                                </div>
                                            </div>


                                        </div>


                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course_access/index'); ?>"
                                                    class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit" class="btn btn-success">Synchronous
                                                    Course</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <?php echo form_close(); ?>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        <div class="tab-pane fade in  <?php if (isset($list_chakra)) {echo 'active';}?> "
                            id="tab_chakra">
                            <div class="x_content">
                                <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <tbody>

                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?> </th>
                                            <th><?php echo $this->lang->line('chakra'); ?></th>
                                            <th><?php echo $this->lang->line('class'); ?></th>
                                            <th><?php echo $this->lang->line('subject'); ?></th>
                                            <th><?php echo $this->lang->line('unit'); ?></th>
                                            <th><?php echo $this->lang->line('active'); ?></th>
                                            <th><?php echo $this->lang->line('in_active'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>

                                        <!-- <?php echo "<pre>"; print_r($chakra_list);?> -->


                                        <?php $count = 1;if (isset($chakra_list) && !empty($chakra_list)) {?>
                                        <?php foreach ($chakra_list as $obj) {?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->course_name; ?></td>
                                            <td><?php echo $obj->grade_title; ?></td>
                                            <td><?php echo $obj->subject_title; ?></td>
                                            <td><?php echo $obj->unit_title; ?></td>
                                            <td><?php echo $obj->active_time; ?></td>
                                            <td><?php echo $obj->inactive_time; ?></td>
                                            <td><?php echo $obj->status ? $this->lang->line('active') : $this->lang->line('in_active'); ?>
                                            </td>
                                            <td> <a href="<?php echo site_url('administrator/course_access/edit_chakra/'.$obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a></td>

                                        </tr>
                                        <?php }?>
                                        <?php }?>


                                    </tbody>
                                </table>

                            </div>
                        </div>

                        <?php if (isset($edit_chakra)) {?>
                        <div class="tab-pane fade in active" id="tab_edit_state">
                            <div class="x_content">
                                <?php echo form_open_multipart(site_url('administrator/course_access/edit_chakra/'.$chakra->id), array('name' => 'edit', 'id' => 'edit', 'class'=>'form-horizontal form-label-left'), ''); ?>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title">
                                            <strong>Name:
                                                <?php echo isset($chakra) ? $chakra->course_name : ''; ?></strong>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <!-- <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="item form-group">
                                            <label for="chakra_title">Name:
                                                <span><?php echo isset($chakra) ? $chakra->course_name : ''; ?></span></label>
                                        </div>
                                    </div> -->
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="active_time">Active Time</label>
                                            <input class="form-control col-md-7 col-xs-12" name="active_time"
                                                id="active_time" value="<?php echo isset($chakra) ? $chakra->active_time : ''; ?>" type="datetime-local" required="required">

                                            <div class="help-block"><?php echo form_error('active_time'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="inactive_time">Inactive Time</label>
                                            <input class="form-control col-md-7 col-xs-12" name="inactive_time"
                                                id="inactive_time" type="datetime-local"  value="<?php echo isset($chakra) ? $chakra->inactive_time : ''; ?>"  required="required">

                                            <div class="help-block"><?php echo form_error('inactive_time'); ?></div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="status">Lock/Unlock</label>
                                            <input class="form-control col-md-7 col-xs-12" name="status" id="status"
                                                value="1" checked="checked" placeholder="state status" type="checkbox"
                                                autocomplete="off">

                                            <div class="help-block"><?php echo form_error('status'); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course/index'); ?>"
                                                    class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit"
                                                    class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                            </div>
                                        </div>

                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
                    </div>
                    <div class="modal-body fn_school_data">
                    </div>
                </div>
            </div>
        </div>

        <link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
        <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
        <script type="text/javascript">
        function get_chakra_modal(course_id) {
            if (course_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/course_access/get_chakra_modal'); ?>/" + course_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {
                            $('.fn_school_data').html(response);
                        }
                    }
                });
            }
        }

        function get_course_update(school_id) {
            if (school_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/course_access/get_course_update'); ?>/" +
                        school_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {

                            location.reload();

                        }
                    }
                });
            }
        }
        </script>