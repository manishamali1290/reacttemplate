<div class="" data-example-id="togglable-tabs">
    <ul class="nav nav-tabs bordered">
        <li class="active"><a href="#tab_basic_info" role="tab" data-toggle="tab" aria-expanded="true"><i
                    class="fa fa-info-circle"></i> chakra List</a> </li>
        <!-- <li class=""><a href="#tab_setting_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> <?php echo $this->lang->line('attachment'); ?></a> </li> -->
        <!-- <li class=""><a href="#tab_social_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('social_information'); ?></a> </li> -->
    </ul>
    <br />


    <div class="tab-content">
        <div class="tab-pane fade in active" id="tab_basic_info">

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <tbody>
                    <!-- <?php print_r($S_chakra)?> -->
                    <tr>
                        <th><?php echo $this->lang->line('sl_no'); ?></th>
                        <th><?php echo $this->lang->line('chakra'); ?></th>
                        <!-- <th><?php echo $this->lang->line('subject'); ?></th> -->
                        <th><?php echo $this->lang->line('active'); ?></th>
                        <th><?php echo $this->lang->line('in_active'); ?></th>
                        <th><?php echo $this->lang->line('status'); ?></th>
                        <!-- <th>View Story Link</th> -->
                    </tr>
                    <?php $count = 1; if(isset($S_chakra) && !empty($S_chakra)){ ?>
                    <?php foreach($S_chakra as $obj){ ?>
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td><?php echo $obj->course_name; ?></td>
                        <td><?php echo $obj->active_time; ?></td>
                        <td><?php echo $obj->inactive_time; ?></td>
                        <td><?php echo $obj->status ? $this->lang->line('active') : $this->lang->line('in_active'); ?></td>
                        <!-- <td>  <a target="_blank" href="<?php echo site_url($obj->file); ?>/story.html"><strong>View
                                    Story</strong></a></td> -->
                    </tr>
                  

                    <?php } }?>

                </tbody>
            </table>
        </div>

    </div>
</div>