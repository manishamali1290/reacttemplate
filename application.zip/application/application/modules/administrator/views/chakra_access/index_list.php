<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small>                
                        <?php echo $this->lang->line('manage_course'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content quick-link">
                <?php $this->load->view('quick-link');?>
            </div>

            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">

                    <ul class="nav nav-tabs bordered">
                        <?php if (has_permission(VIEW, 'master', 'course')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?>"><a
                                href="<?php echo site_url('administrator/course_access/index_list'); ?>"
                                aria-expanded="false"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php } else {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?> "><a href="#tab_school_list" role="tab"
                                data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php }}?>

                        <?php if (has_permission(EDIT, 'master', 'course')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="active"><a href="#tab_edit_state" role="tab" data-toggle="tab"
                                aria-expanded="false"><i class="fa fa-pencil-square-o"></i>
                                <?php echo $this->lang->line('edit'); ?></a> </li>
                        <?php }
}?>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_school_list">
                            <div class="x_content">
                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('title'); ?></th>
                                            <th><?php echo $this->lang->line('active'); ?></th>
                                            <th><?php echo $this->lang->line('in_active'); ?></th>
                                            <th><?php echo $this->lang->line('class'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1; if(isset($courses_list) && !empty($courses_list)){ ?>
                                        <?php foreach($courses_list as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->course_name; ?></td>
                                            <td><?php echo $obj->active_time; ?></td>
                                            <td><?php echo $obj->inactive_time; ?></td>
                                            <td><?php echo $obj->grade_title; ?></td>
                                            <td><?php if($obj->status==1)
                                            {
                                                echo 'Active';
                                            }else echo 'Deactive'; ?></td>
                                            <td><a onclick="get_school_modal(<?php echo $obj->course_id; ?>);"
                                                    data-toggle="modal" data-target=".bs-school-modal-lg"
                                                    class="btn btn-success btn-xs"><i class="fa fa-eye"></i>
                                                    <?php echo $this->lang->line('view'); ?> </a> 
                                               
                                                <?php if(has_permission(EDIT, 'master', 'course')){ ?>
                                                <a href="<?php echo site_url('administrator/course_access/edit/'.$obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        
                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_state">
                            <div class="x_content"> 
                               <?php echo form_open_multipart(site_url('administrator/course_access/edit/'.$courses_one->id), array('name' => 'edit', 'id' => 'edit', 'class'=>'form-horizontal form-label-left'), ''); ?>
                               
                               <div class="row">                  
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5  class="column-title"><strong><?php echo $this->lang->line('basic_information'); ?>:</strong></h5>
                                    </div>
                                </div>
                                <div class="row">                                    
                                <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="course_title">Title <span class="required">*</span> </label>
                                            <input readonly  class="form-control col-md-7 col-xs-12"  name="course_title"  id="course_title" value="<?php echo isset($courses_one) ? $courses_one->course_name : ''; ?>" placeholder=" title" required="required" type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('course_title'); ?></div> 
                                        </div>
                                    </div>  
                                        
                                   
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="active_time">Active Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="active_time"
                                                        id="active_time" type="datetime-local"  value="<?php echo isset($courses_one) ? $courses_one->active_time : ''; ?>"   required="required">

                                                    <div class="help-block"><?php echo form_error('active_time'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="inactive_time">Inactive Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="inactive_time"
                                                        id="inactive_time"  value="<?php echo isset($courses_one) ? $courses_one->inactive_time : ''; ?>"   type="datetime-local"  required="required">

                                                    <div class="help-block"><?php echo form_error('inactive_time'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="status">Status</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="status"
                                                        id="status" value="1" checked="checked"
                                                        placeholder="state status" type="checkbox" autocomplete="off">

                                                    <div class="help-block"><?php echo form_error('status'); ?></div>
                                                </div>
                                            </div>
                                        </div>  
                                    
                                   
                                </div>                              

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($school) ? $school->id : '' ?>" name="id" />
                                        <a href="<?php echo site_url('administrator/master/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit" class="btn btn-success"><?php  echo $this->lang->line('update'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
                    </div>
                    <div class="modal-body fn_school_data">
                    </div>
                </div>
            </div>
        </div>

        <link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
        <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
        <script type="text/javascript">
        function get_course_modal(school_id) {
            if (school_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/course_access/get_course_modal'); ?>/" + school_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {
                            $('.fn_school_data').html(response);
                        }
                    }
                });
            }
        }
        function get_course_update(school_id) {
            if (school_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/course_access/get_course_update'); ?>/" + school_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {
                           
                            location.reload();
                           
                        }
                    }
                });
            }
        }
        function get_school_modal(course_id){
         if(course_id){
         $('.fn_school_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>');
         $.ajax({       
           type   : "POST",
           url    : "<?php echo site_url('administrator/course_access/get_single_course'); ?>/"+ course_id,
        //    data   : {course_id : course_id},  
           success: function(response){                                                   
              if(response)
              {
                 $('.fn_school_data').html(response);
              }
           }
        });
    }
     }
        </script>