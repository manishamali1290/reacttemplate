<div class="" data-example-id="togglable-tabs <?php if ($S_course[0]->status==1) { echo 'Active'; } else echo 'Deactive' ?>">
    <ul  class="nav nav-tabs bordered">
        <li class="active"><a href="#tab_basic_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-info-circle"></i> <?php echo $this->lang->line('basic_information'); ?></a> </li>
        <li class=""><a href="#tab_setting_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> <?php echo $this->lang->line('attachment'); ?></a> </li>
        <!-- <li class=""><a href="#tab_social_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('social_information'); ?></a> </li> -->
    </ul>
    <br/>
    
     <div class="tab-content">
        <div  class="tab-pane fade in active" id="tab_basic_info" > 
        <!-- <?php print_r($S_course)?> -->
            <table class="table table-striped table-bordered dt-responsive nowrap <?php if ($S_course[0]->status==1) { echo 'Active'; } else echo 'Deactive' ?> " cellspacing="0" width="100%">
                <tbody>
                   <tr>
                        <th>Course URL</th>
                        <td colspan="3"><a target="_blank" href="<?php echo site_url($S_course[0]->file); ?>/story.html"><strong>View Story</strong></a></td> 
                    </tr>
                    <tr>
                        <th>Active Time</th>
                        <td><?php echo $S_course[0]->active_time; ?></td>        
                        <th>Inactive Time</th>
                        <td><?php echo $S_course[0]->inactive_time; ?></td>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('course'); ?></th>
                        <td><?php echo $S_course[0]->title; ?></td>        
                        <th><?php echo $this->lang->line('description'); ?></th>
                        <td><?php echo $S_course[0]->description; ?></td>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('state'); ?></th>
                        <td><?php echo $S_course[0]->state_title; ?></td>        
                        <th><?php echo $this->lang->line('grade'); ?></th>
                        <td><?php echo $S_course[0]->grade_title; ?></td>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('board'); ?></th>
                        <td><?php echo $S_course[0]->board_title; ?></td>        
                        <th><?php echo $this->lang->line('section'); ?></th>
                        <td><?php echo $S_course[0]->section_title; ?></td>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('subject'); ?></th>
                        <td><?php echo $S_course[0]->subject_title; ?></td>        
                        <th><?php echo $this->lang->line('volume'); ?></th>
                        <td><?php echo $S_course[0]->volume_title; ?></td>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('unit'); ?></th>
                        <td><?php echo $S_course[0]->unit_title; ?></td>        
                        <th><?php echo $this->lang->line('lessons'); ?></th>
                        <td><?php echo $S_course[0]->lessons_title; ?></td>
                    </tr>
                    
                    <tr>   
                        <th><?php echo $this->lang->line('chakra'); ?></th>
                        <td><?php echo $S_course[0]->chakra_title; ?></td>  
                        <th><?php echo $this->lang->line('status'); ?></th>
                        <td><?php if ($S_course[0]->status==1) { echo 'Active'; } else echo 'Deactive' ?></td>                     
                    </tr>
                    
                    
                </tbody>
            </table>
        </div>
         
        <div  class="tab-pane fade in" id="tab_setting_info" > 
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <tbody>                               
            <?php $count = 1;if (isset($S_course_files) && !empty($S_course_files)) {?>
            <?php foreach ($S_course_files as $obj) {?>
                <tr>
                    <td><?php echo $count++; ?></td>
                    <td><a href="<?php echo  site_url($obj->path); ?>" target="_blank"> <?php echo  site_url($obj->path); ?></a></td>
                </tr>          
              
                  
            <?php } }?>         
            </tbody>
        </table>
        </div>
         
       
    </div>
</div>
