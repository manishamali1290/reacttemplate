<style>
input[type=file] {

    min-height: 40px !important;
    font-size: 12px !important;
    opacity: 1 !important;
    position: relative !important;
}

input#zip_file {
    min-width: 200px !important;
    border: 1px solid #ccc;
    border-radius: 3px;
    min-height: 33px !important;
    margin-top: -6px;

}

.item.form-group.form-control.custom-file {
    border: none !important;
    background-color: inherit !important;
    box-shadow: none !important;
}

.field {
    margin-bottom: 10px;
    display: flex;
    transition: opacity 0.3s;
}

.field input {
    padding: 5px 10px;
    width: 100%;
    border: none;
    border: thin solid #d4d4d4;
    font-size: 20px;
    color: #888;
    font-family: ubuntu, sans-serif;
    background-color: #f9f9f9;
}

input#zip_file {
    padding: 5px;
}

.input-group-btn {
    top: 28px;
}

.field input:focus {
    outline: none;
}

.field span {
    display: inline-block;
    margin-left: 10px;
    cursor: pointer;
    background-color: #f9f9f9;
    padding: 10px;
    font-size: 20px;
    transition: all 0.3s;
    font-weight: bold;
    border: thin solid #d4d4d4;
}

.field span:last-child {
    display: none;
    padding: 12px;
}

label.zip-input {
    position: relative;
    top: -5px;
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 14px !important;
    line-height: 1.428571429;
    color: #333 !important;
}

.field span:hover {
    background-color: green;
    border: thin solid green;
    color: #fff;
}

.field span:last-child:hover {
    background-color: red;
    border: thin solid red;
    color: #fff;
}


.reset1 {
    float: right;
    background-color: green;
}
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small>
                        <?php echo $this->lang->line('manage_course'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content quick-link">
                <?php $this->load->view('quick-link');?>
            </div>

            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">

                    <ul class="nav nav-tabs bordered">
                        <?php if (has_permission(VIEW, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?>"><a
                                href="<?php echo site_url('administrator/course/index'); ?>" aria-expanded="false"><i
                                    class="fa fa-list-ol"></i> <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php } else {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?> "><a href="#tab_state_list" role="tab"
                                data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php }}?>

                        <?php if (has_permission(ADD, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <!-- <li  class="<?php if (isset($add)) {echo 'active';}?>"><a href="<?php echo site_url('administrator/course/index/#tab_add_state'); ?>"  aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('add'); ?></a> </li>                           -->
                        <?php } else {?>
                        <li class="<?php if (isset($add)) {echo 'active';}?>"><a href="#tab_add_state" role="tab"
                                data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i>
                                <?php echo $this->lang->line('add'); ?></a> </li>
                        <?php }?>
                        <?php }?>

                        <?php if (has_permission(EDIT, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="active"><a href="#tab_edit_state" role="tab" data-toggle="tab"
                                aria-expanded="false"><i class="fa fa-pencil-square-o"></i>
                                <?php echo $this->lang->line('edit'); ?></a> </li>
                        <?php }
}?>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if (isset($list)) {echo 'active';}?> " id="tab_state_list">
                            <div class="x_content">
                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('name'); ?></th>
                                            <th><?php echo $this->lang->line('description'); ?></th>
                                            <th><?php echo $this->lang->line('state'); ?></th>
                                            <th><?php echo $this->lang->line('board'); ?></th>
                                            <th><?php echo $this->lang->line('grade'); ?></th>
                                            <!-- <th><?php echo $this->lang->line('subject'); ?></th>
                                            <th><?php echo $this->lang->line('volume'); ?></th>
                                            <th><?php echo $this->lang->line('unit'); ?></th>
                                            <th><?php echo $this->lang->line('lesson'); ?></th>
                                            <th><?php echo $this->lang->line('chakra'); ?></th> -->
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1;if (isset($courses) && !empty($courses)) {?>
                                        <?php foreach ($courses as $obj) {?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>

                                            <td><?php echo $obj->title; ?> </td>
                                            <td><?php echo $obj->description; ?></td>
                                            <td><?php echo $obj->state_title; ?></td>
                                            <td><?php echo $obj->board_title; ?></td>
                                            <td><?php echo $obj->grade_title; ?></td>
                                            <!-- <td><?php echo $obj->subject_title ?></td>
                                            <td><?php echo $obj->volume_title; ?></td>
                                            <td><?php echo $obj->unit_title; ?></td>
                                            <td><?php echo $obj->lessons_title; ?></td>
                                            <td><?php echo $obj->chakra_title; ?></td> -->
                                            <td><?php if ($obj->status == 1) {
                                                    echo 'Active';
                                                } else {
                                                    echo 'Deactive';
                                                }
                                                    ?></td>
                                                    <td>
                                                <?php if (has_permission(VIEW, 'master', 'master')) {?>
                                                <a onclick="get_school_modal(<?php echo $obj->id; ?>);"
                                                    data-toggle="modal" data-target=".bs-school-modal-lg"
                                                    class="btn btn-success btn-xs"><i class="fa fa-eye"></i>
                                                    <?php echo $this->lang->line('view'); ?> </a> 
                                                <?php }?>
                                                <?php if (has_permission(EDIT, 'master', 'master')) {?>
                                                <a href="<?php echo site_url('administrator/course/edit/' . $obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a>
                                                <?php }?>
                                                <?php if (has_permission(DELETE, 'master', 'master')) {?>
                                                <a href="<?php echo site_url('administrator/course/delete/' . $obj->id); ?>"
                                                    onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');"
                                                    class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                                                    <?php echo $this->lang->line('delete'); ?> </a>
                                                <?php }?>
                                            </td>
                                        </tr>
                                        <?php }?>
                                        <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade in <?php if (isset($add)) {echo 'active';}?>" id="tab_add_state">
                            <div class="x_content">
                                <form method="post" action="<?php echo base_url('administrator/course/add') ?>"
                                    enctype="multipart/form-data">
                                    <div class="x_content">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('basic_information'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- Your form fields here -->
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="course_title">Title <span
                                                            class="required">*</span></label>
                                                    <input class="form-control col-md-7 col-xs-12" name="course_title"
                                                        id="course_title"
                                                        value="<?php echo isset($post['course_title']) ? $post['course_title'] : ''; ?>"
                                                        placeholder="title" required="required" type="text"
                                                        autocomplete="off">
                                                    <div class="help-block"><?php echo form_error('course_title'); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="course_description">Description</label>
                                                    <input class="form-control col-md-7 col-xs-12"
                                                        name="course_description" id="course_description"
                                                        value="<?php echo isset($post['course_description']) ? $post['course_description'] : ''; ?>"
                                                        placeholder="description" type="text" autocomplete="off">
                                                    <div class="help-block">
                                                        <?php echo form_error('course_description'); ?></div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group form-control custom-file">
                                                    <label class="zip-input" for="zip_file">Upload story line zip<span
                                                            class="required">*</span></label>
                                                    <input type="file" class="col-md-3 custom-file-input" id="zip_file"
                                                        name="zip_file" accept=".zip" required="required">
                                                   
                                                    <div class="help-block"><?php echo form_error('zip_file'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('select'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="state_id"><?php echo $this->lang->line('state'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="state_id" id="state_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>
                                                        <?php foreach ($states as $sp) {?>
                                                        <option value="<?php echo $sp->id; ?>"><?php echo $sp->title; ?>
                                                        </option>
                                                        <?php }?>
                                                    </select>

                                                    <div class="help-block"><?php echo form_error('state_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="board_id"><?php echo $this->lang->line('board'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="board_id" id="board_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('board_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="grade_id"><?php echo $this->lang->line('grade'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="grade_id" id="grade_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('grade_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="section_id"><?php echo $this->lang->line('section'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="section_id" id="section_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('section_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="subject_id"><?php echo $this->lang->line('subject'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="subject_id" id="subject_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('subject_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="volume_id"><?php echo $this->lang->line('volume'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="volume_id" id="volume_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('volume_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="unit_id"><?php echo $this->lang->line('unit'); ?> <span
                                                            class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="unit_id" id="unit_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('unit_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="lessons_id"><?php echo $this->lang->line('lessons'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="lessons_id" id="lessons_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('lessons_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="chakra_id"><?php echo $this->lang->line('chakra'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="chakra_id" id="chakra_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('chakra_id'); ?>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">

                                        <!-- <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="active_time">Active Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="active_time"
                                                        id="active_time" type="datetime-local"   required="required">

                                                    <div class="help-block"><?php echo form_error('active_time'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="inactive_time">Inactive Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="inactive_time"
                                                        id="inactive_time"   type="datetime-local"  required="required">

                                                    <div class="help-block"><?php echo form_error('inactive_time'); ?></div>
                                                </div>
                                            </div> -->
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="status">Status</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="status"
                                                        id="status" value="1" checked="checked"
                                                        placeholder="state status" type="checkbox" autocomplete="off">

                                                    <div class="help-block"><?php echo form_error('status'); ?></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('attachment'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="panel panel-default">
                                            <div class="panel-body">

                                                <div class="col-sm-4 nopadding">
                                                    <div class="form-group">
                                                        <!-- <label for="file">File Name<span class="required">*</span></label> -->
                                                        <label for="file">File Name</label>
                                                        <input type="text" class="form-control" id="file_name" name="file_name[]"
                                                            value="" placeholder="Upload file Name" require>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 nopadding">
                                                    <div class="form-group">
                                                        <label for="file">Upload File</label>
                                                        <input type="file" class="form-control" id="file" name="file[]"
                                                            value="" placeholder="upload file">
                                                    </div>
                                                </div>

                                                <div class="col-sm-4 nopadding">
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-btn">
                                                                <button class="btn btn-success" type="button"
                                                                    onclick="education_fields();">
                                                                    <span class="glyphicon glyphicon-plus"
                                                                        aria-hidden="true"></span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                              
                                            </div>
                                            <div id="education_fields">
                                                    <!-- Initially empty -->
                                                </div>
                                                <div class="clear"></div>
                                        </div>


                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course/index'); ?>"
                                                    class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit"
                                                    class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <?php echo form_close(); ?>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        <?php if (isset($edit)) {?>
                        <div class="tab-pane fade in active" id="tab_edit_state">
                            <div class="x_content">
                                <?php echo form_open_multipart(site_url('administrator/course/edit/' . $course->id), array('name' => 'edit', 'id' => 'edit', 'class' => 'form-horizontal form-label-left'), ''); ?>
                                <div class="x_content">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('basic_information'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- Your form fields here -->
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="course_title">Title <span
                                                            class="required">*</span></label>
                                                    <input class="form-control col-md-7 col-xs-12" name="course_title"
                                                        id="course_title"
                                                        value="<?php echo isset($course) ? $course->title : ''; ?>"
                                                        placeholder="title" required="required" type="text"
                                                        autocomplete="off">
                                                    <div class="help-block"><?php echo form_error('course_title'); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="course_description">Description</label>
                                                    <input class="form-control col-md-7 col-xs-12"
                                                        name="course_description" id="course_description"
                                                        value="<?php echo isset($course) ? $course->description : ''; ?>"
                                                        placeholder="description" type="text" autocomplete="off">
                                                    <div class="help-block">
                                                        <?php echo form_error('course_description'); ?></div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group form-control custom-file">
                                                <label class="zip-input" for="zip_file">Upload story line {not Edit}<span
                                                            class="required">*</span></label>
                                                            <label class="zip-input" for="zip_file"><a target="_blank" href="<?php echo site_url($course->file); ?>/story.html"><strong>View Story</strong></a></label>
                                                   
                                               
                                                    <div class="help-block"><?php echo form_error('zip_file'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('select'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="state_id"><?php echo $this->lang->line('state'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="state_id" id="state_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>
                                                        <?php foreach ($states as $sp) {?>
                                                        <option value="<?php echo $sp->id; ?>" <?php if ($sp->id == $course->state_id) { echo 'selected'; } ?>><?php echo $sp->title; ?>
                                                        </option>
                                                        <?php }?>
                                                    </select>

                                                    <div class="help-block"><?php echo form_error('state_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="board_id"><?php echo $this->lang->line('board'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="board_id" id="board_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('board_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="grade_id"><?php echo $this->lang->line('grade'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="grade_id" id="grade_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('grade_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="section_id"><?php echo $this->lang->line('section'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="section_id" id="section_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('section_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="subject_id"><?php echo $this->lang->line('subject'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="subject_id" id="subject_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('subject_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="volume_id"><?php echo $this->lang->line('volume'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="volume_id" id="volume_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('volume_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="unit_id"><?php echo $this->lang->line('unit'); ?> <span
                                                            class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="unit_id" id="unit_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('unit_id'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="lessons_id"><?php echo $this->lang->line('lessons'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="lessons_id" id="lessons_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('lessons_id'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="chakra_id"><?php echo $this->lang->line('chakra'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="chakra_id" id="chakra_id_edit" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>

                                                    </select>

                                                    <div class="help-block"><?php echo form_error('chakra_id'); ?>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">
                                            
                                        <!-- <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="active_time">Active Times </label>
                                                    <input class="form-control col-md-7 col-xs-12" name="active_time"
                                                    <?php echo isset($course) ? $course->description : ''; ?>
                                                        id="active_time" type="datetime-local"   required="required"   value="<?php echo isset($course) ? $course->active_time : ''; ?>">

                                                    <div class="help-block"><?php echo form_error('active_time'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="inactive_time">Inactive Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="inactive_time"
                                                        id="inactive_time"   type="datetime-local"  required="required"        value="<?php echo isset($course) ? $course->inactive_time : ''; ?>">

                                                    <div class="help-block"><?php echo form_error('inactive_time'); ?></div>
                                                </div>
                                            </div> -->

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="status">Status <span class="required">* </span><?php if ($course->status==1) { echo 'Active'; } else echo 'Deactive' ?></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="status"  id="status" value="1" checked="checked" placeholder="state status"  type="checkbox" autocomplete="off">
                                            <!-- <div class="text-info"><?php echo $this->lang->line('school_url_format'); ?></div> -->
                                            <div class="help-block"><?php echo form_error('atate_title'); ?></div> 
                                        </div>
                                    </div> 

                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong><?php echo $this->lang->line('attachment'); ?>:</strong>
                                                </h5>
                                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('name'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <?php $count = 1;if (isset($course_file) && !empty($course_file)) {?>
                                        <?php foreach ($course_file as $obj) {?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>

                                            <td><a target="_blank" href="<?php echo site_url($obj->path); ?>"><strong><?php echo $obj->file_name; ?></strong></a> </td>
                                                    <td>
                                                <?php if (has_permission(DELETE, 'master', 'master')) {?>
                                                <a href="<?php echo site_url('administrator/course/delete_file/' . $obj->id); ?>"
                                                    onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');"
                                                    class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                                                    <?php echo $this->lang->line('delete'); ?> </a>
                                                <?php }?>
                                            </td>
                                        </tr>
                                        <?php }?>
                                        <?php }?>
                                    </tbody>
                                </table>
                                            </div>
                                        </div>

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('administrator/course/index'); ?>"
                                            class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit"
                                            class="btn btn-success"><?php echo $this->lang->line('update'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                        <?php }?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
            </div>
            <div class="modal-body fn_school_data">
            </div>
        </div>
    </div>
</div>

<link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
<script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
<script type="text/javascript">

$(document).ready(function() {
    if ($('#state_id_edit').val())
        getBoard($('#state_id_edit').val());
});
function get_school_modal(course_id){
         if(course_id){
         $('.fn_school_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>');
         $.ajax({       
           type   : "POST",
           url    : "<?php echo site_url('administrator/course/get_single_course'); ?>/"+ course_id,
        //    data   : {course_id : course_id},  
           success: function(response){                                                   
              if(response)
              {
                 $('.fn_school_data').html(response);
              }
           }
        });
    }
     }

function getBoard(stateId) {
    $('#board_id').empty();
    $('#board_id_edit').empty();

    console.log("stateId", stateId);

    $('#board_id,#board_id_edit').append('<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');
    if (stateId) {
        $.ajax({
            url: "<?php echo site_url('administrator/master/get_board_list_by_state_id'); ?>/" + stateId,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#board_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');

                        if (value.id == <?php echo $course->board_id ?? 0; ?>) {
                            $('#board_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else
                            $('#board_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                    });
                    if ($('#board_id_edit').val())
                        getGrade($('#board_id_edit').val());

                }
            }
        });
    }

}


function getGrade(selectedBoard) {
    if (selectedBoard) {
        console.log("selectedBoard", selectedBoard);

        $('#grade_id').empty();
        $('#grade_id_edit').empty();

        $('#grade_id,#grade_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');
        $.ajax({
            url: "<?php echo site_url('administrator/master/get_grade_list_by_board_id'); ?>/" + selectedBoard,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {
                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#grade_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->grade_id ?? 0; ?>) {
                            $('#grade_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                            console.log('Selected Value:', selectedBoard);
                        } else
                            $('#grade_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                    });
                    if ($('#grade_id_edit').val())
                        getSections($('#grade_id_edit').val());

                }
            }
        });
    }
}

function getSections(selectedGrade) {
    if (selectedGrade) {
        console.log('selectedGrade', selectedGrade);
        $('#section_id').empty();
        $('#section_id_edit').empty();
        $('#section_id,#section_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_sections_by_grade_id'); ?>/" + selectedGrade,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#section_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->section_id ?? 0; ?>) {
                            $('#section_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#section_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });
                    if ($('#section_id_edit').val())
                        getSubject($('#section_id_edit').val());
                }
            }
        });
    }
}

function getSubject(sectionsID) {
    if (sectionsID) {
        console.log('selectedGrade', sectionsID);
        $('#subject_id').empty();
        $('#subject_id_edit').empty();
        $('#subject_id,#subject_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_subject_by_section_id'); ?>/" + sectionsID,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#subject_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->subject_id ?? 0; ?>) {
                            $('#subject_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#subject_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });
                    if ($('#subject_id_edit').val())
                        getVolume($('#subject_id_edit').val());
                }
            }
        });
    }
}

function getVolume(subjectid) {
    if (subjectid) {
        console.log('selectedGrade', subjectid);
        $('#volume_id').empty();
        $('#volume_id_edit').empty();
        $('#volume_id,#volume_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_volume_by_subject_id'); ?>/" + subjectid,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#volume_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->volume_id ?? 0; ?>) {
                            $('#volume_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#volume_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });

                    if ($('#volume_id_edit').val())
                        getUnit($('#volume_id_edit').val());
                }
            }
        });
    }
}

function getUnit(volume_id) {
    if (volume_id) {
        console.log('volume_id', volume_id);
        $('#unit_id').empty();
        $('#unit_id_edit').empty();
        $('#unit_id,#unit_id_edit').append('<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_unit_by_volume_id'); ?>/" + volume_id,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#unit_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->unit_id ?? 0; ?>) {
                            $('#unit_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#unit_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });

                    if ($('#unit_id_edit').val())
                        getLesson($('#unit_id_edit').val());

                }
            }
        });
    }
}

function getLesson(unit_id) {
    if (unit_id) {
        console.log('volume_id', unit_id);
        $('#lessons_id').empty();
        $('#lessons_id_edit').empty();
        $('#lessons_id,#lessons_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_lesson_by_unit_id'); ?>/" + unit_id,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#lessons_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->lessons_id ?? 0; ?>) {
                            $('#lessons_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#lessons_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });
                    if ($('#lessons_id_edit').val())
                    getChackra($('#lessons_id_edit').val());

                }
            }
        });
    }
}
function getChackra(lessons_id) {
    if (lessons_id) {
        console.log('volume_id', lessons_id);
        $('#chakra_id').empty();
        $('#chakra_id_edit').empty();
        $('#chakra_id,#chakra_id_edit').append(
            '<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');

        $.ajax({
            url: "<?php echo site_url('administrator/master/get_cakra_by_lesson_id'); ?>/" + lessons_id,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#chakra_id').append('<option value="' + value.id + '">' + value.title +
                            '</option>');
                        if (value.id == <?php echo $course->lessons_id ?? 0; ?>) {
                            $('#chakra_id_edit').append('<option value="' + value.id +
                                '" selected>' + value.title + '</option>');
                        } else {
                            $('#chakra_id_edit').append('<option value="' + value.id + '">' + value
                                .title + '</option>');
                        }
                    });
                }
            }
        });
    }
}


$('#state_id , #state_id_edit').on('change', function() {
    var stateId = $(this).val();
    console.log(stateId);
    getBoard(stateId);

});

$('#board_id , #board_id_edit').on('change', function() {
    var board_id = $(this).val();
    console.log(board_id);
    getGrade(board_id);
});
$('#grade_id , #grade_id_edit').on('change', function() {
    var gradeId = $(this).val();
    getSections(gradeId);
});
$('#section_id , #section_id_edit').on('change', function() {
    var sectionid = $(this).val();
    getSubject(sectionid);
});
$('#subject_id , #subject_id_edit').on('change', function() {
    var subjectid = $(this).val();
    getVolume(subjectid);
});
$('#volume_id , #volume_id_edit').on('change', function() {
    var volume_id = $(this).val();
    getUnit(volume_id);
});
$('#unit_id , #unit_id_edit').on('change', function() {
    var unit_id = $(this).val();
    getLesson(unit_id);
});
$('#lessons_id , #lessons_id_edit').on('change', function() {
    var lessons_id = $(this).val();
    getChackra(lessons_id);
});

</script>
<script>
var room = 0; // Initialize room counter to 0

function education_fields() {
    room++;
    var objTo = document.getElementById('education_fields');
    var divtest = document.createElement("div");
    divtest.setAttribute("class", "form-group panel-body removeclass" + room);
    var rdiv = 'removeclass' + room;
    divtest.innerHTML =
        '<div class="col-sm-4 nopadding"><div class="form-group"><input type="text" class="form-control" id="file_name" name="file_name[]" value="" placeholder="Upload file Name" require> </div> </div><div class="col-sm-4 nopadding"><div class="form-group"> <input type="file" class="form-control" id="file' +
        room +
        '" name="file[]" value="" placeholder="Upload file" required></div></div><div class="col-sm-4 nopadding"><div class="form-group"><div class="input-group"> <div class="input-group-btn"> <button class="btn btn-danger" style="top: -25px;" type="button" onclick="remove_education_fields(' +
        room +
        ');"> <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> </button></div></div></div></div><div class="clear"></div>';

    objTo.appendChild(divtest);
}


function remove_education_fields(rid) {
    $('.removeclass' + rid).remove();
}
</script>