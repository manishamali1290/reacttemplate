<div class="" data-example-id="togglable-tabs">
    <ul  class="nav nav-tabs bordered">
        <li class="active"><a href="#tab_basic_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-info-circle"></i> chakra</a> </li>
        <!-- <li class=""><a href="#tab_setting_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> <?php echo $this->lang->line('attachment'); ?></a> </li> -->
        <!-- <li class=""><a href="#tab_social_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('social_information'); ?></a> </li> -->
    </ul>
    <br/>

    
     <div class="tab-content">
        <div  class="tab-pane fade in active" id="tab_basic_info" > 
        
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <tbody>
                <!-- <?php print_r($S_chakra)?> -->
                <tr>
                        <th>S No.</th>
                        <th>Name</th>
                </tr>                   
                 <?php $count = 1; if(isset($S_chakra) && !empty($S_chakra)){ ?>
                    <?php foreach($S_chakra as $obj){ ?>
                    <tr> 
                        <td><?php echo $count++; ?></td>
                        <td><?php print_r($obj->course_name)?></td>                        
                    </tr>
                    
                    <?php } ?>
                    <?php } ?>
                      
                </tbody>
            </table>
        </div>
         
       
    </div>
</div>
