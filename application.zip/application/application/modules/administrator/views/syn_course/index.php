<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small>
                        <?php echo $this->lang->line('manage_course'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content quick-link">
                <?php $this->load->view('quick-link');?>
            </div>

            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">

                    <ul class="nav nav-tabs bordered">
                        <?php if (has_permission(VIEW, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?>"><a
                                href="<?php echo site_url('administrator/course_access/index'); ?>"
                                aria-expanded="false"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php } else {?>
                        <li class="<?php if (isset($list)) {echo 'active';}?> "><a href="#tab_school_list" role="tab"
                                data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php }}?>

                        <?php if (has_permission(ADD, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <!-- <li  class="<?php if (isset($add)) {echo 'active';}?>"><a href="<?php echo site_url('administrator/course_access/index/#tab_add_state'); ?>"  aria-expanded="false"><i class="fa fa-refresh"></i> Syn Course</a> </li>                           -->
                        <?php } else {?>
                        <li class="<?php if (isset($add)) {echo 'active';}?>"><a href="#tab_add_state" role="tab"
                                data-toggle="tab" aria-expanded="false"><i class="fa fa-refresh"></i> Synchronous
                                Course</a> </li>
                        <?php }?>
                        <?php }?>

                        <?php if (has_permission(EDIT, 'master', 'master')) {?>
                        <?php if (isset($edit)) {?>
                        <li class="active"><a href="#tab_edit_state" role="tab" data-toggle="tab"
                                aria-expanded="false"><i class="fa fa-pencil-square-o"></i>
                                <?php echo $this->lang->line('edit'); ?></a> </li>
                        <?php }
}?>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_school_list">
                            <div class="x_content">
                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('school_name'); ?></th>
                                            <th><?php echo $this->lang->line('address'); ?></th>
                                            <th><?php echo $this->lang->line('phone'); ?></th>
                                            <th><?php echo $this->lang->line('email'); ?></th>
                                            <th><?php echo $this->lang->line('admin_logo'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1; if(isset($schools) && !empty($schools)){ ?>
                                        <?php foreach($schools as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td>
                                                <?php echo $obj->school_name; ?><br />
                                                <?php if($obj->status){ ?>
                                                <a class="btn btn-success btn-xs" target="_blank"
                                                    href="<?php echo site_url($obj->school_url); ?>"><?php echo $this->lang->line('visit_school'); ?></a>
                                                <?php }else{ ?>
                                                <a class="btn btn-success btn-xs"
                                                    href="<?php echo site_url('administrator/school/edit/'.$obj->id); ?>"><?php echo $this->lang->line('activate_now'); ?></a>
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $obj->address; ?></td>
                                            <td><?php echo $obj->phone; ?></td>
                                            <td><?php echo $obj->email; ?></td>
                                            <td>
                                                <?php if($obj->logo){ ?>
                                                <img class="logo-identifier"
                                                    src="<?php echo UPLOAD_PATH; ?>/logo/<?php echo $obj->logo; ?>"
                                                    alt="" width="80" />
                                                <?php }else{ ?>
                                                <img class="logo-identifier"
                                                    src="<?php echo IMG_URL; ?>/sms-logo-50.png" alt="" width="80" />
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $obj->status ? $this->lang->line('active') : $this->lang->line('in_active'); ?>
                                            </td>
                                            <td>
                                                <?php if(has_permission(VIEW, 'master', 'course')){ ?>
                                                <a onclick="get_course_modal(<?php echo $obj->id; ?>);"
                                                    data-toggle="modal" data-target=".bs-school-modal-lg"
                                                    class="btn btn-success btn-xs"><i class="fa fa-eye"></i>
                                                    <?php echo $this->lang->line('view'); ?> </a>
                                                <?php } ?>
                                                <!-- <?php if(has_permission(EDIT, 'master', 'course')){ ?>
                                                <a href="<?php echo site_url('administrator/course_access/edit/'.$obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a>
                                                <?php } ?> -->
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade in <?php if (isset($add)) {echo 'active';}?>" id="tab_add_state">
                            <div class="x_content">
                                <form method="post" action="<?php echo site_url('administrator/syn_course/add') ?>"
                                    enctype="multipart/form-data">
                                    <div class="x_content">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong>Select <?php echo $this->lang->line('school'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- Your form fields here -->
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="school_id"><?php echo $this->lang->line('school'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type"
                                                        name="school_id" id="school_id" style="float: left;"
                                                        required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>
                                                        <?php foreach ($schools as $sp) {?>
                                                        <option value="<?php echo $sp->id; ?>">
                                                            <?php echo $sp->school_name; ?>
                                                        </option>
                                                        <?php }?>
                                                    </select>

                                                    <div class="help-block"><?php echo form_error('school_id'); ?></div>
                                                </div>
                                            </div>


                                        </div>


                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course_access/index'); ?>"
                                                    class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit" class="btn btn-success">Synchronous
                                                    Course</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <?php echo form_close(); ?>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        <?php if (isset($edit)) {?>
                        <div class="tab-pane fade in active" id="tab_edit_state">
                            <div class="x_content">
                                <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <tbody>

                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('name'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>


                                        <?php $count = 1;if (isset($courses) && !empty($courses)) {?>
                                        <?php foreach ($courses as $obj) {?>
                                        <tr >
                                            <td><?php echo $count++; ?></td>

                                            <td><strong><?php echo $obj->course_name; ?></strong> </td>
                                            <td> <?php if(has_permission(EDIT, 'master', 'master')){ ?>
                                                <a  onclick="get_course_update(<?php echo $obj->id; ?>);"
                                                    class="btn btn-info btn-xs <?php if($obj->deleted_by_admin == 0) echo 'btn-danger' ?>">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                    <?php if($obj->deleted_by_admin == 0){  echo $this->lang->line('active'); }
                                                    else{ echo $this->lang->line('in_active');}?> </a>
                                                <?php } ?></td>

                                        </tr>
                                        <?php }?>
                                        <?php }?>


                                    </tbody>
                                </table>

                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
                    </div>
                    <div class="modal-body fn_school_data">
                    </div>
                </div>
            </div>
        </div>

        <link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
        <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
        <script type="text/javascript">
            
        function get_course_modal(school_id) {
            if (school_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/syn_course/get_course_modal'); ?>/" + school_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {
                            $('.fn_school_data').html(response);
                        }
                    }
                });
            }
        }
        function get_course_update(school_id) {
            if (school_id) {
                $('.fn_school_data').html(
                    '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                );
                $.ajax({
                    type: "POST",
                    url: "<?php echo site_url('administrator/course_access/get_course_update'); ?>/" + school_id,
                    //    data   : {course_id : course_id},  
                    success: function(response) {
                        if (response) {
                           
                            location.reload();
                           
                        }
                    }
                });
            }
        }
        </script>