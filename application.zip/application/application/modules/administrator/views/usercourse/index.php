<style>
iframe.storyline {
    min-height: 300px;
    height: 100vh;
    width: 100%;
}

.row.home_top_mar {
    margin-top: 50px;
}

:root {
    --radius: 20vh;
    --frame-size: calc(var(--radius) / 3);
    --d-outer: calc(var(--radius) * 2);
    --d-inner: calc(var(--d-outer) - var(--frame-size));
    --font-size: calc(var(--radius) / 10);
}

.homeDataWrap {
    min-height: 100vh;
}
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Inconsolata, sans-serif;
}

p {
    font-size: var(--font-size);
}

.circle {
    position: relative;
    width: var(--d-outer);
    height: var(--d-outer);
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;

    max-width: 300px;
    max-height: 300px;
}

.tex-main p {
    margin-top: 30px;

}

.tex-main {
    position: absolute;
    width: var(--d-inner);
    height: var(--d-inner);
    background: #cbc3e3;
    /* background: url(https://avatars.githubusercontent.com/u/58844494?v=4); */
    background-size: cover;
    border-radius: 50%;
    filter: contrast(1.5);
    padding-top: 80px;
    max-width: 300px;
    max-height: 300px;
}

.text {
    position: absolute;
    width: 100%;
    height: 100%;
    max-width: 300px;
    max-height: 300px;
    animation: rotateText 10s linear infinite;
}

.chakra-dataWrap {
    /*text-align: center;*/
    margin: 10px auto 0;
    width: 45px;
    height: 45px;
    border-radius: 100%;
    /* box-shadow: 0px 4px 4px 0 rgba(0, 0, 0, 0.12); */
    display: flex;
    justify-content: center;
    align-items: center;
    margin: -23px auto;
}

@keyframes rotateText {
    0% {
        transform: rotate(360deg);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Inconsolata, sans-serif;
    }

    p {
        font-size: var(--font-size);
    }

    .circle {
        position: relative;
        width: var(--d-outer);
        height: var(--d-outer);
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;

        max-width: 300px;
        max-height: 300px;
    }

    .tex-main p {
        margin-top: 30px;

    }

    .tex-main {
        position: absolute;
        width: var(--d-inner);
        height: var(--d-inner);
        background: #cbc3e3;
        /* background: url(https://avatars.githubusercontent.com/u/58844494?v=4); */
        background-size: cover;
        border-radius: 50%;
        filter: contrast(1.5);
        padding-top: 80px;
        max-width: 300px;
        max-height: 300px;
    }

    .text {
        position: absolute;
        width: 100%;
        height: 100%;
        max-width: 300px;
        max-height: 300px;
        animation: rotateText 10s linear infinite;
    }

    @keyframes rotateText {
        0% {
            transform: rotate(360deg);
        }

        100% {
            transform: rotate(0deg);
        }
    }
}

.text p span {
    position: absolute;
    left: 50%;
    font-size: 1.2em;
    transform-origin: 0 var(--radius);
}
</style>


<style>
. {

    background-color: #8fd3f4;
    background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"%3E%3Cpath fill="%23ffffff" d="M0 192l48-5.3C96 181 192 171 288 181.3c96 10.7 192 42.7 288 58.7C672 267 768 267 864 261.3c96-5.7 192-21.7 288-37.4s192-32.7 240-37.4l48-5.3v320H0z"%3E%3C/path%3E%3C/svg%3E');
    background-size: cover;
}

.slides-list {
    display: flex;
    flex-direction: column;
    margin-right: 20px;
}

.slides-title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
    color: black;
}

.slide-button {
    width: auto;
    height: 40px;
    padding: 8px;
    border-radius: 33px;
    background-color: #ffcc66;

    text-align: center;
    font-weight: 600 !important;
    font-size: 16px;
    cursor: pointer;
    margin-bottom: 10px;
}

.slide-button a {
    color: #fff !important;
}

.play-circle {
    width: 280px;
    height: 280px;
    border-radius: 50%;
    background-color: #FF8C00;
    display: flex;
    align-items: center;
    justify-content: center;
    float: left;
    margin-top: 140px;


}

.play-image {
    width: 100%;
    max-width: 95px;
    max-height: auto;
    border-radius: 50%;
    object-fit: contain;
    margin-top: 1px;
}

span.sub_let {
    font-size: 35px;
    color: #fff;
    font-weight: 700;
    font-family: FontAwesome;
}
</style>


<style>
.progress-page-container {

    background-color: #8fd3f4;
    background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"%3E%3Cpath fill="%23ffffff" d="M0 192l48-5.3C96 181 192 171 288 181.3c96 10.7 192 42.7 288 58.7C672 267 768 267 864 261.3c96-5.7 192-21.7 288-37.4s192-32.7 240-37.4l48-5.3v320H0z"%3E%3C/path%3E%3C/svg%3E');
    background-size: cover;

}

.title {
    margin: 5px;
    font-size: 18px;
    font-weight: bold;
    color: #333;
}

.badge {

    background-color: #dd2222;
    color: #fff;
    padding: 8px 85px;
    border-radius: 10px;
    font-weight: bold;
    margin: 5px;
    text-align: start !important;
}

h3 {
    color: #2c3e50;
    text-align: center;

}


.make_center {
    align-items: center !important;
    text-align: center !important;
}

.subject-name h3 {
    font-size: 18px;
    color: white
}

.subject-name a {
    color: white;
    text-decoration: none;
}

.ribbon-container {
    position: relative;
    width: 100px;
    height: auto;

}

.ribbon {
    position: absolute;
    top: -14px;
    left: -36px;
    width: 107px;
    padding: 5px;
    background-color: #e74c3c;
    color: #fff;
    text-align: center;
    transform: rotate(-44deg);
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
}

.progress-bar-container {
    width: 200px;
    height: 20px;
    background-color: #f0f0f0;
    border-radius: 30px;
    overflow: hidden;


}

.progress-bars {
    width: 30%;
    height: 20px;
    background-color: #2ecc71;
    animation: progressAnimation 2s ease-out forwards;

}


@keyframes progressAnimation {
    from {
        width: 0%;
    }

    to {
        width: 30%;
    }
}

.view-progress {
    text-decoration: none;
    color: #2ecc71;
    text-align: center;
    font-weight: 700;
}
</style>

<!-- subjects -->
<style>
.main-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;

}

.profile-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.profile-info {
    display: flex;
    align-items: center;
}

.profile-icon {
    float: right;
    margin-left: 5px;
}

.badge {
    display: inline-block;
    padding: 5px 10px;

    background-color: rgb(255 255 255 / 34%);
    /* Green background color with 50% opacity */
    color: white;
    font-size: 12px;
    border-radius: 5px;
}

.profile-image {
    width: 50px;
    height: 50px;
    margin-right: 5px;
    margin-top: -5px;
    border-radius: 50%;
    overflow: hidden;
    border: solid 1px yellowgreen;

}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-name {
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.profile-grade {
    font-size: 14px;
    color: white;
}

.action-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
}


.rounded-button {
    padding: 8px 30px;
    border-radius: 20px;
    margin: 0 10px;
    background-color: #ab2e7e;
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
}

.action-buttons a:hover {
    color: #fff;
}

.content-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
}

.center-icon {
    font-size: 24px;
    color: white;
    margin-bottom: 5px;
}

.rounded-div {
    width: calc(33.33% - 20px);
    margin: 10px;
    padding: 20px;
    border-radius: 17px;
    background-color: #d3d3d3;
    text-align: center;
    transition: transform 0.3s;
}

.rounded-div img {
    max-width: 55%;
    max-height: 55%;
    border-radius: 50%;
    margin-bottom: 5px;
}

.subject-name {
    font-size: 14px;
    font-weight: bold;
    color: whitesmoke;
    max-height: 34px;
    overflow: hidden;
}

.student-name {
    font-size: 12px;
    color: lightgray;
}

.rounded-div:hover {
    transform: scale(1.05);
}


.rounded-div:nth-child(1) {
    background-color: #3498db;
}

.rounded-div:nth-child(2) {
    background-color: #e74c3c;
}

.rounded-div:nth-child(3) {
    background-color: #2ecc71;
}

.rounded-div:nth-child(4) {
    background-color: #f39c12;
}

.rounded-div:nth-child(5) {
    background-color: #9b59b6;
}

.rounded-div:nth-child(6) {
    background-color: #1abc9c;
}

.rounded-div:nth-child(7) {
    background-color: #e67e22;
}

.rounded-div:nth-child(8) {
    background-color: #95a5a6;
}

.rounded-div:nth-child(9) {
    background-color: #d35400;
}

.chat-popup {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #fff;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: none;
}

.chat-message {
    font-size: 16px;
    color: #333;
}

.chat-close {
    position: absolute;
    top: 5px;
    right: 5px;
    cursor: pointer;
}

.show {
    opacity: 1;
}

button.nav-link {
    float: left;
}
.row.chakra_view {
    background: url("<?php echo base_url() . "assets/images/bgimg.png" ?>");
    /* background-size: 400px;
    background-repeat: no-repeat;
    background-position: right bottom;
    min-height: 500px; */
    background-size: 500px;
    background-repeat: no-repeat;
    background-position: right bottom;
    min-height: 476px;
}
</style>
<!-- subjects -->

<?php
$placeholder = base_url() . "assets/uploads/logo/flower.png";
function countChakras($unit_id, $obj)
{

    $school_id = $_SESSION['school_id'];
    $obj->db->select('id');
    $obj->db->from('m_course_relation');
    $obj->db->where('unit_id', $unit_id);
    $obj->db->where('school_id', $school_id);
    $query = $obj->db->get();
    $total_chakras_in_unit = $query->num_rows();


    return $total_chakras_in_unit;
}


function generateRandomColor()
{
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}

function checkResults($chakra_id, $obj)
{
    // echo"<pre>";
            // print_r($_SESSION['user_id']);
            // die();
    $school_id = $_SESSION['school_id'];
     $student_id = $_SESSION['user_id'];
    $obj->db->select('*');
    $obj->db->from('m_course_result');
    $obj->db->where('chakra_id', $chakra_id);
    $obj->db->where('school_id', $school_id);
    $obj->db->where('student_id', $student_id);
    $query = $obj->db->get();
    $result = $query->row_array();
    //return $result;
    if (!empty($result)) {
        return true;
    } else {
        return false;
    }
}
?>
<link rel="stylesheet" href="<?php echo  base_url();?>/assets1/css/style.css">
<link rel="stylesheet" href="<?php echo base_url()?>/assets1/css/device.css">
<link rel="stylesheet" href="<?php echo base_url()?>/assets1/css/fontawesome-all.min.css">

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">

        <?php
        if (isset($today_chakras)) {
        ?>
        <div class="x_panel">

            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small>
                        <?php echo $this->lang->line('todays_chakras');?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content">
                <div class="row ">
                    <div class="col-md-4 col-sm-4 col-xs-4">

                        <div class="slides-list">
                            <br>
                            <div class="slides-title">Chakra Title</div>

                            <?php

                                foreach ($todays_chakras_list as $obj) {

                                    $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                                    $base_url = base_url($obj->path);
                                    echo '<div class="slide-button" style="background-color: ' . $randomColor . ';"><a href="#" target="_blank">' . $obj->_name . '</a></div>';
                                }
                                ?>
                        </div>

                    </div>

                    <div class="col-md-8 col-sm-8 col-xs-8">
                        <div class="play-circle">
                            <a href=""> <img src="<?php echo base_url('/assets/images/play.gif') ?>"
                                    class="play-image"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
        <style>
        .itemWrap{
            margin-top:30px;
        }
    
        .homePageWrap {
            width: 100%;
            margin: 0px auto;
            padding: 60px 0 0;
            background-color: #ffffff;
        }

        .homeDataWrap .subjectsListTab .itemWrap .dataWrap h2 {
            color: #000000;
            font-size: 1.3rem;
            /* font-weight: 400; */
            font-weight: bold;
            letter-spacing: 0.1px;
        }

        .icoWrap-name {
            width: 100px;
            height: 100px;
            border: 4px solid #ffffff;
            border-radius: 100%;
            box-shadow: 0px 4px 4px 0 rgba(0, 0, 0, 0.12);
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
        }

        /* .icoWrap-json {
            width: 100px;
            height: 100px;
            border: 4px solid #ffffff;
            border-radius: 100%;
            box-shadow: 0px 4px 4px 0 rgba(0, 0, 0, 0.12);
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
        } */

        .dataWrap h2 {
            color: #000000;
            font-size: 1.3rem;
            text-align: center;
            margin: 10px auto 0;
            font-weight: bold;
            letter-spacing: 0.1px;
        }

        .play-circle {
            position: relative;
        }

        .button-text {
            position: absolute;
            top: 18%;
            left: 50%;
            font-weight: bold;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            font-size: 16px;
        }

        .button-text-second {
            position: absolute;
            top: 82%;
            left: 50%;
            /* font-weight: bold; */
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            font-size: 16px;
        }


        .itemWrap .circularDataWrap {
            background-color: #B5AAEB;
            border: 3px solid #ffffff;
            box-shadow: 0px 6px 9px -3px rgba(0, 0, 0, 0.20);
            width: 180px;
            height: 180px;
            border-radius: 50%;
            margin: 0 auto;
        }

        .circularDataWrap .dataWrap {
            text-align: center;
            margin: 0 auto;
            padding: 45px 20px 26px 20px;
            display: flex;
            flex-flow: column;
            justify-content: space-between;
            align-items: center;
            height: 100%;
        }

        .circularDataWrap .dataWrap h2 {
            color: #000000;
            font-size: 1.4rem;
            line-height: 20px;
            margin: 0 auto;
            min-height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        </style>
        <style>
        .progressListWrap ul.progressSlider li .itemWrap {
            background-color: #DBDAFB;
            box-shadow: 0px 2px 6px 0px rgba(0, 0, 0, 0.15);
            border-radius: 10px;
            display: flex;
            /* float: left; */
            /* flex-flow: column; */
            align-items: center;
            justify-content: space-between;
            min-height: 300px;
            margin: 20px;
            padding: 20px;
        }

        .progressListWrap ul.progressSlider li .itemWrap .progress-bar {
            transition: width 0.3s ease-in-out;
            /* Optional: Add a transition effect for smooth changes */
        }

        .left-aligned-image {
            float: right;
            margin-right: 10px;
        }

        .x_panel {
            position: relative;
            width: 100%;
            min-height: 100vh;
            margin-bottom: 10px;
            padding: 5px 17px;
            display: inline-block;
            background: #fff;
            border: 1px solid #E6E9ED;
            -webkit-column-break-inside: avoid;
            -moz-column-break-inside: avoid;
            column-break-inside: avoid;
            opacity: 1;
            transition: all .2s ease;
        }
        .middleData progress {
    height: 30px;}
    </style>
    <style>
    .button-link {
        display: inline-block;
        padding: 10px 20px;
        background-color: #800080; /* Green background color */
        color: white; /* White text color */
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 20px;
    }
    img.sub_icon_chakra {
    padding-top: 50px;
    }
    .homeDataWrap .tabChakra .itemWrap {
    text-align: center;
    margin: 10px auto;
    position: relative;
   }
  img.sub_icon_chakras {
    padding-top: 50px;
    }
  /*   .homeDataWrap .tabChakras .itemWrap {*/
  /*  text-align: center;*/
  /*  margin: 10px auto;*/
  /*  position: relative;*/
    </style>
        <?php if (isset($list)) { ?>
        <div class="x_panel">
            <div class="mainContent homePageWrap">
                <div class="homeDataWrap">
                    <div class="container">
                        <div class="row justify-content-center pt-5">
                            <div class="col-md-12">
                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <button onclick="handleClick()" class="nav-link active" data-bs-toggle="tab"
                                            data-bs-target="#todaysChakras" type="button" role="tab"
                                            aria-controls="todaysChakras" aria-selected="true">Today’s Chakras</button>
                                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#subjects"
                                            type="button" role="tab" aria-controls="subjects"
                                            aria-selected="false">Subjects</button>
                                            <button onclick="handleClick()" class="nav-link" data-bs-toggle="tab" data-bs-target="#chackra"
                                            type="button" role="tab" aria-controls="chackra"
                                            aria-selected="false">All Chakra</button>
                                    </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade active show tabChakra" id="todaysChakras" role="tabpanel">
                                        <?php
                                        
                                        foreach ($today_chackra_list as $obj) {  
                                            // Check if the status is zero (assuming status is a property of $obj)
                                            // print_r($obj);
                                            $isLocked = ($obj->status == 0);
                                            $icon = '&#128274;'; // Lock icon
                                        ?>
                                        
                                        <div class="col-md-4">
                                            <?php if ($isLocked) { ?>
                                                <div class="itemWrap locked">
                                                    <div class="topDataWrap">
                                                        <h2 class="curved-text"><?php echo $obj->subjectName; ?></h2>
                                                    </div>
                                                    <div class="circularDataWrap">
                                                        <div class="dataWrap">
                                                            <h2><?php echo $obj->name; ?></h2>
                                                            <p>Inactive on: <br /> <span><?php echo $obj->inactive_time; ?></span></p>
                                                            <!--<p>Inactive: <span><?php echo date('M j, Y g:i A', strtotime($obj->inactive_time)); ?></span></p>-->
                                                            <div class="sub_icon_wrapper">
                                                                <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/lock.png" ?>" alt="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } else { ?>
                                            
                                                <a href="story_line/<?php echo $obj->chakra_id; ?>">
                                                    <div class="itemWrap">
                                                        <div class="topDataWrap">
                                                            <h2 class="curved-text"><?php echo $obj->subjectName; ?></h2>
                                                        </div>
                                                        <div class="circularDataWrap">
                                                            <div class="dataWrap">
                                                                <h2><?php echo $obj->name; ?></h2>
                                                                <p>Active on: <br /> <span><?php echo $obj->active_time; ?></span></p>
                                                                <!--<p>Active on: <br /> <span><?php echo date('F j, Y g:i A', strtotime($obj->active_time)); ?></span></p>-->
                                                                <div class="sub_icon_wrapper">
                                                                    
                                                                    <?php 
                                                                     $chakra_exists = checkResults($obj->chakra_id, $this);
                                                                    
                                                                    if(!empty($chakra_exists)){ ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/right.png" ?>" alt="">
                                                                        <?php } elseif ($obj->status == 1)   { ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/foundation_burst-new.png" ?>" alt="">
                                                                        <?php  } else { ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/lock.png" ?>" alt="">
                                                                        <?php } ?>
                                                                    <!--<img class="sub_icon_chakra" src="<?php echo base_url() . "assets/images/foundation_burst-new.png" ?>" alt="">-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            <?php } ?>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="tab-pane fade subjectsListTab" id="subjects" role="tabpanel">
                                        <div class="row">
                                            <?php foreach ($subject_list as $obj) {  $randomColor = sprintf('#%06X', mt_rand(0, 0xFF0000));?>
                                            <div class="col-md-4">
                                                <a
                                                    href="<?php echo  site_url(); ?>/administrator/usercourse/volume/<?php echo $obj->subject_id; ?>">
                                                    <div class="itemWrap">
                                                        <div class="icoWrap"
                                                            style="background:<?php echo $randomColor; ?>">
                                                            <span class="sub_let">
                                                                <?php echo substr($obj->_name, 0, 1); ?><span>
                                                        </div>
                                                        <div class="dataWrap">
                                                            <h2><?php echo $obj->_name; ?></h2>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php }?>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade tabChakra"  id="chackra" role="tabpanel" >
                                        <?php
                                        foreach ($total_chackra_list as $obj) {  
                                            // print_r($obj);
                                            $isLocked = ($obj->status == 0);
                                            $icon = '&#128274;'; // Lock icon
                                        ?>
                                        
                                        <div class="col-md-4">
                                            <?php if ($isLocked) { ?>
                                                <div class="itemWrap locked">
                                                    <div class="topDataWrap">
                                                        <h2 class="curved-text"><?php echo $obj->subjectName; ?></h2>
                                                    </div>
                                                    <div class="circularDataWrap">
                                                        <div class="dataWrap">
                                                            <h2><?php echo $obj->name; ?></h2>
                                                            <p>Inactive on: <br /> <span><?php echo $obj->inactive_time; ?></span></p>
                                                            <!--<p>Inactive on: <br /> <span><?php echo date('F j, Y g:i A', strtotime($obj->inactive_time)); ?></span></p>-->
                                                            <div class="sub_icon_wrapper">
                                                                <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/lock.png" ?>" alt="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } else { ?>
                                            
                                                <a href="story_line/<?php echo $obj->chakra_id; ?>">
                                                    <div class="itemWrap">
                                                        <div class="topDataWrap">
                                                            <h2 class="curved-text"><?php echo $obj->subjectName; ?></h2>
                                                        </div>
                                                        <div class="circularDataWrap">
                                                            <div class="dataWrap">
                                                                <h2><?php echo $obj->name; ?></h2>
                                                                <p>Active on: <br /> <span><?php echo $obj->active_time; ?></span></p>
                                                                <!--<p>Active on: <br /> <span><?php echo date('F j, Y g:i A', strtotime($obj->active_time)); ?></span></p>-->
                                                                <div class="sub_icon_wrapper">
                                                                    
                                                                    <?php 
                                                                     $chakra_exists = checkResults($obj->chakra_id, $this);
                                                                    
                                                                    if(!empty($chakra_exists)){ ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/right.png" ?>" alt="">
                                                                        <?php } elseif ($obj->status == 1)   { ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/foundation_burst-new.png" ?>" alt="">
                                                                        <?php  } else { ?>
                                                                        <img class="sub_icon_chakras" src="<?php echo base_url() . "assets/images/lock.png" ?>" alt="">
                                                                        <?php } ?>
                                                                    <!--<img class="sub_icon_chakra" src="<?php echo base_url() . "assets/images/foundation_burst-new.png" ?>" alt="">-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            <?php } ?>
                                        </div>
                                        <?php } ?>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php } ?>
<?php if (isset($list_volume)) { ?>
<div class="x_panel">
    <div class="x_content">
           <h3 class="head-title">
                <a href="javascript:history.go(-1);" class="button-link">
                    <strong>&lt; Previous</strong>
                </a>
            </h3>
        <div class="row home_top_mar">
            <?php foreach ($volume_list as $obj) {  $randomColor = sprintf('#%06X', mt_rand(0, 0xFF0000));?>
            <div class="col-md-4">
                <a href="<?php echo  site_url(); ?>/administrator/usercourse/unit/<?php echo $obj->volume_id; ?>">
                    <div class="itemWrap">
                        <div class="icoWrap-name" style="background:<?php echo $randomColor; ?>">
                            <span class="sub_let">
                                <?php echo substr($obj->_name, 0, 1); ?><span>
                        </div>
                        <div class="dataWrap">
                            <h2><?php echo $obj->_name; ?></h2>
                        </div>
                    </div>
                </a>
            </div>
            <?php }?>
        </div>
    </div>
</div>
<?php } ?>
<?php if (isset($lessons_list)) { ?>
<div class="x_panel">
    <div class="x_content">
        <h3 class="head-title">
            <a href="javascript:history.go(-1);" class="button-link">
                <strong>&lt; Previous</strong>
            </a>
        </h3>
        <div class="row home_top_mar">
            <?php foreach ($lessons_list as $obj) {  $randomColor = sprintf('#%06X', mt_rand(0, 0xFF0000));?>
            <div class="col-md-4">
                <a href="<?php echo  site_url(); ?>/administrator/usercourse/chakra/<?php echo $obj->lessons_id; ?>">
                    <div class="itemWrap">
                        <div class="icoWrap-name" style="background:<?php echo $randomColor; ?>">
                            <span class="sub_let">
                                <?php echo substr($obj->_name, 0, 1); ?><span>
                        </div>
                        <div class="dataWrap">
                            <h2><?php echo $obj->_name; ?></h2>
                        </div>
                    </div>
                </a>
            </div>
            <?php }?>
        </div>
    </div>
</div>
<?php } ?>
<?php if (isset($list_unit)) { ?>

<div class="x_panel">
<h3 class="head-title">
    <a href="javascript:history.go(-1);" class="button-link">
        <strong>&lt; Previous</strong>
    </a>
</h3>

<div class="progressListWrap">
    <div class="container">
        <div class="row ">
            <div class="col-md-12">
                <ul class="progressSlider">
                    <?php  foreach ($unit_list as $obj) {  ?>
                   
                    <li>           
                        <div class="itemWrap completed">
                            <div class="topData">
                                <h2><?php echo $obj->_name; ?></h2>
                                <?php if($obj->result_count==$obj->total_chakra){ echo '<h4 >Completed</h4>';}else echo '<h4 style="background-color: red;">InCompleted</h4>'  ?>
                                       
                            </div>
                           
                            <div class="middleData">
                                <h3><span> <?php
           
                          ?><?php echo $obj->result_count.'/'.$obj->total_chakra; ?></span> <br /> Chakras</h3>

                                <progress value="<?php echo $obj->result_count?>" max="<?php echo $obj->total_chakra?>">
                                </progress>

                            </div>
                            <div class="btmData">
                                <a href="<?php echo  site_url(); ?>/administrator/usercourse/lessons/<?php echo $obj->unit_id; ?>">View Chakras</a>
                            </div>
                        </div>
                        </li>

                    <?php } ?>
                </ul>
            </div>
        </div>

    </div>
</div>
</div>
<?php } ?>
<?php if (isset($chakra_list) ) { ?>
<div class="x_panel">
<h3 class="head-title">
    <a href="javascript:history.go(-1);" class="button-link">
        <strong>&lt; Previous</strong>
    </a>
</h3>

    <div class="row home_top_mar">

        <?php foreach ($chakra_list as $obj) {
            // echo"<pre>";
            // print_r($obj);
            // die();
    $user_exits = checkResults($obj->chakra_id, $this);
    $currentTime = new DateTime();
    $activeTime = new DateTime($obj->active_time);
    $inActiveTime = new DateTime($obj->inactive_time);

    if ($obj->status == 1) {

        if ($user_exits) {
            $icon = '&#x2714;'; //marked;
        } else {
            $icon = '<div class="badge">NEW</div>'; //new
        }
    } else if ($obj->status == 0 || $currentTime >= $activeTime && $currentTime <= $inActiveTime) {
        $icon = '&#128274;'; //lock
    }


    $content = $obj->_description;
    $contentWithoutTags = strip_tags($content);
    $words = explode(' ', $contentWithoutTags);
    $limitedDescription = implode(' ', array_slice($words, 0, 70));?>
        <div class="col-md-4">
            <div class="itemWrap">
                <!-- <div class="topDataWrap">
                <h2 id="curved"><?php echo $obj->_name; ?></h2>
            </div> -->
                <div class="circularDataWrap">
                    <div class="dataWrap">
                        <a  href="<?php if ($obj->status == 1)   {  echo  site_url(); ?>/administrator/usercourse/story_line/<?php echo $obj->chakra_id; } else echo "#"?>">
                            <div class="subject-name"><?php echo $obj->_name; ?>
                            </div>

                            <div class="subject-name">
                                <?php echo 'Start: ' . date('Y-m-d', strtotime($obj->active_time)); ?>
                            </div>
                            <div class="subject-name">
                                <?php echo 'End: ' . date('Y-m-d', strtotime($obj->active_time)); ?>
                            </div>
                        </a>

                    </div>
                    <div class="chakra-dataWrap" style="">
                        <?php 
                     $chakra_exists = checkResults($obj->chakra_id, $this);
                    
                    if(!empty($chakra_exists)){ ?>
                        <img class="sub_icon" src="<?php echo base_url() . "assets/images/right.png" ?>" alt="">
                        <?php } elseif ($obj->status == 1)   { ?>
                        <img class="sub_icon" src="<?php echo base_url() . "assets/images/foundation_burst-new.png" ?>" alt="">
                        <?php  } else { ?>
                        <img class="sub_icon" src="<?php echo base_url() . "assets/images/lock.png" ?>" alt="">
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
    
    </div>
    <?php } ?>



    <?php if (isset($story_line) && $story_line) { ?>
    <div class="x_panel">
        <h3 class="head-title">
            <a href="javascript:history.go(-1);" class="button-link">
                <strong>&lt; Previous</strong>
            </a>
        </h3><br><br>

        <h3 class="head-title"><strong><?php echo $story_line_data->title; ?> </strong><br></small>
        </h3><br>

        <div class="x_content">
            <div class="row chakra_view">
                <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="slides-list">
                        <br><?php if($story_line_files){ ?>
                        <div class="slides-title">Download Attached file:</div>
                        <?php }

                                foreach ($story_line_files as $obj) {

                                    $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                                    $base_url = base_url($obj->path);
                                    echo '<div class="slide-button" style="background-color: ' . $randomColor . ';"><a href="' . $base_url . '" target="_blank">' . $obj->file_name . '</a></div>';
                                }
                                ?>
                    </div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="play-circle">
                        <a href="<?php echo base_url(); ?>administrator/usercourse/story_view/<?php echo $story_line_data->id; ?>">
                            <img src="<?php echo base_url('assets/images/playr.png') ?>" class="play-image">
                            <p class="button-text">Check your Knowledge</p>
                            <p class="button-text-second">Time to apply our leranings
                                and test
                                ourselves!</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php } ?>
<?php if (isset($story_view) && $story_view) { ?>
<div class="x_panel">
    <div class="x_title">
       <h3 class="head-title">
            <a href="javascript:history.go(-1);" class="button-link">
                <strong>&lt; Previous</strong>
            </a>
        </h3>
<br>

        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
        </ul>
        <div class="clearfix"></div>
    </div>

    <div class="x_content">
        <?php if ($story_view_data->file) { ?>

        <iframe src="<?php echo base_url($story_view_data->file); ?>/story.html" class="storyline"
            title="<?php echo $story_view_data->title; ?>"></iframe>

        <?php } else { ?>
        <h3> Data Not Found</h3>
        <?php } ?>
    </div>
</div>
<?php } ?>
</div>

</div>

<script src="<?php echo base_url()?>/assets1/js/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
function rotateText() {
    const textElements = document.querySelectorAll(".text p");

    textElements.forEach((text) => {
        text.innerHTML = text.innerText
            .split("")
            .map(
                (char, i) =>
                `<span style="transform:rotate(${i * 5.8}deg)">${char}</span>`
            )
            .join("");
    });
}

rotateText();
</script>
<script src="<?php echo base_url()?>/assets1/js/popper.min.js"></script>
<script src="<?php echo base_url()?>/assets1/js/bootstrap/js/bootstrap.bundle.min.js">
</script>
<script src="https://kit.fontawesome.com/4ebc3bb295.js" crossorigin="anonymous"></script>
<script src="<?php echo base_url()?>/assets1/js/wow.js"></script>
<script src="<?php echo base_url()?>/assets1/js/aos.js"></script>
<script src="<?php echo base_url()?>/assets1/js/slick.min.js"></script>
<script src="<?php echo base_url()?>/assets1/js/slick-animation.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lettering.js/0.6.1/jquery.lettering.min.js">
</script>
<script src="<?php echo base_url()?>/assets1/js/main.js"></script>
<script>
$.fn.circleType = function(options) {

    var settings = {
        dir: 1,
        position: 'relative'
    };
    if (typeof($.fn.lettering) !== 'function') {
        console.log('Lettering.js is required');
        return;
    }
    return this.each(function() {

        if (options) {
            $.extend(settings, options);
        }
        var elem = this,
            delta = (180 / Math.PI),
            ch = parseInt($(elem).css('line-height'), 10),
            fs = parseInt($(elem).css('font-size'), 10),
            txt = elem.innerHTML.replace(/^\s+|\s+$/g, '').replace(/\s/g,
                '&nbsp;'),
            letters,
            center;

        elem.innerHTML = txt
        $(elem).lettering();

        elem.style.position = settings.position;

        letters = elem.getElementsByTagName('span');
        center = Math.floor(letters.length / 2)

        var layout = function() {
            var tw = 0,
                i,
                offset = 0,
                minRadius,
                origin,
                innerRadius,
                l, style, r, transform;

            for (i = 0; i < letters.length; i++) {
                tw += letters[i].offsetWidth;
            }
            minRadius = (tw / Math.PI) / 2 + ch;

            if (settings.fluid && !settings.fitText) {
                settings.radius = Math.max(elem.offsetWidth / 2, minRadius);
            } else if (!settings.radius) {
                settings.radius = minRadius;
            }

            if (settings.dir === -1) {
                origin = 'center ' + (-settings.radius + ch) / fs + 'em';
            } else {
                origin = 'center ' + settings.radius / fs + 'em';
            }

            innerRadius = settings.radius - ch;

            for (i = 0; i < letters.length; i++) {
                l = letters[i];
                offset += l.offsetWidth / 1.4 / innerRadius * delta;
                l.rot = offset;
                offset += l.offsetWidth / 1.4 / innerRadius * delta;
            }
            for (i = 0; i < letters.length; i++) {
                l = letters[i]
                style = l.style
                r = (-offset * settings.dir / 2) + l.rot * settings.dir
                transform = 'rotate(' + r + 'deg)';

                style.position = 'absolute';
                style.left = '50%';
                style.marginLeft = -(l.offsetWidth / 2) / fs + 'em';

                style.webkitTransform = transform;
                style.MozTransform = transform;
                style.OTransform = transform;
                style.msTransform = transform;
                style.transform = transform;

                style.webkitTransformOrigin = origin;
                style.MozTransformOrigin = origin;
                style.OTransformOrigin = origin;
                style.msTransformOrigin = origin;
                style.transformOrigin = origin;
                if (settings.dir === -1) {
                    style.bottom = 0;
                }
            }

            if (settings.fitText) {
                if (typeof($.fn.fitText) !== 'function') {
                    console.log(
                        'FitText.js is required when using the fitText option'
                    );
                } else {
                    $(elem).fitText();
                    $(window).resize(function() {
                        updateHeight();
                    });
                }
            }
            updateHeight();
        };

        var getBounds = function(elem) {
            var docElem = document.documentElement,
                box = elem.getBoundingClientRect();
            return {
                top: box.top + window.pageYOffset - docElem.clientTop,
                left: box.left + window.pageXOffset - docElem.clientLeft,
                height: box.height
            };
        };

        var updateHeight = function() {
            var mid = getBounds(letters[center]),
                first = getBounds(letters[0]),
                h;
            if (mid.top < first.top) {
                h = first.top - mid.top + first.height;
            } else {
                h = mid.top - first.top + first.height;
            }
            elem.style.height = h + 'px';
        }

        if (settings.fluid && !settings.fitText) {
            $(window).resize(function() {
                layout();
            });
        }

        if (document.readyState !== "complete") {
            elem.style.visibility = 'hidden';
            $(window).load(function() {
                elem.style.visibility = 'visible';
                layout();
            });
        } else {
            layout();
        }
    });
};

$('#curved').circleType({
    position: 'absolute',
    dir: 1,
    radius: 130
});
$('.curved-text').circleType({
    position: 'absolute',
    dir: 1,
    radius: 130
});
// function handleClick() {
//     console.log("kkkk");
    
//     $('.curved-text').circleType({
//         position: 'absolute',
//         dir: 1,
//         radius: 130
//     });
// }

function applyCircleType() {
    $('.curved-text').circleType({
        position: 'absolute',
        dir: 1,
        radius: 130
    });
}

function handleClick() {
    console.log("kkkk");
    
    // Use setTimeout to delay the execution of applyCircleType by 1000 milliseconds (1 second)
    setTimeout(function() {
        applyCircleType();
    }, 300);
}

$(document).ready(function() {
    // Call the applyCircleType function when the document is ready
    applyCircleType();
});
</script>
