<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small><?php echo $this->lang->line('manage_report'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="row bg">
                    <?php foreach ($results as $result) { ?>
                        <div class="col-md-6">
                            <div class="rounded-div">
                                <div class="result-info">
                                    <p>Date / Time: <?php echo date('F j, Y', strtotime($result->time_finished)); ?><br>
                                    <?php echo date('h:i a', strtotime($result->time_finished)); ?></p>
                                </div>
                                <div class="result-score">
                                    <p>Student Score: <?php echo $result->score; ?><br>
                                    Passing Score: <?php echo $result->passing_score; ?><br>
                                    Result: <?php echo ($result->score >= $result->passing_score) ? 'Pass' : 'Fail'; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
