 <?php
 if(!empty($chakras)){     
       
  foreach ($chakras as $chakra) { 
            
             ?>
 <li>
     <a href="#">
         <div class="itemWrap completed">
             <div class="topData">
                 <h2 class="text-center "><?php echo $chakra->course_name; ?>
                 </h2>
                 <?php if ($chakra->result_id) { ?>
                 <?php echo '<h4 style="background-color: green;">COMPLETED</h4>'; ?>
                 <?php } else { ?>
                 <?php echo '<h4 style="background-color: red;">INCOMPLETED</h4>'; ?>
                 <?php } ?>
             </div>
             </br>


             <p class="middle_content">
                 <?php echo 'Active: ' . date('Y-m-d', strtotime($chakra->active_time)); ?>
             </p>
             <p class="middle_content">
                 <?php echo 'Inactive: ' . date('Y-m-d', strtotime($chakra->inactive_time)); ?>
             </p>
             <?php if ($chakra->result_id) { ?>
             <div class="res_progress">
                 <p>Score:</p>
                 <div class="progress-container">
                     <progress style="appearance: none; height: 10px; width: 80%;"
                         value="<?php echo $chakra->result_pt ?>" max="100"
                         class="<?php echo $chakra->result_pt >= 50 ? 'progress-green' : 'progress-red'; ?>"></progress>
                     <span class="percentage"><?php echo $chakra->result_pt ?>%</span>
                 </div>

             </div><?php }?>
     </a>
 </li>
 <?php } }else{ ?>
 <li>Data not found! </li>
 <?php } ?>