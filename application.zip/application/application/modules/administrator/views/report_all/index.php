<link rel="stylesheet" href="<?php echo  base_url();?>/assets1/css/style.css">
<link rel="stylesheet" href="<?php echo base_url()?>/assets1/css/device.css">
<link rel="stylesheet" href="<?php echo base_url()?>/assets1/css/fontawesome-all.min.css">
<style>
    .button-link {
        display: inline-block;
        padding: 10px 20px;
        background-color: #800080; /* Green background color */
        color: white; /* White text color */
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 20px;
    }
    </style>

<style>
.progress-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 10px;
    margin-top: 10px;
}

/* Style for the percentage display */
.percentage {
    margin-left: 5px;
    /* Adjust the margin as needed */
}

.progressListWrap ul.progressSlider li .itemWrap {
    background-color: #DBDAFB;
    box-shadow: 0px 2px 6px 0px rgba(0, 0, 0, 0.15);
    border-radius: 10px;
    display: flex;
    float: left;
    width: 240px;
    flex-flow: column;
    align-items: baseline;
    /* justify-content: space-between; */
    min-height: 300px;
    margin: 15px;
    padding: 20px;
}

.progressListWrap ul.progressSlider li .itemWrap .middleData h3 {
    align-items: center !important;

}

.middle_content {
    /* text-align: center; */
    /* margin-bottom: -30px; */
}

.status {
    margin-bottom: 10px;
}
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">

        <?php if($this->session->userdata('role_id') != STUDENT && $this->session->userdata('role_id') != GUARDIAN){ ?>

        <div class="x_content">
            <div class="" data-example-id="togglable-tabs">
                <ul class="nav nav-tabs bordered">
                    <?php  ?>
                    <li class="<?php if(isset($list)){ echo 'active'; }?> "><a href="#tab_state_list" role="tab"
                            data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                            <?php echo $this->lang->line('list'); ?></a> </li>
                    <?php ?>
                </ul>
                <br />

                <div class="tab-content">
                    <div class="tab-pane fade in active" id="tab_state_list">
                        <div class="x_content filter-box no-print">
                            <div class="row">
                                <div class="x_content filter-box no-print">
                                    <div class="row">
                                        <?php echo form_open_multipart(site_url('administrator/report_all/'), array('name' => 'index', 'id' => 'index', 'class'=>'form-horizontal form-label-left'), ''); ?>
                                        <?php echo form_open('report_all/');?>
                                        <?php if($this->session->userdata('role_id') == SUPER_ADMIN){ ?>

                                        <div class="col-md-2 col-sm-2 col-xs-12">
                                            <div class="item form-group">
                                                <div><?php echo $this->lang->line('school'); ?> <span
                                                        class="red">*</span></div>
                                                <select class="form-control col-md-7 col-xs-12" name="school_id"
                                                    id="school_id" required="required">

                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                    <?php foreach ($school_list as $obj) { ?>
                                                    <option value="<?php echo $obj->id; ?>">
                                                        <?php echo $obj->school_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <?php if($this->session->userdata('role_id') != SUPER_ADMIN){ ?>

                                        <div class="col-md-2 col-sm-2 col-xs-12">
                                            <div class="item form-group">
                                                <div><?php echo $this->lang->line('school'); ?> <span
                                                        class="red">*</span></div>
                                                <select class="form-control col-md-7 col-xs-12" name="school_id"
                                                    id="school_id" required="required">

                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                    <?php echo $this->session->userdata('school_id') ?>
                                                    <option value="<?php echo $this->session->userdata('school_id') ?>">
                                                        <?php echo $this->session->userdata('school_name') ?>
                                                    </option>
                                                    <?php ?>
                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>

                                        <div class="col-md-2 col-sm-2 col-xs-12">
                                            <div class="item form-group">
                                                <div><?php echo $this->lang->line('class'); ?> <span
                                                        class="red">*</span></div>
                                                <select class="form-control col-md-7 col-xs-12" name="class_id"
                                                    id="class_id" required="required" s>
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                    <?php foreach ($classes as $obj) { ?>
                                                    <option value="<?php echo $obj->id; ?>"
                                                        <?php if(isset($class_id) && $class_id == $obj->id){ echo 'selected="selected"';} ?>>
                                                        <?php echo $obj->name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-2 col-sm-2 col-xs-12">
                                            <div class="form-group"><br />
                                                <button id="send" type="submit"
                                                    class="btn btn-success"><?php echo $this->lang->line('find'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>

                                <div class="x_content">
                                    <table id="datatable-responsive"
                                        class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo $this->lang->line('sl_no'); ?></th>
                                                <th><?php echo $this->lang->line('school_name'); ?></th>
                                                <th><?php echo $this->lang->line('student_name'); ?></th>
                                                <th><?php echo $this->lang->line('class'); ?></th>
                                                <th><?php echo $this->lang->line('score'); ?></th>
                                                <th><?php echo $this->lang->line('passing_score'); ?></th>
                                                <th><?php echo $this->lang->line('time_finished'); ?></th>
                                                <th><?php echo $this->lang->line('incorrect_q'); ?></th>
                                                <th><?php echo $this->lang->line('total_q'); ?></th>
                                                <th><?php echo $this->lang->line('quiz_name'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                if (($course_results) && !empty($course_results)) {
                                                    $count = 1; 
                                                    $school_id = $this->session->userdata('school_id');
                                                    foreach ($course_results as $result) {
                                                        
                                                       if($school_id == $result->school_id){
                                                ?>
                                            <tr>
                                                <td><?php echo $count++; ?></td>
                                                <td><?php echo $result->school_name; ?><?php echo $result->school_name; ?></td>
                                                <td><?php echo $result->student_name; ?></td>
                                                <td><?php echo $result->class; ?></td>
                                                <td><?php echo $result->score; ?></td>
                                                <td><?php echo $result->passing_score; ?></td>
                                                <td><?php echo $result->time_finished; ?></td>
                                                <td><?php echo $result->incorrect_q; ?></td>
                                                <td><?php echo $result->total_q; ?></td>
                                                <td><?php echo $result->quiz_name; ?></td>
                                            </tr>
                                            <?php
                                                       }else if($this->session->userdata('role_id') == SUPER_ADMIN){?>
                                                            <tr>
                                                <td><?php echo $count++; ?></td>
                                                <td><?php echo $result->school_name; ?><?php echo $result->school_name; ?></td>
                                                <td><?php echo $result->student_name; ?></td>
                                                <td><?php echo $result->class; ?></td>
                                                <td><?php echo $result->score; ?></td>
                                                <td><?php echo $result->passing_score; ?></td>
                                                <td><?php echo $result->time_finished; ?></td>
                                                <td><?php echo $result->incorrect_q; ?></td>
                                                <td><?php echo $result->total_q; ?></td>
                                                <td><?php echo $result->quiz_name; ?></td>
                                            </tr>
                                                           
                                                      <?php }
                                                    }
                                                }
                                                ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                            <div class="row no-print">
                                <div class="col-xs-12 text-right">
                                    <button class="btn btn-default " onclick="window.print();"><i
                                            class="fa fa-print"></i>
                                        <?php echo $this->lang->line('print'); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } elseif($this->session->userdata('role_id') != GUARDIAN) { ?>
        <div class="x_content">
            <div class="progressListWrap">
                <div class="container">
                    <div class="row ">
                        <div class="col-md-12">
                            <ul class="progressSlider">
                                <?php 
                                $user_id = $this->session->userdata('user_id'); 
                                foreach ($course_results as $obj) { 
                                if($user_id == $obj->student_id){
                    
                                ?>

                                <li>
                                    <div class="itemWrap completed">
                                        <div class="topData">
                                            <h2 class="text-center "><?php echo $obj->chakreName; ?></h2>
                                            <?php if($obj->passing_score<=$obj->pt_score){ echo '<h4 >Pass</h4>';}else echo '<h4 style="background-color: red;">Fail</h4>'  ?>
                                        </div>

                                        <div class="subject-name"><?php echo $obj->class ."/".$obj->subjectName; ?>
                                        </div>
                                        <div class="subject-name"><?php echo  $obj->quiz_name;  ?> </div>
                                        <p class="ram">Score: <span><?php echo $obj->pt_score; ?>%</span> </p>
                                        <p class="ram">Minimum Passing Score:
                                            <span><?php echo $obj->passing_score; ?>%</span>
                                        </p>
                                        <p class="ram">Correct answer:<span>
                                                <?php echo $obj->correct_q; ?>/<?php echo $obj->total_q; ?></span> </p>
                                        <p class="ram">Completed
                                            at:<span><?php echo date('Y-m-d', strtotime($obj->time_finished)); ?></span>
                                        </p>
                                        <p class="ram">Total Score: <span><?php echo $obj->total_q; ?></span> </p>
                                    </div>
                                </li>

                                <?php } } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } else { ?>
        <?php  $this->session->userdata('role_id') == GUARDIAN ?>
        <div class="x_panel">
            <div class="row homePageWrap">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="main_">
                        <?php foreach ($list_student as $student) { 
                             $random_color = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                            ?>
                        <a href="<?php echo site_url(); ?>/administrator/report_all/student_progress/<?php echo $student->id; ?>">
                            <div class="account-card-outer">
                                <div class="account-card" style="background-color: <?php echo $random_color; ?>">                               
                                </div>
                                <h3 style="font-size: 14px;"><?php echo $student->name ?></h3>
                            </div>
                        </a>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <?php if (isset($subjects)) { ?>
            <div class="mainContent ">
                <div class="progressTop">
                    <div class="container">
                        <h3 class="head-title">
            <a href="javascript:history.go(-1);" class="button-link">
                <strong>&lt; Previous</strong>
            </a>
        </h3><br><br>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="titleWrap">
                                    <h2>Progress</h2>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="selectWrap">
                                    <select id="subject_id">
                                        <?php foreach ($subjects as $subject) { ?>
                                    
                                        <option value="<?php echo $subject->id ?>"><?php echo $subject->name ?></a>
                                        </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="progressListWrap">
                <ul class="progressSlider" id="resultData">

                </ul>
            </div>

            <?php } ?>

          
        </div>
        
    </div>
    <?php } ?>
</div>
<script type="text/javascript">
$('#school_id').on('change', function() {
    var school_id = $(this).val();
    getClass(school_id);
});

function getClass(school_id) {
    if (school_id) {
        console.log('school_id', school_id);
        $('#class_id').empty();

        $.ajax({
            url: "<?php echo site_url('administrator/report_all/get_class'); ?>/" + school_id,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {
                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#class_id').append('<option value="' + value.id + '">' +
                            value.name + '</option>');
                    });
                }
            }
        });
    }
}


$(document).ready(function() {

    $('#datatable-responsive').DataTable({
        dom: 'Bfrtip',
        iDisplayLength: 15,
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
            'pageLength'
        ],
        search: true,
        responsive: true
    });
});
</script>
</div>
<script src="<?php echo base_url()?>/assets1/js/bootstrap/js/bootstrap.bundle.min.js"></script>
<style>
progress::-webkit-progress-bar {
    background-color: #fff;
}

progress.progress-green::-webkit-progress-value {
    background-color: green;
}

progress.progress-red::-webkit-progress-value {
    background-color: red;
    /* Corrected typo */
}

. {

    background-color: #8fd3f4;
    background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"%3E%3Cpath fill="%23ffffff" d="M0 192l48-5.3C96 181 192 171 288 181.3c96 10.7 192 42.7 288 58.7C672 267 768 267 864 261.3c96-5.7 192-21.7 288-37.4s192-32.7 240-37.4l48-5.3v320H0z"%3E%3C/path%3E%3C/svg%3E');
    background-size: cover;
}

.titleWrap h2 {
    /* text-align: left ; */
    margin-left: -25px;
    font-weight: 500;
    font-size: 3.4rem;
}

h3 {
    color: #2c3e50;
    text-align: center;

}


.make_center {
    align-items: center !important;
    text-align: center !important;
}


.ribbon-container {
    position: relative;
    width: 100px;
    height: auto;

}

.ribbon {
    position: absolute;
    top: -14px;
    left: -36px;
    width: 107px;
    padding: 5px;
    background-color: #e74c3c;
    color: #fff;
    text-align: center;
    transform: rotate(-44deg);
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
}

.progress-bar-container {
    width: 200px;
    height: 20px;
    background-color: #f0f0f0;
    border-radius: 30px;
    overflow: hidden;


}

.progress-bar {
    width: 30%;
    height: 20px;
    background-color: #2ecc71;
    animation: progressAnimation 2s ease-out forwards;

}

.ram {
    color: black;
}

@keyframes progressAnimation {
    from {
        width: 0%;
    }

    to {
        width: 30%;
    }
}

.view-progress {
    text-decoration: none;
    color: #2ecc71;
    text-align: center;
    font-weight: 700;
}

.chakra-dataWrap {
    /*text-align: center;*/
    text-align: center;
    */ margin: 25px auto 0;
    width: 98px;
    border-radius: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 35px;
}
</style>


<!-- subjects -->
<style>
.main-container {
    /* max-width: 800px; */
    margin: 0 auto;
    padding: 20px;

}

.profile-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.profile-info {
    display: flex;
    align-items: center;
}

.profile-icon {
    float: right;
    margin-left: 5px;
}

.badge {
    display: inline-block;
    padding: 5px 10px;

    background-color: rgb(255 255 255 / 34%);
    /* Green background color with 50% opacity */
    color: white;
    font-size: 12px;
    border-radius: 5px;
}

.profile-image {
    width: 50px;
    height: 50px;
    margin-right: 5px;
    margin-top: -5px;
    border-radius: 50%;
    overflow: hidden;
    border: solid 1px yellowgreen;

}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-name {
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.profile-grade {
    font-size: 14px;
    color: white;
}

.action-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
}

.action-buttons a:hover {
    color: #fff;
}

.content-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
}

.center-icon {
    font-size: 24px;
    color: white;
    margin-bottom: 5px;
}

.rounded-div {
    width: calc(33.33% - 20px);
    margin: 10px;
    padding: 20px;
    border-radius: 17px;
     background-color: #E5E4E2; 
    text-align: center;
    transition: transform 0.3s;
}

.rounded-div img {
    max-width: 55%;
    max-height: 55%;
    border-radius: 50%;
    margin-bottom: 5px;
}

.subject-name {
    font-size: 14px;
    /* font-weight: bold; */
    color: black;
}

.student-name {
    font-size: 12px;
    color: lightgray;
}

.rounded-div:hover {
    transform: scale(1.05);
}


.rounded-div:nth-child(1) {
    background-color: #e5e4e2 !important;
    /* color: black; */
}

.rounded-div:nth-child(2) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(3) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(4) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(5) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(6) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(7) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(8) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(9) {
    background-color: #E5E4E2;
}

.x_panel .x_panel {
    border: none;
    margin-top: -60px;
}

ul.progressSlider {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}
</style>
<!-- subjects -->

<?php

function generateRandomColor()
{
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}

?>

<!-- studnet selection -->
<style>
/* .homePageWrap {
    width: 100%;
    margin: 0px auto;
    padding: 60px 0 0;
    background-color: #ffffff;
} */

.x_panel {
    position: relative;
    width: 100%;
    min-height: 80vh;
    margin-bottom: 10px;
    padding: 5px 17px;
    display: inline-block;
    background: #fff;
    border: 1px solid #E6E9ED;
    -webkit-column-break-inside: avoid;
    -moz-column-break-inside: avoid;
    column-break-inside: avoid;
    opacity: 1;
    transition: all .2s ease;
}

.main_ {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}

.account-card {
    background-color: #3498db;
    border: 2px solid #cecece;
    border-radius: 16px;
    padding: 20px;
    margin: 35px;
    width: 135px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease-in-out;
    height: 130px;
}

.account-card-outer {
    text-align: center;
    color: black;
    font-weight: 600;
    font-size: 25px !important;
}

.account-image {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    margin-bottom: 10px;
    object-fit: contain;
}

.view-progress-btn {

    color: #fff;
    font-weight: 600;
    font-size: 14px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

/* Responsive Styles */
@media (max-width: 600px) {
    .account-card {
        width: 100%;
    }
}

/* Hover Effect */
.account-card:hover {
    transform: scale(1.05);
}
</style>

<style>
.progressTop .selectWrap {
    background-color: #75c2e3;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.15);
    border-radius: 30px;
    height: 44px;
    max-width: 230px;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    margin: 0 auto;
    position: relative;
}

.progressTop .selectWrap select {
    background-color: transparent;
    border: 0;
    outline: 0;
    color: black;
    width: 100%;
    height: 100%;
    text-align: center;
    -webkit-appearance: none;
}

.progressTop .selectWrap:after {
    content: "";
    background-image: url(../img/ico-2.png);
    background-repeat: no-repeat;
    width: 9px;
    height: 7px;
    background-size: cover;
    background-position: center;
    position: absolute;
    right: 15px;
}
</style>
<script>
$(document).ready(function() {
    const subject_id = $("#subject_id").val();
   
    $(document).on('change','#subject_id' ,function() {
         const subject_id = $(this).find(":selected").val();
        //  alert(subject_id);
         get_chakras(subject_id);
});
   get_chakras(subject_id);
    // const subject_id = $("#subject_id").val();
    // alert(subject_id);
   // get_chakras(subject_id);
    // $('#subject_id').on('change', function() {
    //     const subject_id = $(this).val();
    //     get_chakras(subject_id);
    // });

    function get_chakras(subject_id) {
        if (subject_id) {
            $.ajax({
                url: "<?=site_url('administrator/report_all/getChakras');?>/" + subject_id,
                type: 'GET',
                success: function(data) {
                    //alert(data);
                    $('#resultData').html(data);
                },
                // error: function(xhr, status, error) {
                //     console.error(xhr.responseText);
                // }
            });
        }
    }
});
</script>