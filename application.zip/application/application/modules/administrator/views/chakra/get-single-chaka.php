<div class="" data-example-id="togglable-tabs">
    <ul  class="nav nav-tabs bordered">
        <li class="active"><a href="#tab_basic_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-info-circle"></i> chakra</a> </li>
        <!-- <li class=""><a href="#tab_setting_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> <?php echo $this->lang->line('attachment'); ?></a> </li> -->
        <!-- <li class=""><a href="#tab_social_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('social_information'); ?></a> </li> -->
    </ul>
    <br/>

    
     <div class="tab-content">
        <div  class="tab-pane fade in active" id="tab_basic_info" > 
        
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <tbody>
                <!-- <?php print_r($S_chakra)?> -->
                <tr>
                        <th>Course URL</th>
                        <td colspan="3"><a target="_blank" href="<?php echo base_url($S_chakra->file); ?>/story.html"><strong>View Story</strong></a></td> 
                    </tr>                   
                <tr>
                        <th><?php echo $this->lang->line('name'); ?></th>
                        <th><?php print_r($S_chakra->title)?></th>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('description'); ?></th>
                        <th><?php print_r($S_chakra->description)?></th>
                    </tr>
                    <tr>
                        <th><?php echo $this->lang->line('status'); ?></th>
                        <th> <?php if ($S_chakra->status == 1) {
                                                    echo 'Active';
                                                } else {
                                                    echo 'Deactive';
                                                }
                                                    ?></th>
                    </tr>  
                    <?php $count = 1;if (isset($S_chakra_files) && !empty($S_chakra_files)) {?>
                        <tr>
                    <td>No.</td>
                    <td>File Attachment:</td>
                </tr>  
            <?php foreach ($S_chakra_files as $obj) {?>
                <tr>
                    <td><?php echo $count++; ?></td>
                    <td><a href="<?php echo  base_url($obj->path); ?>" target="_blank"> <?php echo $obj->file_name; ?></a></td>
                </tr>          
              
                  
            <?php } }?>     
                </tbody>
            </table>
        </div>
         
        <!-- <div  class="tab-pane fade in" id="tab_setting_info" > 
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <tbody>                               
            <?php $count = 1;if (isset($S_course_files) && !empty($S_course_files)) {?>
            <?php foreach ($S_course_files as $obj) {?>
                <tr>
                    <td><?php echo $count++; ?></td>
                    <td><?php echo  site_url($obj->path); ?></td>
                </tr>          
              
                  
            <?php } }?>         
            </tbody>
        </table>
        </div>
          -->
       
    </div>
</div>
