<span><?php echo $this->lang->line('quick_link'); ?>:</span>

<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/master/index'); ?>"> <?php echo $this->lang->line('manage_state'); ?></a> |
<?php } ?>
<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/board/index'); ?>"><?php echo $this->lang->line('board'); ?></a> |
<?php } ?>
<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/grade/index'); ?>"><?php echo $this->lang->line('grade'); ?></a> |
<?php } ?>
<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/sections/index'); ?>"><?php echo $this->lang->line('sections'); ?></a> |
<?php } ?>
<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/subject/index'); ?>"><?php echo $this->lang->line('subject'); ?></a> |
<?php } ?>
<?php if(has_permission(VIEW, 'master', 'master')){ ?>
<a href="<?php echo site_url('administrator/volume/index'); ?>"><?php echo $this->lang->line('volume'); ?></a>
<?php } ?>