<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small> <?php echo $this->lang->line('manage_school'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content quick-link">
                <?php $this->load->view('quick-link'); ?>
            </div>

            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">

                    <ul class="nav nav-tabs bordered">
                        <?php if (has_permission(VIEW, 'administrator', 'school')) { ?>
                            <li class="<?php if (isset($list)) {
                                            echo 'active';
                                        } ?>"><a href="#tab_school_list" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php } ?>

                        <?php if (has_permission(ADD, 'administrator', 'school')) { ?>
                            <?php if (isset($edit)) { ?>
                                <li class="<?php if (isset($add)) {
                                                echo 'active';
                                            } ?>"><a href="<?php echo site_url('administrator/school/add'); ?>" aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('add'); ?></a> </li>
                            <?php } else { ?>
                                <li class="<?php if (isset($add)) {
                                                echo 'active';
                                            } ?>"><a href="#tab_add_school" role="tab" data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('add'); ?></a> </li>
                            <?php } ?>
                        <?php } ?>

                        <?php if (isset($edit)) { ?>
                            <li class="active"><a href="#tab_edit_school" role="tab" data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> <?php echo $this->lang->line('edit'); ?></a> </li>
                        <?php } ?>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if (isset($list)) {
                                                            echo 'active';
                                                        } ?>" id="tab_school_list">
                            <div class="x_content">
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <th><?php echo $this->lang->line('school_name'); ?></th>
                                            <th><?php echo $this->lang->line('subscription'); ?></th>
                                            <th><?php echo $this->lang->line('is_demo'); ?></th>
                                            <th><?php echo $this->lang->line('address'); ?></th>
                                            <th><?php echo $this->lang->line('phone'); ?></th>
                                            <th><?php echo $this->lang->line('email'); ?></th>
                                            <th><?php echo $this->lang->line('admin_logo'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1;
                                        if (isset($schools) && !empty($schools)) { ?>
                                            <?php foreach ($schools as $obj) { ?>
                                                <tr>
                                                    <td><?php echo $count++; ?></td>
                                                    <td>
                                                        <?php echo $obj->school_name; ?><br />
                                                        <?php if ($obj->status) { ?>
                                                            <a class="btn btn-success btn-xs" target="_blank" href="<?php echo site_url($obj->school_url); ?>"><?php echo $this->lang->line('visit_school'); ?></a>
                                                        <?php } else { ?>
                                                            <a class="btn btn-success btn-xs" href="<?php echo site_url('administrator/school/edit/' . $obj->id); ?>"><?php echo $this->lang->line('activate_now'); ?></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <select class="form-control col-md-7 col-xs-12 status-type" name="subscription_id" id="subscription_id" onchange="update_subscription_status('<?php echo $obj->id; ?>', this.value);" style="float: left;">
                                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                            <?php foreach ($subscriptions as $sp) { ?>
                                                                <option value="<?php echo $sp->id; ?>" <?php echo $sp->id == $obj->subscription_id ?  'selected="selected"' : ''; ?>><?php echo $sp->school; ?> [<?php echo $this->lang->line($sp->plan_name); ?>]</option>
                                                            <?php } ?>
                                                        </select><br />

                                                        <?php $btn = $obj->subscription_status == 'approved' ? 'btn-success' : 'btn-danger'; ?>
                                                        <a class="btn <?php echo $btn; ?> btn-xs" href="javascript:void(0);"><?php echo $this->lang->line($obj->subscription_status); ?></a>
                                                        <a class="btn <?php echo $btn; ?> btn-xs" href="<?php echo site_url('subscription/edit/' . $sp->id); ?>"><?php echo $this->lang->line('update'); ?> <?php echo $this->lang->line('status'); ?></a>

                                                    </td>
                                                    <td>
                                                        <input class="fn_is_demo" onclick="set_demo_school(<?php echo $obj->id; ?>);" type="checkbox" name="is_demo" id="is_demo_<?php echo $obj->id; ?>" value="<?php echo $obj->id; ?>" <?php if ($obj->is_demo) {
                                                                                                                                                                                                                                                echo 'checked="checked"';
                                                                                                                                                                                                                                            } ?> />
                                                    </td>
                                                    <td><?php echo $obj->address; ?></td>
                                                    <td><?php echo $obj->phone; ?></td>
                                                    <td><?php echo $obj->email; ?></td>
                                                    <td>
                                                        <?php if ($obj->logo) { ?>
                                                            <img class="logo-identifier" src="<?php echo UPLOAD_PATH; ?>/logo/<?php echo $obj->logo; ?>" alt="" width="80" />
                                                        <?php } else { ?>
                                                            <img class="logo-identifier" src="<?php echo IMG_URL; ?>/sms-logo-50.png" alt="" width="80" />
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $obj->status ? $this->lang->line('active') : $this->lang->line('in_active'); ?></td>
                                                    <td>
                                                        <?php if (has_permission(VIEW, 'administrator', 'school')) { ?>
                                                            <a onclick="get_school_modal(<?php echo $obj->id; ?>);" data-toggle="modal" data-target=".bs-school-modal-lg" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> <?php echo $this->lang->line('view'); ?> </a><br />
                                                        <?php } ?>
                                                        <?php if (has_permission(EDIT, 'administrator', 'school')) { ?>
                                                            <a href="<?php echo site_url('administrator/school/edit/' . $obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> <?php echo $this->lang->line('edit'); ?> </a>
                                                        <?php } ?>
                                                        <?php if (has_permission(DELETE, 'administrator', 'school')) { ?>
                                                            <a href="<?php echo site_url('administrator/school/delete/' . $obj->id); ?>" onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> <?php echo $this->lang->line('delete'); ?> </a>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade in <?php if (isset($add)) {
                                                            echo 'active';
                                                        } ?>" id="tab_add_school">
                            <div class="x_content">
                                <?php echo form_open_multipart(site_url('administrator/school/add'), array('name' => 'add', 'id' => 'add', 'class' => 'form-horizontal form-label-left'), ''); ?>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title"><strong><?php echo $this->lang->line('basic_information'); ?>:</strong></h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="school_url"><?php echo $this->lang->line('school_url'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="school_url" id="school_url" value="<?php echo isset($post['school_url']) ?  $post['school_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('school_url'); ?>" required="required" type="text" autocomplete="off">
                                            <div class="text-info"><?php echo $this->lang->line('school_url_format'); ?></div>
                                            <div class="help-block"><?php echo form_error('school_url'); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="school_code"><?php echo $this->lang->line('school_code'); ?></label>
                                            <input class="form-control col-md-7 col-xs-12" name="school_code" id="school_code" value="<?php echo isset($post['school_code']) ?  $post['school_code'] : ''; ?>" placeholder="<?php echo $this->lang->line('school_code'); ?> " type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('school_code'); ?></div>
                                        </div>
                                    </div>

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="school_name"><?php echo $this->lang->line('school_name'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="school_name" id="school_name" value="<?php echo isset($post['school_name']) ?  $post['school_name'] : ''; ?>" placeholder="<?php echo $this->lang->line('school_name'); ?>" required="required" type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('school_name'); ?></div>
                                        </div>
                                    </div>

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="address"><?php echo $this->lang->line('address'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="address" id="address" value="<?php echo isset($post['address']) ?  $post['address'] : ''; ?>" placeholder="<?php echo $this->lang->line('address'); ?>" required="required" type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('address'); ?></div>
                                        </div>
                                    </div>

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="phone"><?php echo $this->lang->line('phone'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="phone" id="phone" value="<?php echo isset($post['phone']) ?  $post['phone'] : ''; ?>" placeholder="<?php echo $this->lang->line('phone'); ?>" required="required" type="number" minlength="6" maxlength="20" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('phone'); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="registration_date"><?php echo $this->lang->line('registration_date'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="registration_date" id="add_registration_date" value="<?php echo isset($post['registration_date']) ?  $post['registration_date'] : ''; ?>" placeholder="<?php echo $this->lang->line('registration_date'); ?>" type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('registration_date'); ?></div>
                                        </div>
                                    </div>

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="email"><?php echo $this->lang->line('email'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="email" id="email" value="<?php echo isset($post['email']) ?  $post['email'] : ''; ?>" placeholder="<?php echo $this->lang->line('email'); ?> " required="required" type="email" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('email'); ?></div>
                                        </div>
                                    </div>


                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="school_fax"><?php echo $this->lang->line('school_fax'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="school_fax" id="school_fax" value="<?php echo isset($post['school_fax']) ?  $post['school_fax'] : ''; ?>" placeholder="<?php echo $this->lang->line('school_fax'); ?> " type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('school_fax'); ?></div>
                                        </div>
                                    </div>

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="footer"><?php echo $this->lang->line('footer'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="footer" id="footer" value="<?php echo isset($post['footer']) ?  $post['footer'] : ''; ?>" placeholder="<?php echo $this->lang->line('footer'); ?> " type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('footer'); ?></div>
                                        </div>
                                    </div>

                                </div>


                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title"><strong><?php echo $this->lang->line('setting_information'); ?>:</strong></h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <!--<div class="col-md-3 col-sm-3 col-xs-12">-->
                                    <!--    <div class="item form-group">-->
                                    <!--        <label for="currency"><?php echo $this->lang->line('currency'); ?></label>-->
                                    <!--        <input class="form-control col-md-7 col-xs-12" name="currency" id="currency" value="<?php echo isset($post['currency']) ?  $post['currency'] : ''; ?>" placeholder="<?php echo $this->lang->line('currency'); ?>" type="text" autocomplete="off">-->
                                    <!--        <div class="help-block"><?php echo form_error('currency'); ?></div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <div class="col-md-3 col-sm-3 col-xs-12" style="display:none;">
                                        <div class="item form-group">
                                            <label for="currency_symbol"><?php echo $this->lang->line('currency_symbol'); ?> <span class="required">*</span></label>
                                            <input class="form-control col-md-7 col-xs-12" name="currency_symbol" id="currency_symbol" value="<?php echo isset($post['currency_symbol']) ?  $post['currency_symbol'] : ''; ?>" placeholder="<?php echo $this->lang->line('currency_symbol'); ?> " required="required" type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('currency_symbol'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="enable_frontend"><?php echo $this->lang->line('enable_frontend'); ?> <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12" name="enable_frontend" required="required">
                                                <option value="1" <?php if (isset($post) && $post['enable_frontend'] == '1') {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('yes'); ?></option>
                                                <option value="0" <?php 
                                                if (isset($post) && $post['enable_frontend'] == '0') {
                                                                        echo 'selected="selected"';
                                                                    } 
                                                                    ?>><?php echo $this->lang->line('no'); ?></option>
                                            </select>
                                            <div class="help-block"><?php echo form_error('enable_frontend'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="final_result_type"><?php echo $this->lang->line('exam_final_result'); ?> <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12" name="final_result_type" required="required">
                                                <option value="0" <?php if (isset($post) && $post['final_result_type'] == '0') {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('avg_of_all_exam'); ?> </option>
                                                <option value="1" <?php if (isset($post) && $post['final_result_type'] == '1') {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('only_of_fianl_exam'); ?> </option>
                                            </select>
                                            <div class="help-block"><?php echo form_error('final_result_type'); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="language"><?php echo $this->lang->line('language'); ?> <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12" name="language" required="required">
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                <?php foreach ($fields as $field) { ?>
                                                    <?php if ($field == 'id' || $field == 'label') {
                                                        continue;
                                                    } ?>
                                                    <option value="<?php echo $field; ?>"><?php echo ucfirst($field); ?></option>
                                                <?php } ?>
                                            </select>
                                            <div class="help-block"><?php echo form_error('language'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="theme_name"><?php echo $this->lang->line('theme'); ?> <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12" name="theme_name" required="required">
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                <?php foreach ($themes as $obj) { ?>
                                                    <option style="color: #FFF;background-color: <?php echo $obj->color_code; ?>;" value="<?php echo $obj->slug; ?>" <?php if (isset($post) && $post['theme_name'] == $obj->slug) {
                                                                                                                                                                            echo 'selected="selected"';
                                                                                                                                                                        } ?>><?php echo $obj->name; ?> </option>
                                                <?php } ?>
                                            </select>
                                            <div class="help-block"><?php echo form_error('theme_name'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="enable_online_admission"><?php echo $this->lang->line('online_admission'); ?> <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12" name="enable_online_admission" id="enable_online_admission" required="required">
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                <option value="0" <?php if (isset($post) && $post['enable_online_admission'] == 0) {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('no'); ?></option>
                                                <option value="1" <?php if (isset($post) && $post['enable_online_admission'] == 1) {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('yes'); ?></option>
                                            </select>
                                            <div class="help-block"><?php echo form_error('enable_online_admission'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12" style="display:none;">
                                        <div class="item form-group">
                                            <label for="enable_rtl"><?php echo $this->lang->line('enable_rtl'); ?> </label>
                                            <select class="form-control col-md-7 col-xs-12" name="enable_rtl" required="required">
                                                <option value="0" selected<?php if (isset($post) && $post['enable_rtl'] == 0) {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('no'); ?></option>
                                                <option value="1" <?php if (isset($post) && $post['enable_rtl'] == 1) {
                                                                        echo 'selected="selected"';
                                                                    } ?>><?php echo $this->lang->line('yes'); ?></option>
                                            </select>
                                            <div class="help-block"><?php echo form_error('enable_rtl'); ?></div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="zoom_api_key"><?php echo $this->lang->line('zoom_api_key'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="zoom_api_key" id="zoom_api_key" value="<?php echo isset($post['zoom_api_key']) ?  $post['zoom_api_key'] : ''; ?>" placeholder="<?php echo $this->lang->line('zoom_api_key'); ?> " type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('zoom_api_key'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="zoom_secret"><?php echo $this->lang->line('zoom_secret'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="zoom_secret" id="zoom_secret" value="<?php echo isset($post['zoom_secret']) ?  $post['zoom_secret'] : ''; ?>" placeholder="<?php echo $this->lang->line('zoom_secret'); ?> " type="text" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('zoom_secret'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="google_map"><?php echo $this->lang->line('google_map_url'); ?> </label>
                                            <textarea class="form-control col-md-6 col-xs-12 textarea-4column" name="google_map" id="google_map" placeholder="<?php echo $this->lang->line('google_map'); ?>"><?php echo isset($post['google_map']) ?  $post['google_map'] : ''; ?></textarea>
                                            <div class="help-block"><?php echo form_error('google_map'); ?></div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title"><strong><?php echo $this->lang->line('course'); ?>:</strong></h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="state_id"><?php echo $this->lang->line('state'); ?>
                                                <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12 status-type" name="state_id" id="state_id" style="float: left;" required="required">
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                </option>
                                                <?php foreach ($states as $sp) { ?>
                                                    <option value="<?php echo $sp->id; ?>"><?php echo $sp->title; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>

                                            <div class="help-block"><?php echo form_error('state_id'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="board_id"><?php echo $this->lang->line('board'); ?>
                                                <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12 status-type" name="board_id" id="board_id" style="float: left;" required="required">
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                </option>

                                            </select>

                                            <div class="help-block"><?php echo form_error('board_id'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="course_id"><?php echo $this->lang->line('course'); ?>
                                                <span class="required">*</span></label>
                                            <select class="form-control col-md-7 col-xs-12 status-type" name="course_id[]" id="course_id" style="float: left;" required="required" multiple>
                                                <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                </option>

                                            </select>

                                            <div class="help-block"><?php echo form_error('course_id'); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title"><strong><?php echo $this->lang->line('social_information'); ?>:</strong></h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="facebook_url"><?php echo $this->lang->line('facebook_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="facebook_url" id="facebook_url" value="<?php echo isset($post['facebook_url']) ?  $post['facebook_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('facebook_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('facebook_url'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="twitter_url"><?php echo $this->lang->line('twitter_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="twitter_url" id="twitter_url" value="<?php echo isset($post['twitter_url']) ?  $post['twitter_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('twitter_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('twitter_url'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="linkedin_url"><?php echo $this->lang->line('linkedin_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="linkedin_url" id="linkedin_url" value="<?php echo isset($post['linkedin_url']) ?  $post['linkedin_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('linkedin_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('linkedin_url'); ?></div>
                                        </div>
                                    </div>


                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="youtube_url"><?php echo $this->lang->line('youtube_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="youtube_url" id="youtube_url" value="<?php echo isset($post['youtube_url']) ?  $post['youtube_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('youtube_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('youtube_url'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="instagram_url"><?php echo $this->lang->line('instagram_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="instagram_url" id="instagram_url" value="<?php echo isset($post['instagram_url']) ?  $post['instagram_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('instagram_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('instagram_url'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="pinterest_url"><?php echo $this->lang->line('pinterest_url'); ?> </label>
                                            <input class="form-control col-md-7 col-xs-12" name="pinterest_url" id="pinterest_url" value="<?php echo isset($post['pinterest_url']) ?  $post['pinterest_url'] : ''; ?>" placeholder="<?php echo $this->lang->line('pinterest_url'); ?> " type="url" autocomplete="off">
                                            <div class="help-block"><?php echo form_error('pinterest_url'); ?></div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 class="column-title"><strong><?php echo $this->lang->line('other_information'); ?>:</strong></h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="logo"><?php echo $this->lang->line('frontend_logo'); ?> </label>
                                            <div class="btn btn-default btn-file"><i class="fa fa-paperclip"></i> <?php echo $this->lang->line('upload'); ?>
                                                <input class="form-control col-md-7 col-xs-12" name="frontend_logo" id="frontend_logo" type="file">
                                            </div>
                                            <div class="text-info"><?php echo $this->lang->line('dimension'); ?>:- Max-W: 150px, Max-H: 90px</div>
                                            <div class="help-block"><?php echo form_error('frontend_logo'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="logo"><?php echo $this->lang->line('admin_logo'); ?> </label>
                                            <div class="btn btn-default btn-file"><i class="fa fa-paperclip"></i> <?php echo $this->lang->line('upload'); ?>
                                                <input class="form-control col-md-7 col-xs-12" name="logo" id="logo" type="file">
                                            </div>
                                            <div class="text-info"><?php echo $this->lang->line('dimension'); ?>:- Max-W: 100px, Max-H: 110px</div>
                                            <div class="help-block"><?php echo form_error('logo'); ?></div>
                                        </div>
                                    </div>

                                </div>

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('administrator/school/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit" class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        <?php if (isset($edit)) { ?>
                            <div class="tab-pane fade in active" id="tab_edit_school">
                                <div class="x_content">
                                    <?php echo form_open_multipart(site_url('administrator/school/edit/' . $school->id), array('name' => 'edit', 'id' => 'edit', 'class' => 'form-horizontal form-label-left'), ''); ?>


                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <h5 class="column-title"><strong><?php echo $this->lang->line('basic_information'); ?>:</strong></h5>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="item form-group">
                                                <label for="school_url"><?php echo $this->lang->line('school_url'); ?> <span class="required">*</span></label>
                                                <input class="form-control col-md-7 col-xs-12" name="school_url" id="school_url" value="<?php echo isset($school) ? $school->school_url : ''; ?>" placeholder="<?php echo $this->lang->line('school_url'); ?>" required="required" type="text" autocomplete="off">
                                                <div class="text-info"><?php echo $this->lang->line('school_url_format'); ?></div>
                                                <div class="help-block"><?php echo form_error('school_url'); ?></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="school_code"><?php echo $this->lang->line('school_code'); ?></label>
                                                <input class="form-control col-md-7 col-xs-12" name="school_code" id="school_code" value="<?php echo isset($school) ? $school->school_code : ''; ?>" placeholder="<?php echo $this->lang->line('school_code'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('school_code'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="school_name"><?php echo $this->lang->line('school_name'); ?> <span class="required">*</span></label>
                                                <input class="form-control col-md-7 col-xs-12" name="school_name" id="school_name" value="<?php echo isset($school) ? $school->school_name : ''; ?>" placeholder="<?php echo $this->lang->line('school_name'); ?>" required="required" type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('school_name'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="address"><?php echo $this->lang->line('address'); ?> <span class="required">*</span></label>
                                                <input class="form-control col-md-7 col-xs-12" name="address" id="address" value="<?php echo isset($school) ? $school->address : ''; ?>" placeholder="<?php echo $this->lang->line('address'); ?> " required="required" type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('address'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="phone"><?php echo $this->lang->line('phone'); ?> <span class="required">*</span></label>
                                                <input class="form-control col-md-7 col-xs-12" name="phone" id="phone" value="<?php echo isset($school) ? $school->phone : ''; ?>" placeholder="<?php echo $this->lang->line('phone'); ?>" required="required" type="number" minlength="6" maxlength="20" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('phone'); ?></div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="registration_date"><?php echo $this->lang->line('registration_date'); ?></label>
                                                <input class="form-control col-md-7 col-xs-12" name="registration_date" id="edit_registration_date" value="<?php echo isset($school) ? $school->registration_date : ''; ?>" placeholder="<?php echo $this->lang->line('registration_date'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('registration_date'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="email"><?php echo $this->lang->line('email'); ?> <span class="required">*</span></label>
                                                <input class="form-control col-md-7 col-xs-12" name="email" id="email" value="<?php echo isset($school) ? $school->email : ''; ?>" placeholder="<?php echo $this->lang->line('email'); ?> " required="required" type="email" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('email'); ?></div>
                                            </div>
                                        </div>


                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="school_fax"><?php echo $this->lang->line('school_fax'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="school_fax" id="school_fax" value="<?php echo isset($school) ? $school->school_fax : ''; ?>" placeholder="<?php echo $this->lang->line('school_fax'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('school_fax'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="footer"><?php echo $this->lang->line('footer'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="footer" id="footer" value="<?php echo isset($school) ? $school->footer : ''; ?>" placeholder="<?php echo $this->lang->line('footer'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('footer'); ?></div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <h5 class="column-title"><strong><?php echo $this->lang->line('setting_information'); ?>:</strong></h5>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!--<div class="col-md-3 col-sm-3 col-xs-12">-->
                                        <!--    <div class="item form-group">-->
                                        <!--        <label for="currency"><?php echo $this->lang->line('currency'); ?> </label>-->
                                        <!--        <input class="form-control col-md-7 col-xs-12" name="currency" id="currency" value="<?php echo isset($school) ? $school->currency : ''; ?>" placeholder="<?php echo $this->lang->line('currency'); ?> " type="text" autocomplete="off">-->
                                        <!--        <div class="help-block"><?php echo form_error('currency'); ?></div>-->
                                        <!--    </div>-->
                                        <!--</div>-->
                                        <!--<div class="col-md-3 col-sm-3 col-xs-12">-->
                                        <!--    <div class="item form-group">-->
                                        <!--        <label for="currency_symbol"><?php echo $this->lang->line('currency_symbol'); ?> <span class="required">*</span></label>-->
                                        <!--        <input class="form-control col-md-7 col-xs-12" name="currency_symbol" id="currency_symbol" value="<?php echo isset($school) ? $school->currency_symbol : ''; ?>" placeholder="<?php echo $this->lang->line('currency_symbol'); ?> " required="required" type="text" autocomplete="off">-->
                                        <!--        <div class="help-block"><?php echo form_error('currency_symbol'); ?></div>-->
                                        <!--    </div>-->
                                        <!--</div>-->

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="enable_frontend"><?php echo $this->lang->line('enable_frontend'); ?> <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12" name="enable_frontend" required="required">
                                                    <option value="1" <?php if (isset($school) && $school->enable_frontend == 1) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('yes'); ?></option>
                                                    <option value="0" <?php if (isset($school) && $school->enable_frontend == 0) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('no'); ?></option>
                                                </select>
                                                <div class="help-block"><?php echo form_error('enable_frontend'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="final_result_type"><?php echo $this->lang->line('exam_final_result'); ?> <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12" name="final_result_type" required="required">
                                                    <option value="0" <?php if (isset($school) && $school->final_result_type == 0) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('avg_of_all_exam'); ?> </option>
                                                    <option value="1" <?php if (isset($school) && $school->final_result_type == 1) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('only_of_fianl_exam'); ?> </option>
                                                </select>
                                                <div class="help-block"><?php echo form_error('final_result_type'); ?></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="language"><?php echo $this->lang->line('language'); ?> <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12" name="language" required="required">
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                    <?php foreach ($fields as $field) { ?>
                                                        <?php if ($field == 'id' || $field == 'label') {
                                                            continue;
                                                        } ?>
                                                        <option value="<?php echo $field; ?>" <?php if (isset($school) && $school->language == $field) {
                                                                                                    echo 'selected="selected"';
                                                                                                } ?>><?php echo ucfirst($field); ?></option>
                                                    <?php } ?>
                                                </select>
                                                <div class="help-block"><?php echo form_error('language'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="theme_name"><?php echo $this->lang->line('theme'); ?> <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12" name="theme_name">
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                                    <?php foreach ($themes as $obj) { ?>
                                                        <option style="color: #FFF;background-color: <?php echo $obj->color_code; ?>;" value="<?php echo $obj->slug; ?>" <?php if (isset($school) && $school->theme_name == $obj->slug) {
                                                                                                                                                                                echo 'selected="selected"';
                                                                                                                                                                            } ?>><?php echo $obj->name; ?> </option>
                                                    <?php } ?>
                                                </select>
                                                <div class="help-block"><?php echo form_error('theme_name'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="enable_online_admission"><?php echo $this->lang->line('online_admission'); ?> <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12" name="enable_online_admission" id="enable_online_admission" required="required">
                                                    <option value="0" <?php if (isset($school) && $school->enable_online_admission == 0) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('no'); ?></option>
                                                    <option value="1" <?php if (isset($school) && $school->enable_online_admission == 1) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('yes'); ?></option>
                                                </select>
                                                <div class="help-block"><?php echo form_error('enable_online_admission'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12" style="display:none;">
                                            <div class="item form-group">
                                                <label for="enable_rtl"><?php echo $this->lang->line('enable_rtl'); ?> </label>
                                                <select class="form-control col-md-7 col-xs-12" name="enable_rtl" required="required">
                                                    <option value="0" <?php if (isset($school) && $school->enable_rtl == 0) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('no'); ?></option>
                                                    <option value="1" <?php if (isset($school) && $school->enable_rtl == 1) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('yes'); ?></option>
                                                </select>
                                                <div class="help-block"><?php echo form_error('enable_rtl'); ?></div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="zoom_api_key"><?php echo $this->lang->line('zoom_api_key'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="zoom_api_key" id="zoom_api_key" value="<?php echo isset($school) ? $school->zoom_api_key : ''; ?>" placeholder="<?php echo $this->lang->line('zoom_api_key'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('zoom_api_key'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="zoom_secret"><?php echo $this->lang->line('zoom_secret'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="zoom_secret" id="zoom_secret" value="<?php echo isset($school) ? $school->zoom_secret : ''; ?>" placeholder="<?php echo $this->lang->line('zoom_secret'); ?> " type="text" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('zoom_secret'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="item form-group">
                                                <label for="google_map"><?php echo $this->lang->line('google_map_url'); ?> </label>
                                                <textarea class="form-control col-md-6 col-xs-12 textarea-4column" name="google_map" id="google_map" placeholder="<?php echo $this->lang->line('google_map'); ?>"><?php echo isset($school) ?  $school->google_map : ''; ?></textarea>
                                                <div class="help-block"><?php echo form_error('google_map'); ?></div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <h5 class="column-title"><strong><?php echo $this->lang->line('course'); ?>:</strong></h5>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="state_id"><?php echo $this->lang->line('state'); ?>
                                                    <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12 status-type" name="state_id" id="state_id_edit" style="float: left;" required="required" >
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                    <?php foreach ($states as $sp) { ?>
                                                        <option value="<?php echo $sp->id; ?>" <?php if ($sp->id == $school->state_id) {
                                                                                                    echo 'selected';
                                                                                                } ?>><?php echo $sp->title; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>

                                                <div class="help-block"><?php echo form_error('state_id'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="board_id"><?php echo $this->lang->line('board'); ?>
                                                    <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12 status-type" name="board_id" id="board_id_edit" style="float: left;" required="required" >
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                </select>

                                                <div class="help-block"><?php echo form_error('board_id'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="course_id"><?php echo $this->lang->line('course'); ?>                                               
                                                    <span class="required">*</span></label>
                                                <select class="form-control col-md-7 col-xs-12 status-type" name="course_id[]" id="course_id_edit" style="float: left;" required="required" multiple >
                                                    <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                    </option>
                                                </select>

                                                <div class="help-block"><?php echo form_error('course_id'); ?></div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <h5 class="column-title"><strong><?php echo $this->lang->line('social_information'); ?>:</strong></h5>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="facebook_url"><?php echo $this->lang->line('facebook_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="facebook_url" id="facebook_url" value="<?php echo isset($school) ? $school->facebook_url : ''; ?>" placeholder="<?php echo $this->lang->line('facebook_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('facebook_url'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="twitter_url"><?php echo $this->lang->line('twitter_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="twitter_url" id="twitter_url" value="<?php echo isset($school) ? $school->twitter_url : ''; ?>" placeholder="<?php echo $this->lang->line('twitter_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('twitter_url'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="linkedin_url"><?php echo $this->lang->line('linkedin_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="linkedin_url" id="linkedin_url" value="<?php echo isset($school) ? $school->linkedin_url : ''; ?>" placeholder="<?php echo $this->lang->line('linkedin_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('linkedin_url'); ?></div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="youtube_url"><?php echo $this->lang->line('youtube_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="youtube_url" id="youtube_url" value="<?php echo isset($school) ? $school->youtube_url : ''; ?>" placeholder="<?php echo $this->lang->line('youtube_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('youtube_url'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="instagram_url"><?php echo $this->lang->line('instagram_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="instagram_url" id="instagram_url" value="<?php echo isset($school) ? $school->instagram_url : ''; ?>" placeholder="<?php echo $this->lang->line('instagram_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('instagram_url'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="pinterest_url"><?php echo $this->lang->line('pinterest_url'); ?> </label>
                                                <input class="form-control col-md-7 col-xs-12" name="pinterest_url" id="pinterest_url" value="<?php echo isset($school) ? $school->pinterest_url : ''; ?>" placeholder="<?php echo $this->lang->line('pinterest_url'); ?> " type="url" autocomplete="off">
                                                <div class="help-block"><?php echo form_error('pinterest_url'); ?></div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <h5 class="column-title"><strong><?php echo $this->lang->line('other_information'); ?>:</strong></h5>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="logo"><?php echo $this->lang->line('frontend_logo'); ?></label>
                                                <div class="btn btn-default btn-file"><i class="fa fa-paperclip"></i> <?php echo $this->lang->line('upload'); ?>
                                                    <input class="form-control col-md-7 col-xs-12" name="frontend_logo" id="frontend_logo" type="file">
                                                </div>
                                                <div class="text-info"><?php echo $this->lang->line('dimension'); ?>:- Max-W: 150px, Max-H: 90px</div>
                                                <div class="help-block"><?php echo form_error('frontend_logo'); ?></div>
                                                <?php if ($school->frontend_logo) { ?>
                                                    <img class="logo-identifier" src="<?php echo UPLOAD_PATH; ?>/logo/<?php echo $school->frontend_logo; ?>" alt="" width="80" /><br /><br />
                                                    <input name="frontend_logo_prev" value="<?php echo isset($school) ? $school->frontend_logo : ''; ?>" type="hidden">
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="logo"><?php echo $this->lang->line('admin_logo'); ?> </label>
                                                <div class="btn btn-default btn-file"><i class="fa fa-paperclip"></i> <?php echo $this->lang->line('upload'); ?>
                                                    <input class="form-control col-md-7 col-xs-12" name="logo" id="logo" type="file">
                                                </div>
                                                <div class="text-info"><?php echo $this->lang->line('dimension'); ?>:- Max-W: 100px, Max-H: 110px</div>
                                                <div class="help-block"><?php echo form_error('logo'); ?></div>
                                                <?php if ($school->logo) { ?>
                                                    <img class="logo-identifier" src="<?php echo UPLOAD_PATH; ?>/logo/<?php echo $school->logo; ?>" alt="" width="80" /><br /><br />
                                                    <input name="logo_prev" value="<?php echo isset($school) ? $school->logo : ''; ?>" type="hidden">
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                            <div class="item form-group">
                                                <label for="status"><?php echo $this->lang->line('status'); ?></label>
                                                <select class="form-control col-md-7 col-xs-12" name="status">
                                                    <option value="1" <?php if (isset($school) && $school->status == 1) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('active'); ?></option>
                                                    <option value="0" <?php if (isset($school) && $school->status == 0) {
                                                                            echo 'selected="selected"';
                                                                        } ?>><?php echo $this->lang->line('in_active'); ?></option>
                                                </select>
                                                <div class="help-block"><?php echo form_error('status'); ?></div>
                                            </div>
                                        </div>


                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="form-group">
                                        <div class="col-md-6 col-md-offset-3">
                                            <input type="hidden" value="<?php echo isset($school) ? $school->id : '' ?>" name="id" />
                                            <a href="<?php echo site_url('administrator/school/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                            <button id="send" type="submit" class="btn btn-success"><?php echo $this->lang->line('update'); ?></button>
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>
                        <?php } ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
            </div>
            <div class="modal-body fn_school_data">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function get_school_modal(school_id) {

        $('.fn_school_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>');
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('administrator/school/get_single_school'); ?>",
            data: {
                school_id: school_id
            },
            success: function(response) {
                if (response) {
                    $('.fn_school_data').html(response);
                }
            }
        });
    }
</script>



<link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
<script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        if ($('#state_id_edit').val())
            getBoard($('#state_id_edit').val());
    });
    $('#state_id , #state_id_edit').on('change', function() {
        var stateId = $(this).val();
        console.log(stateId);
        getBoard(stateId);

    });

    $('#board_id , #board_id_edit').on('change', function() {
        var board_id = $(this).val();
        console.log(board_id);
        getCourse(board_id);
    });

    function getBoard(stateId) {
        $('#board_id').empty();
        $('#board_id_edit').empty();
        $('#course_id').empty(); 
        $('#course_id_edit').empty();
        console.log("stateId", stateId);

        $('#board_id,#board_id_edit').append('<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');
        if (stateId) {
            $.ajax({
                url: "<?php echo site_url('administrator/master/get_board_list_by_state_id'); ?>/" + stateId,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    if (data) {

                        console.log(data);
                        $.each(data, function(key, value) {
                            $('#board_id').append('<option value="' + value.id + '">' + value.title +
                                '</option>');

                            if (value.id == <?php echo $school->board_id ?? 0; ?>) {
                                $('#board_id_edit').append('<option value="' + value.id +
                                    '" selected>' + value.title + '</option>');
                            } else
                                $('#board_id_edit').append('<option value="' + value.id + '">' + value
                                    .title + '</option>');
                        });
                        if ($('#board_id_edit').val())
                            getCourse($('#board_id_edit').val());

                    }
                }
            });
        }

    }


    function getCourse(boardId) {

        console.log('board_id', boardId);
        $('#course_id').empty();
        $('#course_id_edit').empty();

        console.log("boardId", boardId);

       // $('#course_id,#course_id_edit').append('<option value="">--<?php echo $this->lang->line('select'); ?>--</option>');
        if (boardId) {
            $.ajax({
                url: "<?php echo site_url('administrator/master/get_course_list_by_board_id'); ?>/" + boardId,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    if (data) {

                        console.log(data);
                        $.each(data, function(key, value) {
                            $('#course_id').append('<option value="' + value.id + '">' + value.title + '</option>');
                            var schoolCourseIds = <?php echo json_encode(explode(',', $school->course_id ?? '')); ?>;


                            if ($.inArray(value.id.toString(), schoolCourseIds) !== -1) {
                                $('#course_id_edit').append('<option value="' + value.id + '" selected>' + value.title + '</option>');
                            } else
                                $('#course_id_edit').append('<option value="' + value.id + '">' + value.title  + ' </option>');
                        });
                        // if ($('#course_id_edit').val())
                        //     getCourse($('#course_id_edit').val());

                    }
                }
            });
        }

    }




    function update_subscription_status(school_id, subscription_id) {

        if (!subscription_id) {
            toastr.error('<?php echo $this->lang->line('select_school'); ?>');
            return false;
        }
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('administrator/school/update_subscription_status'); ?>",
            data: {
                school_id: school_id,
                subscription_id: subscription_id
            },
            async: false,
            success: function(response) {
                if (response) {
                    toastr.success('<?php echo $this->lang->line('update_success'); ?>');
                    return false;
                } else {
                    toastr.error('<?php echo $this->lang->line('already_associated_with_a_school'); ?>');
                    return false;
                }
            }
        });
    }

    function set_demo_school(school_id) {

        if ($('#is_demo_' + school_id).prop("checked") == true) {

            $('.fn_is_demo').prop("checked", false);
            $('#is_demo_' + school_id).prop("checked", true);

            $.ajax({
                type: "POST",
                url: "<?php echo site_url('administrator/school/set_demo_school'); ?>",
                data: {
                    school_id: school_id
                },
                async: false,
                success: function(response) {
                    if (response) {
                        toastr.success('<?php echo $this->lang->line('update_success'); ?>');
                    } else {
                        toastr.error('<?php echo $this->lang->line('update_failed'); ?>');
                    }
                    location.reload();
                }
            });

        }
    }


    $('#add_registration_date').datepicker();
    $('#edit_registration_date').datepicker();

    $(document).ready(function() {
        $('#datatable-responsive').DataTable({
            dom: 'Bfrtip',
            iDisplayLength: 15,
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5',
                'pageLength'
            ],
            search: true,
            responsive: true
        });
    });

    $("#add").validate();
    $("#edit").validate();
</script>