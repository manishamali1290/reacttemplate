<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Grade extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        parent::__construct();
        $this->load->model('Grade_Model', 'master', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashboard/index');
        }
        $this->load->model('Grade_Model');
        $this->layout->title($this->lang->line('manage_grade') . ' | ' . SMS);
        $this->data['states'] = $this->Grade_Model->get_satate_list();
    }


    /*****************Function index**********************************
    
     * ********************************************************** */
    public function index()
    {


        $this->load->model('Grade_Model');
        $this->data['grades'] = $this->Grade_Model->get_grade_list();
        // $this->data['boards']= $this->Board_Model->get_board_list();       
        $this->data['list'] = TRUE;
        // $this->layout->title($this->lang->line('grade'). ' | ' . SMS);
        $this->layout->view('administrator/grade/index', $this->data);
    }



    /*****************Function add**********************************
  
     * ********************************************************** */

    public function add()
    {

        $this->data['edit'] = FALSE;
        $this->data['add'] = FALSE;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('state_id', 'State', 'required');
            $this->form_validation->set_rules('board_id', 'Board', 'required');
            $this->form_validation->set_rules('course_id', 'Course', 'required');
            $this->form_validation->set_rules('grade_title', 'Grade', 'trim|required');

            if ($this->form_validation->run() == true) {
                $status = $this->input->post('status');
                $status = ($status === null) ? '0' : $status;
                $data = array(
                    'state_id' => $this->input->post('state_id'),
                    'board_id' => $this->input->post('board_id'),
                    'course_id' => $this->input->post('course_id'),
                    'title' => $this->input->post('grade_title'),
                    'description' => $this->input->post('grade_description'),
                    'status' => 1,
                );
                $data['created_at'] = date('Y-m-d H:i:s');
                $data['created_by'] = logged_in_user_id();
                $this->load->model('Grade_Model');

                $inserted_id = $this->Grade_Model->insert_data($data);

                // echo $inserted_id; die;
                if ($inserted_id) {
                    create_log('Has been created a state : ' . $data['state_title']);

                    success($this->lang->line('insert_success'));
                    redirect('administrator/grade/index');
                } else {
                   
                    error('Grade is already created');
                    redirect('administrator/grade/index');
                    $this->data['add'] = TRUE;
                    $this->data = $_POST;
                    // echo "<pre>";
                    // print_r($data); die;
                }
            }
        }

        $this->load->view('administrator/grade/index/');
    }


    public function delete($id)
    {
        if ($id) {
            $this->load->model('Grade_Model');

            $inserted_id = $this->Grade_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a Grade ');

                success($this->lang->line('insert_success'));
            }
            redirect('administrator/grade/index');
        }
        $this->data['add'] = TRUE;
    }


    /*****************Function edit**********************************
 
     * ********************************************************** */
    public function edit($id = null)
    {
        $this->load->model('Grade_Model');
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
                // 'course_id' => $this->input->post('course_id'),
                'title' => $this->input->post('grade_title'),
                'description' => $this->input->post('grade_description'),
                'status' => 1,
                'modified_at' => date('Y-m-d H:i:s'),
                'modified_by' => logged_in_user_id(),
            );

            $this->load->model('Grade_Model');
            // print_r($data);
            // die();
            $updated = $this->Grade_Model->update_data($data);

            if ($updated) {

                // create_log('Has been updated a Grade : ' . $data['grade_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/grade/index');
            } else {

                error($this->lang->line('update_failed'));
                redirect('administrator/grade/edit/' . $id);
            }
        } else {
            if ($id) {
                $this->data['grade'] = $this->master->get_single('m_grade', array('id' => $id));

                if (!$this->data['grade']) {
                    redirect('administrator/grade/index');
                }
            }
        }

        $this->data['edit'] = TRUE;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('grade/index', $this->data);
    }
}
