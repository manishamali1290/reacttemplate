<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Sections extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Sections_Model', 'master', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        $this->load->model('Sections_Model');
        $this->layout->title($this->lang->line('manage_sections'). ' | ' . SMS);
        $this->data['states']= $this->Sections_Model->get_satate_list(); 
       
        
       
    }

    
    /*****************Function index**********************************
    
    * ********************************************************** */
    public function index() {

        
         $this->load->model('Sections_Model');
         $this->data['sections']= $this->Sections_Model->get_section_list(); 
        // $this->data['boards']= $this->Board_Model->get_board_list();       
        $this->data['list'] = TRUE;
       // $this->layout->title($this->lang->line('section'). ' | ' . SMS);
        $this->layout->view('administrator/sections/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************
  
    * ********************************************************** */
   
    public function add() {      
        
       $this->data['edit'] = FALSE;        
       $this->data['add'] = true; 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
              
                    $status = $this->input->post('status');
                    $status = ($status === null) ? '0' : $status;
                    $data = array(
                        'state_id' => $this->input->post('state_id'),
                        'board_id' => $this->input->post('board_id'),
                        'course_id' => $this->input->post('course_id'),
                        'grade_id' => $this->input->post('grade_id'),
                        'title' => $this->input->post('section_title'),
                        'description' => $this->input->post('section_description'),
                        'status' => 1,
                    );
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $data['created_by'] = logged_in_user_id();
                   // $this->load->model('Sections_Model');
                   
        
        
                    $inserted_id = $this->Sections_Model->insert_data($data);
    
                    if ($inserted_id) {
                        create_log('Has been created a state : '.$data['section_title']);  
                    
                        success($this->lang->line('insert_success'));
                        redirect('administrator/sections/index');
                    }
                }
                   
                    else {
                      
                        $this->data = $_POST;
                    }
                
            
    
            $this->load->view('administrator/sections/index');
        }
        public function delete($id) {
            if($id){
            $this->load->model('Sections_Model');
    
            $inserted_id = $this->Sections_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a sections ');  
            
                success($this->lang->line('insert_success'));               
            } 
            redirect('administrator/sections/index');
            }
           
        }
   
    
    /*****************Function edit**********************************
 
    * ********************************************************** */
    public function edit($id = null) {        
        $this->load->model('Sections_Model'); 
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                'title' => $this->input->post('section_title'),
                'description' => $this->input->post('section_description'),
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
                // 'grade_id' => $this->input->post('grade_id'),
                'status' => 1,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
           
            $this->load->model('Sections_Model');  
        
            $updated = $this->Sections_Model->update_data($data);
             
                if ($updated) {
                    
                    // create_log('Has been updated a section : '.$data['section_title']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/sections/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/sections/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['section'] = $this->master->get_single('m_section', array('id' => $id));

                if (!$this->data['section']) {
                     redirect('administrator/sections/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('sections/index', $this->data);
    }
      

    
    
}
