<?php

use Razorpay\Api\Request;

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Usercourse extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        // die('lll');
        parent::__construct();
        $this->load->model('Usercourse_Model', 'user_course', true);
        // if ($this->session->userdata('role_id') != SUPER_ADMIN) {
        //     error($this->lang->line('permission_denied'));
        //     redirect('dashboard/index');
        // }

        // echo "<pre>";
        // print_r($this->session);die;
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $school_id = $this->session->userdata('school_id');
        $grade_id = $this->session->userdata('grade_id');
        $class_id = $this->session->userdata('class_id');
        $theme = $this->session->userdata('theme');
        // print_r( $this->session);
        // die();

        
        //print_r($this->data['courses_list']);
        // print_r( $this->session);
        // die();
        //redirect('course/index');

        //$this->data['add'] = TRUE;
        // $this->data['fields'] = $this->school->get_table_fields('languages'); 
        // $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
        // $this->data['subscriptions'] = $this->school->get_subscription_list(); 
        // $this->data['schools'] = $this->school->get_school_list();
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */


    public function index()
    {
      
        //  $this->session->unset_userdata('sub_id');
        // $this->session->set_userdata('sub_id');
        
        $this->data['subject_list'] =  $this->user_course->get_course_list_user();  
        $this->data['today_chackra_list'] =  $this->user_course->get_today_chackra_list_user(); 
        $this->data['total_chackra_list'] =  $this->user_course->get_total_chackra_list_user();  
        // echo "lll<pre>";
        // print_r($this->data['total_chackra_list']);
        //     exit();  
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }

    public function volume($id)
    {
         $school_id = $this->session->userdata('school_id');

        $this->data['list_volume'] = TRUE;
        $this->data['volume_list'] =  $this->user_course->get_volume_list_user($id);
        $this->data['sub_id'] =  $this->user_course->get_sub_id($id,$school_id);
        // print_r($id);die;
        $this->session->unset_userdata('sub_id');
        $this->session->set_userdata('sub_id', $id);
      
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }

    public function unit($id)
    {
        $this->data['list_unit'] = TRUE;
        
        $this->data['unit_list'] =  $this->user_course->get_unit_list_user($id);
        // echo "lll<pre>";
        // print_r($this->data['unit_list']);
        //     die(); 
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }
    public function lessons($id)
    {
        $this->data['lessons_list'] = TRUE;
        // echo "lll<pre>$id";
        // die(); 
        $this->data['lessons_list'] =  $this->user_course->get_lessons_list_user($id);
        // echo "lll<pre>";
        // print_r($this->data['lessons_list']);
        //     die();  

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }
    public function chakra($id)
    {
        $this->data['chakra_list'] = TRUE;
        // echo "lll<pre>$id";
        // die(); 
        $this->data['chakra_list'] =  $this->user_course->get_chakra_list_user($id);
        // echo "lll<pre>";
        // print_r($this->data['chakra_list']);
        //     die();  

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }


    public function todays_chakras()
    {
        $this->data['today_chakras'] = TRUE;
        // echo "lll<pre>$id";
        // die(); $this->data['volume_list'] =  $this->user_course->get_volume_list_user($id);
        
        $this->data['todays_chakras_list'] =  $this->user_course->todays_chakras();

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }

    public function story_line($id)
    {
//         echo $id;
//   echo "lll<pre> ";
//         print_r( $this->session->userdata());
//         die(); 
        $this->session->unset_userdata('chakra_id');
        $this->session->set_userdata('chakra_id', $id);
        $this->data['story_line'] = TRUE;
        // echo "lll<pre> ";
        // print_r( $this->session->userdata('chakra_id'));
        // die(); 
        $this->data['story_line_data'] = $this->user_course->get_single('m_chakra', array('id' => $id));
        $this->load->model('Chakra_Model');
        $this->data['story_line_files'] = $this->Chakra_Model->get_single_course_file($id);

        //$this->data['story_line'] =  $this->user_course->get_story_line($id); 
        // echo "lll<pre>";
        // print_r($this->data['story_line']);
        // print_r($this->data['story_line_files']);
        //     die();  

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }
    public function story_view($id)

    {
        
        $this->data['story_line'] = 0;
        $this->data['story_view'] = TRUE;
        // echo "lll<pre>$id";
        // die(); 
        $this->data['story_view_data'] = $this->user_course->get_single('m_chakra', array('id' => $id));
        // $this->load->model('Chakra_Model');
        // $this->data['story_line_files'] = $this->Chakra_Model->get_single_course_file($id);

        // $this->data['story_line'] =  $this->user_course->get_story_line($id); 
        // echo "<pre>";
        // print_r($this->data['story_view_data']->section_id);die;
        $this->session->unset_userdata('section_id');
        $this->session->set_userdata('section_id', $this->data['story_view_data']->section_id);
        //  echo "lll<pre> ";
        // print_r( $this->session->userdata());
        // die();
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/usercourse/index', $this->data);
    }
    public function story_line_save()
    {
        
        $insertData = [];
       
        if ($this->input->method() == 'post') {
            $json_data = $this->input->raw_input_stream;
            $data = json_decode($json_data, true);
            if ($data !== null) {
                // echo "vv<pre>";
                //  print_r ($this->session);
                //         die(); 
              

                $insertData['school_id'] = $this->session->userdata('school_id');
                $insertData['student_id'] = $this->session->userdata('id');
                $insertData['grade_id'] = $this->session->userdata('grade_id');
                $insertData['class_id'] = $this->session->userdata('class_id');
                $insertData['subject_id'] = $this->session->userdata('sub_id');
                $insertData['chakra_id'] = $this->session->userdata('chakra_id');
                $insertData['created_at'] = date('Y-m-d H:i:s');
                $insertData['quiz_name'] = $data['strQuizName'];
                $insertData['score'] = $data['nScore'];
                $insertData['passing_score'] = $data['nPassingScore'];
                $insertData['pt_score'] = $data['nPtScore'];
                $insertData['time_finished'] = $data['dtmFinished'];
                $insertData['incorrect_q'] = $data['incorrectQuestionCount'];
                $insertData['correct_q'] = $data['correctQuestionCount'];
                $insertData['total_q'] = $data['totlaQuestionCount'];
                $insertData['questions'] = json_encode($data['arrQuestions']);
                
                //  echo "lll<pre>";
                //  print_r ($insertData);
                //         die(); 
                // $this->session->unset_userdata('sub_id');
                // $this->session->set_userdata('sub_id');
                $chechData = $this->user_course->get_single('m_course_result', array('student_id' => $this->session->userdata('id'), 'chakra_id' => $this->session->userdata('chakra_id')));
                if ($chechData) {
                    $response_data = array('status' => 'success', 'message' => 'Your Result Already processed');
                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode($response_data));
                } else {
                    $suceData = $this->user_course->save_result($insertData);
                    if ($suceData) {
                        $response_data = array('status' => 'success', 'message' => 'Congratulations on your Result successfully Submitted!');
                        $this->output
                            ->set_content_type('application/json')
                            ->set_output(json_encode($response_data));
                    } else {
                        $error_response = array('status' => 'error', 'message' => 'Your Result Not Save Try Again');

                        $this->output
                            ->set_content_type('application/json')
                            ->set_output(json_encode($error_response));
                    }
                }

            } else {
                echo "Error decoding JSON data.";
            }
        } else {
            echo "This endpoint only accepts POST requests.";
        }
    }
    
    
}
