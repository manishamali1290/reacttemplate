<?php

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.
 * @author          : Codetroopers Team
 * @url             : https://themeforest.net/user/codetroopers
 * @support         : yousuf361@gmail.com
 * @copyright       : Codetroopers Team
 * ********************************************************** */

class Subject extends MY_Controller
{

    public $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Subject_Model', 'subject', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashsubject/index');
        }

        $this->load->model('Subject_Model');
        $this->layout->title($this->lang->line('manage_subject') . ' | ' . SMS);
        $this->data['states'] = $this->Subject_Model->get_satate_list();
        
    }

    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface
     *
     * @param           : null
     * @return          : null
     * ********************************************************** */

    public function index()
    {
        $this->load->model('Subject_Model');

        $this->data['subjects_New'] = $this->Subject_Model->get_subjects_new_list();
        $this->data['list']         = true;
        $this->layout->view('administrator/subject/index', $this->data);
    }
 
    // public function get_boards_and_grades_by_state($id)
    // {
    //     $this->load->model('Subject_Model');
    //     $data = $this->Subject_Model->get_boards_and_grades_by_state($id);
    //     echo json_encode($data);
    // }

    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface
     *                    and store "Academic School" into database
     * @param           : null
     * @return          : null
     * ********************************************************** */

    public function add()
    {
        $this->data['edit'] = false;
        $this->data['add']  = true;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
         
                $status = $this->input->post('status');
                $status = ($status === null) ? '0' : $status;
                $data   = array(
                    'state_id'    => $this->input->post('state_id'),
                    'board_id'    => $this->input->post('board_id'),
                    'course_id'    => $this->input->post('course_id'),
                    'grade_id'    => $this->input->post('grade_id'),
                    'section_id'    => $this->input->post('section_id'),
                    'title'       => $this->input->post('state_title'),
                    'description' => $this->input->post('state_description'),
                    'status'      =>  $status,
                );
                // die($data);
                $data['created_at'] = date('Y-m-d H:i:s');
                $data['created_by'] = logged_in_user_id();
                $this->load->model('Subject_Model');

                $inserted_id = $this->Subject_Model->insert_data($data);

                if ($inserted_id) {
                    create_log('Has been created a state : ' . $data['title']);

                    success($this->lang->line('insert_success'));
                    redirect('administrator/subject/index');
                } else {

                    $this->data = $_POST;
                }
        }

        $this->load->view('administrator/subject/index/');
    }
    public function delete($id)
    {
        if ($id) {
            $this->load->model('Subject_Model');

            $inserted_id = $this->Subject_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a state ');

                success($this->lang->line('insert_success'));
            }
            redirect('administrator/subject/index');
        }
        // $this->data['add'] = TRUE;
    }

    /*****************Function edit**********************************
     * @type            : Function
     * @function name   : edit
     * @description     : Load Update "Academic School" user interface
     *                    with populated "Academic School" value
     *                    and update "Academic School" database
     * @param           : $id integer value
     * @return          : null
     * ********************************************************** */

     public function edit($id = null)
    {
        // print_r($data);
            // die('dfd');
        $this->load->model('Subject_Model');
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data   = array(
                'id'          => $id,
                'title'       => $this->input->post('state_title'),
                'description' => $this->input->post('state_description'),
                // 'state_id'    => $this->input->post('state_id'),
                // 'board_id'    => $this->input->post('board_id'),
                // 'grade_id'    => $this->input->post('grade_id'),
                // 'section_id'    => $this->input->post('section_id'),
                'status'      =>  $status,
                'modified_at' => date('Y-m-d H:i:s'),
                'modified_by' => logged_in_user_id(),
            );

            $this->load->model('Subject_Model');
            // print_r($data);
            // die();
            $updated = $this->Subject_Model->update_data($data);

            if ($updated) {

                // create_log('Has been updated a Subject : ' . $data['subject_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/subject/index');

            } else {

                error($this->lang->line('update_failed'));
                redirect('administrator/subject/edit/' . $id);

            }

        } 
        else {
            if ($id) {
                $this->data['subject'] = $this->subject->get_single('m_subject', array('id' => $id));

                if (!$this->data['subject']) {
                    redirect('administrator/subject/index');
                }
            }
        }

        $this->data['edit'] = true;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('subject/index', $this->data);
    }
     
}