<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Unit extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Unit_Model', 'master', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        $this->load->model('Unit_Model');
        
        $this->layout->title($this->lang->line('manage_unit'). ' | ' . SMS);
        $this->data['states']= $this->Unit_Model->get_satate_list(); 
               
       
        
       
    }

    
    /*****************Function index**********************************
    
    * ********************************************************** */
    public function index() {        
         $this->load->model('Unit_Model');
         //$this->data['unit']= $this->Unit_Model->get_section_list(); 
        $this->data['units']= $this->Unit_Model->get_unit_list();       
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('manage_unit'). ' | ' . SMS);
        $this->layout->view('administrator/unit/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************
  
    * ********************************************************** */
   
    public function add() {      
        
       $this->data['edit'] = FALSE;        
       $this->data['add'] = true; 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
              
                    $status = $this->input->post('status');
                    $status = ($status === null) ? '0' : $status;
                    $data = array(
                        'state_id' => $this->input->post('state_id'),
                        'board_id' => $this->input->post('board_id'),
                        'course_id'    => $this->input->post('course_id'),
                        'grade_id' => $this->input->post('grade_id'),
                        'section_id' => $this->input->post('section_id'),
                        'subject_id' => $this->input->post('subject_id'),
                        'volume_id' => $this->input->post('volume_id'),
                        'title' => $this->input->post('unit_title'),
                        'description' => $this->input->post('unit_description'),
                        'status' => $status,
                    );
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $data['created_by'] = logged_in_user_id();

                    $this->load->model('Unit_Model');
                    // print_r($data);
                    // die();
                    $inserted_id = $this->Unit_Model->insert_data($data);
    
                    if ($inserted_id) {
                        create_log('Has been created a state : '.$data['section_title']);  
                    
                        success($this->lang->line('insert_success'));
                        redirect('administrator/unit/index');
                    }
                }
                   
                    else {
                      
                        $this->data = $_POST;
                    }
                
            
    
            $this->load->view('administrator/unit/index');
        }
        public function delete($id) {
            if($id){
            $this->load->model('Unit_Model');
    
            $inserted_id = $this->Unit_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a unit ');  
            
                success($this->lang->line('insert_success'));               
            } 
            redirect('administrator/unit/index');
            }
           
        }
   
    
    /*****************Function edit**********************************
 
    * ********************************************************** */
    public function edit($id = null) {        
        $this->load->model('Unit_Model'); 
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                'title' => $this->input->post('section_title'),
                'description' => $this->input->post('section_description'),
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
                // 'grade_id' => $this->input->post('grade_id'),
                'status' =>  $status,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
           
            $this->load->model('Unit_Model');  
        
            $updated = $this->Unit_Model->update_data($data);
             
                if ($updated) {
                    
                    // create_log('Has been updated a section : '.$data['section_title']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/unit/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/unit/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['unit'] = $this->master->get_single('m_unit', array('id' => $id));

                if (!$this->data['unit']) {
                     redirect('administrator/unit/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('unit/index', $this->data);
    }
      

    
    
}
