<?php

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.
 * @author          : Codetroopers Team
 * @url             : https://themeforest.net/user/codetroopers
 * @support         : yousuf361@gmail.com
 * @copyright       : Codetroopers Team
 * ********************************************************** */

class Volume extends MY_Controller
{

    public $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Volume_Model', 'subject', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashsubject/index');
        }

        $this->load->model('Volume_Model');
        $this->layout->title($this->lang->line('manage_volume') . ' | ' . SMS);
        $this->data['states'] = $this->Volume_Model->get_satate_list();

    }

    public function index()
    {
        $this->load->model('Volume_Model');
        $this->data['volumes'] = $this->Volume_Model->get_volumes_list();
        $this->data['list']        = true;
        $this->layout->view('administrator/volume/index', $this->data);
    }

    public function add()
    {
        $this->data['edit'] = false;
        $this->data['add']  = false;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data   = array(
                'state_id'    => $this->input->post('state_id'),
                'board_id'    => $this->input->post('board_id'),
                'course_id'    => $this->input->post('course_id'),
                'grade_id'    => $this->input->post('grade_id'),
                'section_id'  => $this->input->post('section_id'),
                'subject_id'  => $this->input->post('subject_id'),
                'title'       => $this->input->post('state_title'),
                'description' => $this->input->post('state_description'),
                'status'      => $status,
            );
            // die($data);
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            $this->load->model('Volume_Model');

            $inserted_id = $this->Volume_Model->insert_data($data);

            if ($inserted_id) {
                create_log('Has been created a state : ' . $data['state_title']);

                success($this->lang->line('insert_success'));
                redirect('administrator/volume/index');
            } else {

                $this->data = $_POST;
            }
        }

        $this->load->view('administrator/volume/index/');
    }
    public function delete($id)
    {
        if ($id) {
            $this->load->model('Volume_Model');

            $inserted_id = $this->Volume_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a state ');

                success($this->lang->line('insert_success'));
            }
            redirect('administrator/volume/index');
        }
        // $this->data['add'] = TRUE;
    }

    public function edit($id = null)
    {
        $this->load->model('Volume_Model');

        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data   = array(
                'id'          => $id,
                'title'       => $this->input->post('state_title'),
                'description' => $this->input->post('state_description'),
                // 'state_id'    => $this->input->post('state_id'),
                // 'board_id'    => $this->input->post('board_id'),
                // 'grade_id'    => $this->input->post('grade_id'),
                // 'section_id'  => $this->input->post('section_id'),
                // 'subject_id'  => $this->input->post('subject_id'),
                'status'      => $status,
                'modified_at' => date('Y-m-d H:i:s'),
                'modified_by' => logged_in_user_id(),
            );

            $this->load->model('Volume_Model');

            // Debugging
            // $this->load->view('debug_view', array('debug_data' => $data));

            $updated = $this->Volume_Model->update_data($data);

            if ($updated) {
                // create_log('Has been updated a Volume : ' . $data['volume_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/volume/index');
            } else {
                error($this->lang->line('update_failed'));
                redirect('administrator/volume/edit/' . $id);
            }
        } else {
            if ($id) {
                $this->data['volume'] = $this->Volume_Model->get_single('m_volume', array('id' => $id));

                if (!$this->data['volume']) {
                    redirect('administrator/volume/index');
                }
            }
        }

        $this->data['edit'] = true;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('volume/index', $this->data);
    }

}
