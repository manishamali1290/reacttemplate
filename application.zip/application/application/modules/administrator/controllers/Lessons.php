<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Lessons extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Lessons_Model', 'master', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        $this->load->model('Lessons_Model');
        //$this->data['add'] = TRUE;
        $this->layout->title($this->lang->line('manage_lessons'). ' | ' . SMS);
        $this->data['states']= $this->Lessons_Model->get_satate_list(); 
               
       
        
       
    }

    
    /*****************Function index**********************************
    
    * ********************************************************** */
    public function index() {        
         $this->load->model('Lessons_Model');
         //$this->data['unit']= $this->Lessons_Model->get_section_list(); 
        $this->data['lessons']= $this->Lessons_Model->get_lessons_list();       
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('manage_lessons'). ' | ' . SMS);
        $this->layout->view('administrator/lessons/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************
  
    * ********************************************************** */
   
    public function add() {      
        
       $this->data['edit'] = FALSE;        
       $this->data['add'] = true; 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
              
                    $status = $this->input->post('status');
                    $status = ($status === null) ? '0' : $status;
                    $data = array(
                        'state_id' => $this->input->post('state_id'),
                        'board_id' => $this->input->post('board_id'),
                        'grade_id' => $this->input->post('grade_id'),
                        'course_id'=> $this->input->post('course_id'),
                        'section_id' => $this->input->post('section_id'),
                        'subject_id' => $this->input->post('subject_id'),
                        'volume_id' => $this->input->post('volume_id'),
                        'unit_id' => $this->input->post('unit_id'),
                        'title' => $this->input->post('lessons_title'),
                        'description' => $this->input->post('lessons_description'),
                        'status' =>  $status,
                    );
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $data['created_by'] = logged_in_user_id();

                    $this->load->model('Lessons_Model');
                    // print_r($data);
                    // die();
                    $inserted_id = $this->Lessons_Model->insert_data($data);
    
                    if ($inserted_id) {
                        create_log('Has been created a state : '.$data['section_title']);  
                    
                        success($this->lang->line('insert_success'));
                        redirect('administrator/lessons/index');
                    }
                }
                   
                    else {
                      
                        $this->data = $_POST;
                    }
                
            
    
            $this->load->view('administrator/lessons/index');
        }
        public function delete($id) {
            if($id){
            $this->load->model('Lessons_Model');
    
            $inserted_id = $this->Lessons_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a unit ');  
            
                success($this->lang->line('insert_success'));               
            } 
            redirect('administrator/lessons/index');
            }
           
        }
   
    
    /*****************Function edit**********************************
 
    * ********************************************************** */
    public function edit($id = null) {        
        $this->load->model('Lessons_Model'); 
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
                // 'grade_id' => $this->input->post('grade_id'),
                // 'section_id' => $this->input->post('section_id'),
                // 'subject_id' => $this->input->post('subject_id'),
                // 'volume_id' => $this->input->post('volume_id'),
                // 'unit_id' => $this->input->post('unit_id'),
                'title' => $this->input->post('lessons_title'),
                'description' => $this->input->post('lessons_description'),
                'status' =>  $status,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
           
            $this->load->model('Lessons_Model');  
        
            $updated = $this->Lessons_Model->update_data($data);
             
                if ($updated) {
                    
                    // create_log('Has been updated a section : '.$data['section_title']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/lessons/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/lessons/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['lesson'] = $this->master->get_single('m_lessons', array('id' => $id));

                if (!$this->data['lesson']) {
                     redirect('administrator/lessons/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('lessons/index', $this->data);
    }
      

    
    
}
