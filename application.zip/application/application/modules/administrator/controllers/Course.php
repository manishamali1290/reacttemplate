<?php

use Razorpay\Api\Request;

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Course extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        // die('lll');
        parent::__construct();
        $this->load->model('Course_Model', 'course', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashboard/index');
        }
        $this->load->model('Course_Model');
        $this->data['states'] = $this->Course_Model->get_satate_list();

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);

        //$this->data['add'] = TRUE;
        // $this->data['fields'] = $this->school->get_table_fields('languages'); 
        // $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
        // $this->data['subscriptions'] = $this->school->get_subscription_list(); 
        // $this->data['schools'] = $this->school->get_school_list();
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function index()
    {

        $this->data['courses'] = $this->course->get_course_list();

        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/course/index', $this->data);
    }

    private function _prepare_course_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');

        $this->form_validation->set_rules('course_title', 'Title', 'trim|required');
        // $this->form_validation->set_rules('course_description', 'Description', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('board_id', 'Board', 'trim|required');
    }

    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface                 
     *                    and store "Academic School" into database 
     * @param           : null
     * @return          : null 
     * ********************************************************** */


    public function add()
    {


        if ($_POST) {
            $this->_prepare_course_validation();

            if ($this->form_validation->run() === TRUE) {

                $data = array(
                    'title' => $this->input->post('course_title'),
                    'description' => $this->input->post('course_description'),
                    'state_id' => $this->input->post('state_id'),
                    'board_id' => $this->input->post('board_id'),
                    'status' => 1,
                );

                $data['created_at'] = date('Y-m-d H:i:s');
                $data['created_by'] = logged_in_user_id();


                $inserted_id = $this->course->insert_data($data);


                if ($inserted_id) {

                    success($this->lang->line('insert_success'));
                    redirect('administrator/course/index');
                } else {
                    // Handle insertion failure
                    echo 'Failed to insert course data.';
                }
            } else {
                // $validation_errors = validation_errors(); // Get all validation errors
                // You can echo or log $validation_errors to see specific errors

                // Display error message
                // error($validation_errors);
                // redirect('administrator/course/index');
                error('Please fill all required fields!');
                redirect('administrator/course/index');
            }
        }
    }

    public function delete($id)
    {
        if ($id) {
            $data = array(
                'id' => $id,
                'status' => 0,
            );

            $updated = $this->course->update_data($data);
            if ($updated) {
                create_log('Has been Delete a Course ');

                success($this->lang->line('delete_success'));
            }
            redirect('administrator/course/index');
        }
    }

    /*****************Function edit**********************************
     * @type            : Function
     * @function name   : edit
     * @description     : Load Update "Academic School" user interface                 
     *                    with populated "Academic School" value 
     *                    and update "Academic School" database    
     * @param           : $id integer value
     * @return          : null 
     * ********************************************************** */
    public function edit($id = null)
    {

        //check_permission(EDIT);

        if ($_POST) {

            $data = array(
                'id' => $id,
                'title' => $this->input->post('course_title'),
                'description' => $this->input->post('course_description'),
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
            );
            
            if ($this->input->post('status') == "") {
                $data['status'] = 0;
            } else {
                $data['status'] = 1;
            }

            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();

            $updated = $this->course->update_data($data);

            if ($updated) {

                // create_log('Has been updated a course : ' . $data['course_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/course/index');
            } else {

                error($this->lang->line('update_failed'));
                redirect('administrator/course/edit/' . $id);
            }
        } else {

            // die('lll');
            if ($id) {
                $this->load->model('Course_Model');
                $this->data['course'] = $this->course->get_single('m_course', array('id' => $id));


// echo"<pre>"; print_r($this->data); die;
                if (!$this->data['course']) {
                    redirect('administrator/course/index');
                }
            }
        }


        $this->data['edit'] = TRUE;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('course/index', $this->data);
    }


    // public function get_single_course($course_id)
    // {
    //     if ($course_id) {

    //         $this->load->model('Course_Model');

    //         $this->data['S_course'] = $this->course->get_single_course($course_id);
    //         echo $this->load->view('course/get-single-course', $this->data);
    //     }
    // }
}
