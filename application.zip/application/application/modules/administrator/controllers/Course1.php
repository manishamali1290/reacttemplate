<?php

use Razorpay\Api\Request;

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Course extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        // die('lll');
        parent::__construct();
        $this->load->model('Course_Model', 'course', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashboard/index');
        }
        $this->load->model('Course_Model');
        $this->data['states'] = $this->Course_Model->get_satate_list();

        $this->layout->title($this->lang->line('course') . ' | ' . SMS);

        //$this->data['add'] = TRUE;
        // $this->data['fields'] = $this->school->get_table_fields('languages'); 
        // $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
        // $this->data['subscriptions'] = $this->school->get_subscription_list(); 
        // $this->data['schools'] = $this->school->get_school_list();
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function index()
    {

        $this->data['courses'] = $this->course->get_course_list();
        // print_r(  $this->data['courses']);
        // die();
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/course/index', $this->data);
    }



    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface                 
     *                    and store "Academic School" into database 
     * @param           : null
     * @return          : null 
     * ********************************************************** */

    private function _prepare_course_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');

        $this->form_validation->set_rules('course_title', 'Title', 'trim|required');
    }

    public function add()
    {
        // echo $this->input->post('status'); echo"ll"; die;
        $uploads_folder = 'assets/uploads/course';
        $unique_folder = $uploads_folder . '/' . uniqid();

        if ($_POST) {
            $this->_prepare_course_validation();

            // Additional validation for zip file extension
            $fileExtension = pathinfo($_FILES['zip_file']['name'], PATHINFO_EXTENSION);

            if ($fileExtension !== 'zip') {
                error('Only ZIP file is allowed!');
                redirect('administrator/course/index');
            }
            if ($this->form_validation->run() === TRUE) {

                if (!file_exists($unique_folder) && !is_dir($unique_folder)) {
                    mkdir($unique_folder, 0755, true);
                }

                $zip_file = $_FILES['zip_file']['tmp_name'];
                $destination = $unique_folder . '/' . $_FILES['zip_file']['name'];

                if (move_uploaded_file($zip_file, $destination)) {
                    $zip = new ZipArchive;

                    if ($zip->open($destination) === TRUE) {
                        $zip->extractTo($unique_folder);
                        $zip->close();

                        // Remove the original ZIP file
                        unlink($destination);

                        // print_r( $this->input->post());
                        // die();
                        $data = array(
                            'title' => $this->input->post('course_title'),
                            'description' => $this->input->post('course_description'),
                            'state_id' => $this->input->post('state_id'),
                            'board_id' => $this->input->post('board_id'),
                            'grade_id' => $this->input->post('grade_id'),
                            'section_id' => $this->input->post('section_id'),
                            'subject_id' => $this->input->post('subject_id'),
                            'volume_id' => $this->input->post('volume_id'),
                            'unit_id' => $this->input->post('unit_id'),
                            'lessons_id' => $this->input->post('lessons_id'),
                            'chakra_id' => $this->input->post('chakra_id'),
                            // 'active_time' =>date('Y-m-d H:i:s'),
                            // 'inactive_time' => date('Y-m-d H:i:s'),
                            'file' => $unique_folder,
                        );

                        if ($this->input->post('status') == "") {
                            $data['status'] = 0;
                        } else {
                            $data['status'] = 1;
                        }

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['created_by'] = logged_in_user_id();

                        // echo"<pre>"; print_r($data);
                        // die();
                        $inserted_id = $this->course->insert_data($data);

                        //  success($this->lang->line('insert_success'));
                        //  redirect('administrator/course/index');
                        if ($inserted_id) {
                            //     echo"<pre>"; print_r($data);
                            // die();


                            // Validation and handling for uploaded files
                            // echo"<pre>"; print_r( $this->input->post('file_name'));
                            //               die();
                            $total_file_count = count($_FILES['file']['name']);

                            for ($i = 0; $i < $total_file_count; $i++) {
                                $tmpFilePath = $_FILES['file']['tmp_name'][$i];
                                $tmpFileName = $this->input->post('file_name')[$i];

                                if ($tmpFilePath != "") {
                                    $originalFileName = $_FILES['file']['name'][$i];
                                    $fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);

                                    // Validate file type and size here before moving/uploading
                                    $uniqueFileName = time() . '_' . mt_rand(1000, 9999) . '.' . $fileExtension;

                                    // Move uploaded files to the destination
                                    $newFilePath = 'assets/uploads/course_file/' . $uniqueFileName;


                                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                                        // Insert file details into 'course_file' table
                                        $course_file_data = array(
                                            'path' => $newFilePath,
                                            'course_id' => $inserted_id,
                                            'file_name' => $tmpFileName // Make sure this ID exists in the 'course' table
                                            // You can add 'deleted_at' with NULL if needed
                                        );

                                        $course_file_data['created_at'] = date('Y-m-d H:i:s');
                                        $inserted_cf_id = $this->course->insert_course_file($course_file_data);
                                        if ($inserted_cf_id) {
                                            echo "File inserted successfully.";
                                        } else {
                                            echo "Failed to insert file details into the database.";
                                        }
                                    } else {
                                        echo 'File upload failed. Error: ' . $_FILES['file']['error'][$i];
                                        // Log or handle the error appropriately
                                    }
                                }
                            }
                            success($this->lang->line('insert_success'));
                            redirect('administrator/course/index');
                        } else {
                            // Handle insertion failure
                            echo 'Failed to insert course data.';
                        }
                    } else {
                        echo 'Failed to open the ZIP file.';
                    }
                } else {
                    echo 'Failed to move the uploaded file.';
                }
            } else {

                error('Please fill all required fields!');
                redirect('administrator/course/index');
            }
        }
    }


    public function check_zip_file($str)
    {
        $allowed_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');

        // Check if the uploaded file is a ZIP file
        if (!in_array($_FILES['zip_file']['type'], $allowed_types)) {
            $this->form_validation->set_message('check_zip_file', 'The uploaded file must be a ZIP file.');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function delete($id)
    {
        if ($id) {
            $inserted_id = $this->course->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a state ');

                success($this->lang->line('insert_success'));
            }
            redirect('administrator/course/index');
        }
    }

    public function delete_file($id)
    {
        if ($id) {
            $inserted_id = $this->course->delete_data_file($id);
            if ($inserted_id) {
                create_log('Has been Delete a file ');

                success($this->lang->line('insert_success'));
            }
            redirect('administrator/course/index');
        }
    }


    /*****************Function edit**********************************
     * @type            : Function
     * @function name   : edit
     * @description     : Load Update "Academic School" user interface                 
     *                    with populated "Academic School" value 
     *                    and update "Academic School" database    
     * @param           : $id integer value
     * @return          : null 
     * ********************************************************** */
    public function edit($id = null)
    {

        //check_permission(EDIT);

        if ($_POST) {


            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                'title' => $this->input->post('course_title'),
                'description' => $this->input->post('course_description'),
                'state_id' => $this->input->post('state_id'),
                'board_id' => $this->input->post('board_id'),
                'grade_id' => $this->input->post('grade_id'),
                'section_id' => $this->input->post('section_id'),
                'subject_id' => $this->input->post('subject_id'),
                'volume_id' => $this->input->post('volume_id'),
                'unit_id' => $this->input->post('unit_id'),
                'lessons_id' => $this->input->post('lessons_id'),
                'chakra_id' => $this->input->post('chakra_id'),
                // 'active_time' =>date('Y-m-d H:i:s'),
                // 'inactive_time' => date('Y-m-d H:i:s'),
                'status' => $status,
            );
            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();
            $updated = $this->course->update_data($data);
            if ($updated) {

                create_log('Has been updated a course : ' . $data['course_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/course/index');
            } else {
                //             print_r($data);
                //             print_r($id);
                // die();

                error($this->lang->line('update_failed'));
                redirect('administrator/course/edit/' . $id);
            }
        } else {
            if ($id) {
                $this->load->model('Course_Model');
                $this->data['course'] = $this->course->get_single('m_course', array('id' => $id));
                $this->data['course_file'] = $this->Course_Model->get_single_course_file($id);
                // print_r($this->data['course_file'] );
                // die();

                if (!$this->data['course']) {
                    redirect('administrator/course/index');
                }
            }
        }


        $this->data['edit'] = TRUE;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('course/index', $this->data);
    }




    /*****************Function _get_posted_school_data**********************************
     * @type            : Function
     * @function name   : _get_posted_school_data
     * @description     : Prepare "Academic School" user input data to save into database                  
     *                       
     * @param           : null
     * @return          : $data array(); value 
     * ********************************************************** */
    private function _get_posted_school_data()
    {


        $data = elements($_POST);

        if ($this->input->post('id')) {
            $data['status'] = $this->input->post('status');
            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();
        } else {

            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }



        return $data;
    }



    /*****************Function _upload_logo**********************************
     * @type            : Function
     * @function name   : _upload_logo
     * @description     : Process to upload institute logo in the server                  
     *                     and return logo name   
     * @param           : null
     * @return          : $logo string value 
     * ********************************************************** */
    private function _upload_logo()
    {

        $prevoius_logo = @$_POST['logo_prev'];
        $logo_name = $_FILES['logo']['name'];
        $logo_type = $_FILES['logo']['type'];
        $logo = '';


        if ($logo_name != "") {
            if (
                $logo_type == 'image/jpeg' || $logo_type == 'image/pjpeg' ||
                $logo_type == 'image/jpg' || $logo_type == 'image/png' ||
                $logo_type == 'image/x-png' || $logo_type == 'image/gif'
            ) {

                $destination = 'assets/uploads/logo/';

                $file_type = explode(".", $logo_name);
                $extension = strtolower($file_type[count($file_type) - 1]);
                $logo_path = time() . '-school-admin-logo.' . $extension;

                copy($_FILES['logo']['tmp_name'], $destination . $logo_path);

                if ($prevoius_logo != "") {
                    // need to unlink previous image
                    if (file_exists($destination . $prevoius_logo)) {
                        @unlink($destination . $prevoius_logo);
                    }
                }

                $logo = $logo_path;
            }
        } else {
            $logo = $prevoius_logo;
        }

        return $logo;
    }

    /*****************Function _upload_frontend_logo**********************************
     * @type            : Function
     * @function name   : _upload_frontend_logo
     * @description     : Process to upload school front end logo in the server                  
     *                     and return logo name   
     * @param           : null
     * @return          : $logo string value 
     * ********************************************************** */
    private function _upload_frontend_logo()
    {

        $prevoius_logo = @$_POST['frontend_logo_prev'];
        $logo_name = $_FILES['frontend_logo']['name'];
        $logo_type = $_FILES['frontend_logo']['type'];
        $logo = '';


        if ($logo_name != "") {
            if (
                $logo_type == 'image/jpeg' || $logo_type == 'image/pjpeg' ||
                $logo_type == 'image/jpg' || $logo_type == 'image/png' ||
                $logo_type == 'image/x-png' || $logo_type == 'image/gif'
            ) {

                $destination = 'assets/uploads/logo/';

                $file_type = explode(".", $logo_name);
                $extension = strtolower($file_type[count($file_type) - 1]);
                $logo_path = time() . '-school-front-logo.' . $extension;

                copy($_FILES['frontend_logo']['tmp_name'], $destination . $logo_path);

                if ($prevoius_logo != "") {
                    // need to unlink previous image
                    if (file_exists($destination . $prevoius_logo)) {
                        @unlink($destination . $prevoius_logo);
                    }
                }

                $logo = $logo_path;
            }
        } else {
            $logo = $prevoius_logo;
        }

        return $logo;
    }

    public function get_single_course($course_id)
    {
        if ($course_id) {

            $this->load->model('Course_Model');
            // $this->data['S_course'] = $this->course->get_single('m_course', array('id' => $course_id));
            // echo $this->load->view('course/get-single-course', $this->data);

            // $course_id = $this->input->post('course_id');       
            $this->data['S_course'] = $this->course->get_single_course($course_id);
            $this->data['S_course_files'] = $this->course->get_single_course_file($course_id);
            echo $this->load->view('course/get-single-course', $this->data);
        }
    }
}
