<?php

use Razorpay\Api\Request;

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Course_access extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        // die('lll');
        parent::__construct();        
        $this->load->model('School_Model', 'school', true);
        $this->load->model('Course_access_Model', 'course_access', true);
        $this->layout->title($this->lang->line('course') .' | '.  $this->session->userdata('role_id').' | ' . SMS);
        $this->data['fields'] = $this->school->get_table_fields('languages'); 
        $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
      
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function index()
    {
        $inserted_row =$this->school->get_single('schools', array('id' => $this->session->userdata('school_id')));
        if ($inserted_row) {
            $course_ids = explode(',', $inserted_row->course_id);
            $this->data['courses_list'] = $this->course_access->get_course_list($course_ids);
        } 
        // echo "<pre>";
        // print_r($this->data['courses_list']);
        // die();
    $this->data['list'] = TRUE;
    $this->layout->title($this->lang->line('course') . ' List | ' . SMS);
    $this->layout->view('administrator/course_access/index', $this->data);
    }

    public function list_chakra($id)
    {
        $this->data['list_chakra'] = true;
       // $this->load->model('Course_access_Model');
        $this->data['chakra_list'] = $this->course_access->get_chakra_modal($id);
        $this->layout->title($this->lang->line('course') . ' List | ' . SMS);
        $this->layout->view('administrator/course_access/index', $this->data);
    }
    public function edit_chakra($id)
    {
        $this->data['edit_chakra'] = true;
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                'active_time' => $this->input->post('active_time'),
                'inactive_time' => $this->input->post('inactive_time'),
                // 'grade_id' => $this->input->post('grade_id'),
                // 'section_id' => $this->input->post('section_id'),
                // 'subject_id' => $this->input->post('subject_id'),
                // 'volume_id' => $this->input->post('volume_id'),
                // 'unit_id' => $this->input->post('unit_id'),
                // 'lessons_id' => $this->input->post('lessons_id'),
                //'description' => $this->input->post('chakra_description'),
                'status' => $status,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),);
                // echo "<pre>";
                // print_r(  $data );
                // die();
                
            $updated = $this->course_access->update_chakra_data($data);
             
            if ($updated) {
                
                //create_log('Has been updated a school : '.$data['board_title']);
                success($this->lang->line('update_success'));
                redirect('administrator/course_access/index');    
                
            } else {
                
                error($this->lang->line('update_failed'));
                redirect('administrator/course_access/edit_chakra/' . $id);
                
            }

        } 
        else {
            if ($id) {
                $this->data['chakra'] = $this->course_access->get_single('m_course_relation', array('id' => $id));                
               // $this->data['S_chakra_files'] = $this->chakra->get_single_course_file($id);
            //    echo "<pre>";
            //     print_r(  $this->data['chakra'] );
            //     die();
                if (!$this->data['chakra']) {
                    redirect('administrator/course_access/index');
                }
            }
        }

       // $this->load->model('Course_access_Model');
        $this->data['chakra_list'] = $this->course_access->get_chakra_modal($id);
        $this->layout->title($this->lang->line('course') . ' List | ' . SMS);
        $this->layout->view('administrator/course_access/index', $this->data);
    }
    
   


    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface                 
     *                    and store "Academic School" into database 
     * @param           : null
     * @return          : null 
     * ********************************************************** */

    private function _prepare_course_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');

        $this->form_validation->set_rules('course_title', 'Title', 'trim|required');
    }

   

    private function _get_posted_school_data()
    {


        $data = elements($_POST);

        if ($this->input->post('id')) {
            $data['status'] = $this->input->post('status');
            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();
        } else {

            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }



        return $data;
    }
    


    public function get_course_modal($school_id){
        if ($school_id) {            
        //     $this->load->model('Course_access_Model');
        //        // $this->data['S_course'] = $this->course->get_single('m_course', array('id' => $course_id));
        //        // echo $this->load->view('course/get-single-course', $this->data);
        
        //    // $course_id = $this->input->post('course_id');       
        $this->data['S_course'] = $this->course->get_course_modal($school_id);
        //     $this->data['S_course_files'] = $this->course->get_single_course_file($course_id);
           echo $this->load->view('course_access/get-single-course', $this->data);
        }
            
         }
         public function get_course_update($course_id){
            if ($course_id) { 
                $current_status = $this->db->get_where('m_course_relation', array('id' => $course_id))->row()->deleted_by_admin;
                $new_status = ($current_status == 0) ? 1 : 0;
                $this->db->where('id', $course_id);
                $this->db->update('m_course_relation', array('deleted_by_admin' => $new_status));
                $response = array(
                    'success' => true,
                    'status'  => $new_status,
                    'message' => 'Status updated successfully'
                );
                echo json_encode($response);
            }
                
             }
             public function get_single_course($course_id){
                if ($course_id) {
                    
                $this->load->model('Course_access_Model');
                   // $this->data['S_course'] = $this->course->get_single('m_course', array('id' => $course_id));
                   // echo $this->load->view('course/get-single-course', $this->data);
            
               // $course_id = $this->input->post('course_id');       
                $this->data['S_course'] = $this->course->get_single_course($course_id);
                $this->data['S_course_files'] = $this->course->get_single_course_file($course_id);
               echo $this->load->view('course/get-single-course', $this->data);
            }
                
             }
             public function get_chakra_modal($course_id){
                if ($course_id) {                       
                $this->load->model('Course_access_Model');
                $this->data['S_chakra'] = $this->Course_access_Model->get_chakra_modal($course_id);
               
                //     $this->data['S_course_files'] = $this->syn_course->get_single_course_file($course_id);
                   echo $this->load->view('course_access/get-chakra-list', $this->data);
                }
                    
                 }
}
