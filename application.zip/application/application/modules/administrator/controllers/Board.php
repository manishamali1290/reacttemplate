<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* * *****************School.php**********************************
	
 * ********************************************************** */

class Board extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Board_Model', 'master', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        
        $this->layout->title($this->lang->line('manage_board'). ' | ' . SMS);
     
    }

    
    /*****************Function index**********************************
    
    * ********************************************************** */
    public function index() {

        
        $this->load->model('Board_Model');
        $this->data['states']= $this->Board_Model->get_satate_list(); 
        $this->data['boards']= $this->Board_Model->get_board_list();       
        $this->data['list'] = TRUE;
        $this->layout->view('administrator/board/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************

    * ********************************************************** */
   
    public function add() {
        
       $this->data['edit'] = FALSE; 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('state', 'State', 'required');
                $this->form_validation->set_rules('board_title', 'Title', 'required');

                if ($this->form_validation->run() == true) {
                    $status = $this->input->post('status');
                    $status = ($status === null) ? '0' : $status;
                    $data = array(
                        'state_id' => $this->input->post('state'),
                        'title' => $this->input->post('board_title'),
                        'description' => $this->input->post('board_description'),
                        'status' => 1,
                        
                    );
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $data['created_by'] = logged_in_user_id();
                    $this->load->model('Board_Model');
    
                    $inserted_id = $this->Board_Model->insert_data($data);
    
                    if ($inserted_id) {
                       // create_log('Has been created a state : '.$data['board_title']);  
                    
                        success($this->lang->line('insert_success'));
                        redirect('administrator/board/index');
                    } else {
                      
                        $this->data = $_POST;
                    }
                }
            }
    
            $this->load->view('administrator/board/add');
        }
        public function delete($id) {
            if($id){
            $this->load->model('Board_Model');
    
            $inserted_id = $this->Board_Model->delete_data($id);
            if ($inserted_id) {
                create_log('Has been Delete a Board ');  
            
                success($this->lang->line('delete_success'));               
            } 
            redirect('administrator/board/index');
            }
            $this->data['add'] = TRUE;
        }
   
    
    /*****************Function edit**********************************
 
    * ********************************************************** */
    public function edit($id = null) {
        
        $this->load->model('Board_Model');   
        
        $this->data['states']= $this->Board_Model->get_satate_list(); 
      
        //check_permission(EDIT);
       
        if ($_POST) {
           
          
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                // 'state_id' => $this->input->post('state'),
                'title' => $this->input->post('board_title'),
                'description' => $this->input->post('board_description'),
                'status' => 1,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
           
    
            $updated = $this->Board_Model->update_data($data);
             
                if ($updated) {
                    
                    // create_log('Has been updated a school : '.$data['board_title']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/board/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/board/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['board'] = $this->master->get_single('m_board', array('id' => $id));

                if (!$this->data['board']) {
                     redirect('administrator/board/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('board/index', $this->data);
    }
    
   
}
