<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Chakra extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Chakra_Model', 'chakra', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
       // $this->load->model('Chakra_Model');
        //$this->data['add'] = TRUE;
        $this->layout->title($this->lang->line('manage_chakra'). ' | ' . SMS);
        $this->data['states']= $this->chakra->get_satate_list(); 
               
       
        
       
    }

    
    /*****************Function index**********************************
    
    * ********************************************************** */
    public function index() {        
         //$this->load->model('Chakra_Model');
         //$this->data['unit']= $this->Chakra_Model->get_section_list(); 
        $this->data['chakras']= $this->chakra->get_chakra_list();       
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('manage_chakra'). ' | ' . SMS);
        $this->layout->view('administrator/chakra/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************
  
    * ********************************************************** */
   
  
    public function add()
    {
        // echo $this->input->post('status'); echo"ll"; die;
        $uploads_folder = 'assets/uploads/course';
        $unique_folder = $uploads_folder . '/' . uniqid();

        if ($_POST) {
            // $this->_prepare_course_validation();

            // Additional validation for zip file extension
            $fileExtension = pathinfo($_FILES['zip_file']['name'], PATHINFO_EXTENSION);

            if ($fileExtension !== 'zip') {
                error('Only ZIP file is allowed!');
                redirect('administrator/course/index');
            }
            // if ($this->form_validation->run() === TRUE) {

                if (!file_exists($unique_folder) && !is_dir($unique_folder)) {
                    mkdir($unique_folder, 0755, true);
                }

                $zip_file = $_FILES['zip_file']['tmp_name'];
                $destination = $unique_folder . '/' . $_FILES['zip_file']['name'];

                if (move_uploaded_file($zip_file, $destination)) {
                    $zip = new ZipArchive;

                    if ($zip->open($destination) === TRUE) {
                        $zip->extractTo($unique_folder);
                        $zip->close();

                        // Remove the original ZIP file
                        unlink($destination);
                        // die('kkk');
                        // print_r( $this->input->post());
                        // die();
                        $data = array(
                            'title' => $this->input->post('chakra_title'),
                            'description' => $this->input->post('chakra_description'),
                            'state_id' => $this->input->post('state_id'),
                            'board_id' => $this->input->post('board_id'),                           
                            'course_id' => $this->input->post('course_id'),
                            'grade_id' => $this->input->post('grade_id'),
                            'section_id' => $this->input->post('section_id'),
                            'subject_id' => $this->input->post('subject_id'),
                            'volume_id' => $this->input->post('volume_id'),
                            'unit_id' => $this->input->post('unit_id'),
                            'lessons_id' => $this->input->post('lessons_id'),
                            // 'chakra_id' => $this->input->post('chakra_id'),
                            // 'active_time' =>date('Y-m-d H:i:s'),
                            // 'inactive_time' => date('Y-m-d H:i:s'),
                            'file' => $unique_folder,
                        );

                        if ($this->input->post('status') == "") {
                            $data['status'] = 0;
                        } else {
                            $data['status'] = 1;
                        }
                        
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['created_by'] = logged_in_user_id();
                        
                        // echo"<pre>"; print_r($data);
                        // die();
                        
                        $this->load->model('Chakra_Model');
                        $inserted_id = $this->Chakra_Model->insert_data($data);

                        //  success($this->lang->line('insert_success'));
                        //  redirect('administrator/course/index');
                        if ($inserted_id) {
                   
                            // Validation and handling for uploaded files
                            // echo"<pre>"; print_r( $this->input->post('file_name'));
                            //               die();
                            $total_file_count = count($_FILES['file']['name']);
                            // echo"<pre>"; 
                            // print_r( $total_file_count);
                            // die();
                            for ($i = 0; $i < $total_file_count; $i++) {
                                $tmpFilePath = $_FILES['file']['tmp_name'][$i];
                                $tmpFileName =$this->input->post('file_name')[$i];

                                if ($tmpFilePath != "") {
                                    $originalFileName = $_FILES['file']['name'][$i];
                                    $fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);

                                    // Validate file type and size here before moving/uploading
                                    $uniqueFileName = time() . '_' . mt_rand(1000, 9999) . '.' . $fileExtension;

                                    // Move uploaded files to the destination
                                    $newFilePath = 'assets/uploads/course_file/' . $uniqueFileName;


                                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                                        // Insert file details into 'course_file' table
                                        $course_file_data = array(
                                            'path' => $newFilePath,
                                            'chakra_id' => $inserted_id,
                                            'file_name'=>$tmpFileName // Make sure this ID exists in the 'course' table
                                            // You can add 'deleted_at' with NULL if needed
                                        );

                                        $course_file_data['created_at'] = date('Y-m-d H:i:s');
                                        $course_file_data['created_by'] = logged_in_user_id();
                                       
                                        
                                        $inserted_cf_id = $this->Chakra_Model->insert_course_file($course_file_data);
                                        // if ($inserted_cf_id) {
                                        //     success($this->lang->line('update_success'));
                                        // } else {
                                        //     error($this->lang->line('update_failed'));
                                        // }
                                    } else {
                                        error($this->lang->line('update_failed'));
                                        
                                         redirect('administrator/chakra/index');
                                        // Log or handle the error appropriately
                                    }
                                }
                            }
                            success($this->lang->line('insert_success'));
                            redirect('administrator/chakra/index');
                        } else {
                            // Handle insertion failure
                            error($this->lang->line('update_failed'));
                            
                            redirect('administrator/chakra/index');
                        }
                    } else {
                        error($this->lang->line('update_failed'));
                        redirect('administrator/chakra/index');
                    }
                } else {
                    error($this->lang->line('update_failed'));
                    redirect('administrator/chakra/index');
                }
            // } else {

            //     error('Please fill all required fields!');
            //     redirect('administrator/chakra/index');
            // }
        }
        else {
            $this->layout->view('chakra/add', $this->data);
        }
       
    }
    private function _prepare_course_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');
        $this->form_validation->set_rules('chakra_title', 'Title', 'trim|required');
    }


   
    
    /*****************Function edit**********************************
 
    * ********************************************************** */
    public function edit($id = null) {        
        $this->load->model('Chakra_Model'); 
        if ($_POST) {
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                // 'state_id' => $this->input->post('state_id'),
                // 'board_id' => $this->input->post('board_id'),
                // 'grade_id' => $this->input->post('grade_id'),
                // 'section_id' => $this->input->post('section_id'),
                // 'subject_id' => $this->input->post('subject_id'),
                // 'volume_id' => $this->input->post('volume_id'),
                // 'unit_id' => $this->input->post('unit_id'),
                // 'lessons_id' => $this->input->post('lessons_id'),
                'title' => $this->input->post('chakra_title'),
                'description' => $this->input->post('chakra_description'),
                'status' => $status,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
           
            $this->load->model('Chakra_Model');  
        
            $updated = $this->Chakra_Model->update_data($data);
            
            $datas = array('course_name'=>$this->input->post('chakra_title'));
            $updated = $this->Chakra_Model->update_data_course($datas,$id);
             
                if ($updated) {
                    
                    // create_log('Has been updated a section : '.$data['chakra_title']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/chakra/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/chakra/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['chakra'] = $this->chakra->get_single('m_chakra', array('id' => $id));                
                $this->data['S_chakra_files'] = $this->chakra->get_single_course_file($id);
                // print_r(  $this->data['S_chakra_files'] );
                // die();
                if (!$this->data['chakra']) {
                     redirect('administrator/chakra/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('chakra/index', $this->data);
    }

    
    public function get_chakra_modal($chakra_id){
        if ($chakra_id) {            
        $this->data['S_chakra'] = $this->chakra->get_single('m_chakra', array('id' => $chakra_id)); 
        $this->data['S_chakra_files'] = $this->chakra->get_single_course_file($chakra_id);
        echo $this->load->view('chakra/get-single-chaka', $this->data);
        }
    
}
// public function delete($id) {
//     if($id){
  

//     $inserted_id = $this->chakra->delete_data($id);
//     if ($inserted_id) {
//         create_log('Has been Delete a chakra ');  
    
//         success($this->lang->line('insert_success'));               
//     } 
//     redirect('administrator/chakra/index');
//     }
   
// }

public function delete($id) {
    if($id){
        $row = $this->chakra->get_single('m_chakra', array('id' => $id));
        $filePath = $row->file;

        // Check if the file path is a directory
        if(is_dir($filePath)) {
            // Check if directory is writable
            if (!is_writable($filePath)) {
                $this->session->set_flashdata('error', $this->lang->line('delete_failed'));
                redirect('administrator/chakra/index');
            }
            
            // Open a directory handle
            $dirHandle = opendir($filePath);
            
            // Loop through all files and folders in the directory
            while (($file = readdir($dirHandle)) !== false) {
                if ($file != "." && $file != "..") {
                    $fileToDelete = $filePath . DIRECTORY_SEPARATOR . $file;
                    if (is_dir($fileToDelete)) {
                        // If it's a directory, call delete recursively
                        $this->deleteDirectory($fileToDelete);
                    } else {
                        // If it's a file, just unlink it
                        unlink($fileToDelete);
                    }
                }
            }
            // Close directory handle
            closedir($dirHandle);
            
            // Remove the directory itself
            if(rmdir($filePath)) {
                $this->session->set_flashdata('success', $this->lang->line('delete_success'));
            } else {
                $this->session->set_flashdata('error', $this->lang->line('delete_Failed'));
            }
        } else {
            // If it's not a directory, just delete the file
            if(unlink($filePath)) {
                $this->session->set_flashdata('success', 'File deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Error occurred while deleting file');
            }
        }

        // Proceed with the deletion of the chakra data
        $inserted_id = $this->chakra->delete_data($id);
        $this->db->delete('m_chakra_file', array('chakra_id' => $id)); 
        $this->db->delete('m_course_relation', array('chakra_id' => $id)); 
        $this->db->delete('m_course_result', array('chakra_id' => $id)); 

        // Check if chakra data deletion was successful
        if ($inserted_id) {
            create_log('Has been Delete a chakra ');  
            $this->session->set_flashdata('success', $this->lang->line('delete_success'));
        } 

        // Redirect to the chakra index page
        redirect('administrator/chakra/index');
    }
}


// Function to delete a directory recursively
private function deleteDirectory($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . DIRECTORY_SEPARATOR . $object)) {
                    $this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $object);
                } else {
                    unlink($dir . DIRECTORY_SEPARATOR . $object);
                }
            }
        }
        rmdir($dir);
    }
}

}
