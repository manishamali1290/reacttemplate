<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Master extends MY_Controller {

    public $data = array();
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Master_Model', 'master', true);
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        //$this->data['themes'] = $this->setting->get_list('themes', array(), '','', '', 'id', 'ASC');
        //$this->data['setting'] = $this->setting->get_single('global_setting', array('status'=>1));
        //$this->data['fields'] = $this->setting->get_table_fields('languages');
        
        $this->layout->title($this->lang->line('manage_state'). ' | ' . SMS);
        
    }

    
    /*****************Function index**********************************
   
    * ********************************************************** */
    public function index() {

        
        $this->load->model('Master_Model');
        $this->data['states']= $this->Master_Model->get_satate_list();  
         $this->data['list'] = TRUE;
        //$this->layout->title($this->lang->line('manage_state'). ' | ' . SMS);
        $this->layout->view('administrator/master/index', $this->data);            
       
    }

      
    
    /*****************Function add**********************************
    *
    * ********************************************************** */
   
    public function add() {
        
       $this->data['edit'] = FALSE; 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('state_title', 'Title', 'required');
                if ($this->form_validation->run() == true) {
                    $status = $this->input->post('status');
                    $status = ($status === null) ? '0' : $status;
                    $data = array(
                        'title' => $this->input->post('state_title'),
                        'description' => $this->input->post('state_description'),
                       // 'status' => $status,
                        'status' => 1,
                    );
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $data['created_by'] = logged_in_user_id();
                    $this->load->model('Master_Model');
    
                    $inserted_id = $this->Master_Model->insert_data($data);
    
                    if ($inserted_id) {
                        //create_log('Has been created a state : '.$data['state_title']);  
                    
                        success($this->lang->line('insert_success'));
                        redirect('administrator/master/index');
                    } else {
                      
                        $this->data = $_POST;
                    }
                }
            }
    
            $this->load->view('administrator/master/add');
        }
        public function delete($id) {
            if($id){
            $this->load->model('Master_Model');
    
            $inserted_id = $this->Master_Model->delete_data($id);
          
          
            if ($inserted_id) {
                create_log('Has been Delete a state ');  
            
                success($this->lang->line('delete_success'));               
            } 
            redirect('administrator/master/index');
            }
           $this->data['add'] = TRUE;
        }
   
    
    /*****************Function edit**********************************
  
    * ********************************************************** */
    public function edit($id = null) {   
      
         
        if ($_POST) {
           
          
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
            $data = array(
                'id' => $id,
                'title' => $this->input->post('state_title'),
                'description' => $this->input->post('state_description'),
               // 'status' => $status,
                'status' => 1,
                'modified_at'=>date('Y-m-d H:i:s'),
                'modified_by'=>logged_in_user_id(),
            );
            $this->load->model('Master_Model');
    
            $updated = $this->Master_Model->update_data($data);
             
                if ($updated) {
                    
                    // create_log('Has been updated a school : '.$data['school_name']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/master/index');    
                    
                } else {
                    
                    error($this->lang->line('update_failed'));
                    redirect('administrator/master/edit/' . $id);
                    
                }
            
        } 
        else {
            if ($id) {
                $this->data['state'] = $this->master->get_single('m_state', array('id' => $id));

                if (!$this->data['state']) {
                     redirect('administrator/master/index');
                }
            }
       }

       $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('master/index', $this->data);
    }
    public function get_board_list_by_state_id($id) {
        $this->load->model('Master_Model');
        $this->data['list_boards']  = $this->Master_Model->get_board_list_by_state_id($id);
        echo json_encode($this->data['list_boards']);
    }
    public function get_course_list_by_board_id($id) {

        // echo $id; die;
        $this->load->model('Master_Model');
        $this->data['list_grade']  = $this->Master_Model->get_course_list_by_board_id($id);
        echo json_encode($this->data['list_grade']);
    }
    public function get_grade_list_by_course_id($id) {
        $this->load->model('Master_Model');
        $this->data['list_grade']  = $this->Master_Model->get_grade_list_by_course_id($id);
        echo json_encode($this->data['list_grade']);
    }
    public function get_sections_by_grade_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_section'] = $this->Master_Model->get_sections_by_grade_id($id);
        echo json_encode($this->data['list_section']);
    }
    public function get_subject_by_section_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_subject'] = $this->Master_Model->get_subject_by_section_id($id);
        echo json_encode($this->data['list_subject']);
    }  
    public function get_section_by_subject_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_subject'] = $this->Master_Model->get_section_by_subject_id($id);
        echo json_encode($this->data['list_subject']);
    } 
    public function get_volume_by_subject_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_volume'] = $this->Master_Model->get_volume_by_subject_id($id);
        echo json_encode($this->data['list_volume']);
    } 
    public function get_unit_by_volume_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_unit'] = $this->Master_Model->get_unit_by_volume_id($id);
        echo json_encode($this->data['list_unit']);
    }
    public function get_lesson_by_unit_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_lesson'] = $this->Master_Model->get_lesson_by_unit_id($id);
        echo json_encode($this->data['list_lesson']);
    }
    public function get_cakra_by_lesson_id($id)
    {
        $this->load->model('Master_Model');
        $this->data['list_chakra'] = $this->Master_Model->get_cakra_by_lesson_id($id);
        echo json_encode($this->data['list_chakra']);
    }
    
    
    
    
    
       
    
}
