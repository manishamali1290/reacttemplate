<?php

use Razorpay\Api\Request;

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class Syn_Course extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        // die('lll');
        parent::__construct();        
        $this->load->model('School_Model', 'school', true);
        $this->load->model('Syn_course_Model', 'syn_course', true);
        if (!has_permission(VIEW, 'master', 'course') || !has_permission(EDIT, 'master', 'course') ) {
            error($this->lang->line('permission_denied'));
            redirect('dashboard/index');
        }              
        $this->layout->title($this->lang->line('course') .' | '.  $this->session->userdata('role_id').' | ' . SMS);
        $this->data['fields'] = $this->school->get_table_fields('languages'); 
        $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
        $this->data['subscriptions'] = $this->school->get_subscription_list(); 
        $this->data['schools'] = $this->school->get_school_list();
        $this->data['states']= $this->school->get_satate_list(); 
        
       //$this->data['add'] = TRUE;
        // $this->data['fields'] = $this->school->get_table_fields('languages'); 
        // $this->data['themes'] = $this->school->get_list('themes', array(), '','', '', 'id', 'ASC');
        // $this->data['subscriptions'] = $this->school->get_subscription_list(); 
        // $this->data['schools'] = $this->school->get_school_list();
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function index()
    {
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        //$this->data['courses'] = $this->syn_course->get_course_list();
        // print_r(  $this->data['courses']);
        // die();
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('course') . ' | ' . SMS);
        $this->layout->view('administrator/syn_course/index', $this->data);
    }
    public function index_list()
    {
       
        // $role_id=$this->session->userdata('role_id');
        // $school_id=$this->session->userdata('school_id');        
        // $this->load->model('Syn_Course_Model', 'course', true);
        // if($school_id)
        // $this->data['courses_list'] = $this->syn_course->get_course_modal_by_shhool($school_id);
        //  print_r($this->data['courses_list']);
        // die();
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('course') .' | ' . SMS);
        $this->layout->view('administrator/syn_course/index_list', $this->data);
    }



    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface                 
     *                    and store "Academic School" into database 
     * @param           : null
     * @return          : null 
     * ********************************************************** */

    private function _prepare_course_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');

        $this->form_validation->set_rules('course_title', 'Title', 'trim|required');
    }

    public function add()
    {
        if($this->session->userdata('role_id') != SUPER_ADMIN){ 
            error($this->lang->line('permission_denied'));
             redirect('dashboard/index');
        } 
        
        if ($_POST) {
            $school_id =  $this->input->post('school_id'); 
            // print_r($school_id);
            // die();
            if ($school_id) {
                $data_to_insert = array(
                    'school_id' => $school_id,
                   
                );
                $school_data = $this->school->get_single('schools', array('id' => $school_id));
                $course_ids = $school_data->course_id; 
                $grade_id_array = explode(',', $course_ids);  
                // $data['filter_school']    =  $school_data;   
                // $data['filter_school']['grade_id_array']    =  $school_data;         
                 $m_course_query = $this->syn_course->get_chakra_by_course($grade_id_array);
                // echo "<pre>";
                // print_r($m_course_query);
                // die();
                
                foreach ($m_course_query as $obj) {
                    $data_to_insert['course_name'] = $obj->title; 
                    // $data_to_insert['state_id'] = $obj->state_id;                        
                    // $data_to_insert['board_id'] = $obj->board_id;                 
                    $data_to_insert['course_id'] = $obj->course_id;                    
                    $data_to_insert['grade_id'] = $obj->grade_id;
                    $data_to_insert['section_id'] = $obj->section_id;                        
                    $data_to_insert['subject_id'] = $obj->subject_id;                   
                    $data_to_insert['volume_id'] = $obj->volume_id;
                    $data_to_insert['unit_id'] = $obj->unit_id;                        
                    $data_to_insert['lessons_id'] = $obj->lessons_id;                 
                    $data_to_insert['chakra_id'] = $obj->id;  
                    $data_to_insert['status'] = 1;
                    $data_to_insert['deleted_by_admin'] = 1;
                    $data_to_insert['created_at'] = date('Y-m-d H:i:s');
                    $data_to_insert['created_by'] = logged_in_user_id();
                //     echo "<pre>";
                // print_r($data_to_insert);
                // die();

                    $check_data = $this->syn_course->get_single('m_course_relation', array('chakra_id' => $data_to_insert['chakra_id'], 'school_id' =>  $school_id,));
                    if(!$check_data){
                    $this->db->insert('m_course_relation', $data_to_insert);
                    }
                    
                }
                success($this->lang->line('insert_success'));
                redirect('administrator/syn_course/index');     
 
               
            }            
            
           
        else {

                error('Please fill all required fields!');
                redirect('administrator/syn_course/add');
            }
        }
        
    }
  
  
    public function edit($id = null)
    {

        //check_permission(EDIT);

        if ($_POST) {
           
           
              
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
                $data = array(
                    'id'=>$id,                    
                    'active_time' => $this->input->post('active_time'),
                    'inactive_time' => $this->input->post('inactive_time'),
                    'status'=>$status,
                );
                $data['modified_at'] = date('Y-m-d H:i:s');
                $data['modified_by'] = logged_in_user_id();
                // print_r($data);
                // die();
                $updated = $this->syn_course->update_course_by_school($data);
                if ($updated) {

                            create_log('Has been updated a course : ');
                            success($this->lang->line('update_success'));
                            redirect('administrator/syn_course/index_list');    

                        } 
                        else {
                //             print_r($data);
                //             print_r($id);
                // die();

                            error($this->lang->line('update_failed'));
                            redirect('administrator/syn_course/edit/' . $id);

                        }
                     
                } 
                else {
                    if ($id) {                        
                        $this->load->model('Syn_Course_Model');
                        $this->data['courses_one'] = $this->Syn_Course_Model->get_single('m_course_relation', array('id' => $id));
                   
                      // $this->data['course_file'] = $this->Syn_Course_Model->get_single_course_file($id);
                        // print_r($this->data['courses_one'] );
                        // die();

                        if (!$this->data['courses_one']) {
                             redirect('administrator/syn_course/index_list');
                        }
            }
        }
        

        $this->data['edit'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('syn_course/index_list', $this->data);
    }
    public function edit_list($id = null)
    {
        // print_r("hhhh");
        //  die();

        //check_permission(EDIT);

        if ($_POST) {
           
              
            $status = $this->input->post('status');
            $status = ($status === null) ? '0' : $status;
                $data = array(
                    'id'=>$id,
                    'title' => $this->input->post('course_title'),
                    'description' => $this->input->post('course_description'),
                    'state_id' => $this->input->post('state_id'),
                    'board_id' => $this->input->post('board_id'),
                    'grade_id' => $this->input->post('grade_id'),
                    'section_id' => $this->input->post('section_id'),
                    'subject_id' => $this->input->post('subject_id'),
                    'volume_id' => $this->input->post('volume_id'),
                    'unit_id' => $this->input->post('unit_id'),
                    'lessons_id' => $this->input->post('lessons_id'),
                    'chakra_id' => $this->input->post('chakra_id'),
                    'active_time' => $this->input->post('active_time'),
                    'inactive_time' => $this->input->post('inactive_time'),
                    'status'=>$status,
                );
                $data['modified_at'] = date('Y-m-d H:i:s');
                $data['modified_by'] = logged_in_user_id();
                $updated = $this->syn_course->update_data($data);
                if ($updated) {

                            create_log('Has been updated a course : '.$data['course_title']);
                            success($this->lang->line('update_success'));
                            redirect('administrator/syn_course/index');    

                        } 
                        else {
                //             print_r($data);
                //             print_r($id);
                // die();

                            error($this->lang->line('update_failed'));
                            redirect('administrator/syn_course/edit/' . $id);

                        }
                     
                } 
                else {
                    if ($id) {                        
                        $this->load->model('Syn_Course_Model');
                       // $this->data['courses_one'] = $this->syn_course->get_course_by_id($id);
                        $this->data['courses_one'] = $this->Syn_Course_Model->get_single('m_course_relation', array('id' => $id));
                      // $this->data['course_file'] = $this->Syn_Course_Model->get_single_course_file($id);
                        // print_r("kk" );
                        // print_r($this->data['courses_one'] );
                        // die();

                        if (!$this->data['courses_one']) {
                             redirect('administrator/syn_course/index');
                        }
            }
        }
        

        $this->data['edit_list'] = TRUE;       
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('syn_course/index', $this->data);
    }




    /*****************Function _get_posted_school_data**********************************
     * @type            : Function
     * @function name   : _get_posted_school_data
     * @description     : Prepare "Academic School" user input data to save into database                  
     *                       
     * @param           : null
     * @return          : $data array(); value 
     * ********************************************************** */
    private function _get_posted_school_data()
    {


        $data = elements($_POST);

        if ($this->input->post('id')) {
            $data['status'] = $this->input->post('status');
            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();
        } else {

            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }



        return $data;
    }
    


    public function get_course_modal($school_id){
        if ($school_id) {            
        //     $this->load->model('Syn_Course_Model');
        //        // $this->data['S_course'] = $this->syn_course->get_single('m_course', array('id' => $course_id));
        //        // echo $this->load->view('course/get-single-course', $this->data);
        
        //    // $course_id = $this->input->post('course_id');       
        $this->data['S_chakra'] = $this->syn_course->get_course_modal($school_id);
        //     $this->data['S_course_files'] = $this->syn_course->get_single_course_file($course_id);
           echo $this->load->view('syn_course/get-single-course', $this->data);
        }
            
         }
         public function get_course_update($course_id){
            if ($course_id) { 
                $current_status = $this->db->get_where('m_course_relation', array('id' => $course_id))->row()->deleted_by_admin;
                $new_status = ($current_status == 0) ? 1 : 0;
                $this->db->where('id', $course_id);
                $this->db->update('m_course_relation', array('deleted_by_admin' => $new_status));
                $response = array(
                    'success' => true,
                    'status'  => $new_status,
                    'message' => 'Status updated successfully'
                );
                echo json_encode($response);
            }
                
             }
             public function get_single_course($course_id){
                if ($course_id) {
                    
                $this->load->model('Syn_Course_Model');
                   // $this->data['S_course'] = $this->syn_course->get_single('m_course', array('id' => $course_id));
                   // echo $this->load->view('course/get-single-course', $this->data);
            
               // $course_id = $this->input->post('course_id');       
                $this->data['S_course'] = $this->syn_course->get_single_course($course_id);
                $this->data['S_course_files'] = $this->syn_course->get_single_course_file($course_id);
               echo $this->load->view('course/get-single-course', $this->data);
            }
                
             }
}
