<?php

defined('BASEPATH') or exit('No direct script access allowed');

/* * *****************School.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : School
 * @description     : Manage academic school.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

class School extends MY_Controller
{

    public $data = array();


    function __construct()
    {
        parent::__construct();
        $this->load->model('School_Model', 'school', true);
        if ($this->session->userdata('role_id') != SUPER_ADMIN) {
            error($this->lang->line('permission_denied'));
            redirect('dashboard/index');
        }

        //$this->data['add'] = TRUE;
        $this->data['fields'] = $this->school->get_table_fields('languages');
        $this->data['themes'] = $this->school->get_list('themes', array(), '', '', '', 'id', 'ASC');
        $this->data['subscriptions'] = $this->school->get_subscription_list();
        $this->data['schools'] = $this->school->get_school_list();
        $this->data['states'] = $this->school->get_satate_list();
    }


    /*****************Function index**********************************
     * @type            : Function
     * @function name   : index
     * @description     : Load "Academic School List" user interface                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function index()
    {

        check_permission(VIEW);
        $this->data['list'] = TRUE;
        $this->layout->title($this->lang->line('manage_school') . ' | ' . SMS);
        $this->layout->view('school/index', $this->data);
    }



    /*****************Function add**********************************
     * @type            : Function
     * @function name   : add
     * @description     : Load "Add new Academic School" user interface                 
     *                    and store "Academic School" into database 
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function add()
    {

        check_permission(ADD);

       

        if ($_POST) {
            $this->_prepare_school_validation();
            if ($this->form_validation->run() === TRUE) {
                $data = $this->_get_posted_school_data();

                $insert_id = $this->school->insert('schools', $data);
                // echo "<pre>";
                // print_r($insert_id);
                // die();
                if ($insert_id) {

                    $inserted_row = $this->db->get_where('schools', ['id' => $insert_id])->row_array();

                    if ($inserted_row) {
                        // Get the necessary data from the inserted school row
                        $school_id = $inserted_row['id']; // Assuming 'id' is the primary key of the schools table
                        $course_ids = explode(',', $inserted_row['course_id']);

                        // echo "<pre>";
                        // print_r($course_ids);
                        // die();
                        $classes_data = [];
                        foreach ($course_ids as $course_id) {

                            if ($course_id) {
                                $grade_row =  $this->db->get_where('m_grade', ['course_id' => $course_id])->row_array();
                            }
                            // echo "<pre>";
                            // print_r($grade_row);
                            // die();
                            if ($grade_row) {
                                $class_row = [
                                    'school_id' => $school_id,
                                    'teacher_id' => 0,
                                    'name' => $grade_row['title'],
                                    'numeric_name' => 1,
                                    'course_id' => $grade_row['course_id'],
                                    'grade_id' => $grade_row['id'],
                                    'note' => '',
                                    'status' => 1,
                                    'created_at' => date('Y-m-d H:i:s'),
                                    'created_by' => logged_in_user_id(),
                                ];
                                // echo "lll<pre>";
                                // print_r($class_row);
                                // die();

                                $class_inserted_id =  $this->school->insert('classes', $class_row);

                                if ($class_inserted_id) {

                                    $class_inserted_id_row =  $this->db->get_where('classes', ['id' => $class_inserted_id])->row_array();

                                    if ($class_inserted_id_row) {

                                        $this->db->select('classes.*, m_section.title as m_section_title, m_section.id as m_section_id');
                                        $this->db->from('classes');
                                        $this->db->join('m_section', 'classes.grade_id = m_section.grade_id');
                                        $this->db->where('classes.id', $class_inserted_id_row['id']); // Replace 

                                        $query = $this->db->get();

                                        $mSection_and_section_rows = $query->result();

                                        // 
                                        // echo "<pre>";
                                        // print_r($mSection_and_section_rows);


                                        // Fetch all rows based on the condition
                                        // $section_rows = $this->db->get_where('m_section', ['id' => $grade_id])->result_array();

                                        foreach ($mSection_and_section_rows as $s_row) {

                                          

                                            $section_data = array(
                                                'school_id' => $school_id,
                                                'class_id' => $class_inserted_id_row['id'],
                                                'course_id' => $class_inserted_id_row['course_id'],
                                                'teacher_id' => 0,
                                                'm_section_id' => $s_row->m_section_id,
                                                'name' => $s_row->m_section_title,
                                                'note' => '',
                                                'status' => 1,
                                                'created_at' => date('Y-m-d H:i:s'),
                                                'created_by' =>  logged_in_user_id(),

                                                // 'modified_by' => $s_row['modified_by']
                                            );
                                            // echo "<pre>";
                                            // print_r($section_data);
                                            // die();

                                            $class_inserted_id =  $this->school->insert('sections', $section_data);
                                            

                                            if ($class_inserted_id) {
                                                $class_inserted_data= $this->school->get_single('sections', array('id' => $class_inserted_id));
                                            //     echo "<pre>";
                                            //     print_r($class_inserted_data);
                                            // die();
                                                $get_subject_list=$this->school->get_subject_list($class_inserted_data);
                                               
                                                if($get_subject_list){
                                                    foreach ($get_subject_list as $obj) {            
                                                        $sub_data = array(
                                                            'school_id' => $school_id,
                                                            'class_id' => $class_inserted_id_row['id'],
                                                            'course_id' =>  $obj->course_id,
                                                            'teacher_id' =>0,
                                                            'm_section_id' => $obj->section_id,
                                                            'm_subjects_id' => $obj->id,
                                                            'name' => $obj->title,
                                                            'note' => '',
                                                            'status' => 1,
                                                            'created_at' => date('Y-m-d H:i:s'),
                                                            'created_by' => logged_in_user_id()
                                                        );
                                                    //     echo "<pre>";
                                                    //     // print_r($get_subject_list);
                                                    //     // print_r($class_inserted_data);
                                                    //     print_r($sub_data);
                                                    // die();

                                                        $class_sub_id =  $this->school->insert('subjects', $sub_data);
                                                        }

                                                }
                                                // $class_inserted_data->m_section_id;
                                                // $class_inserted_data->course_id;

                                            //     echo "<pre>";
                                            //     print_r($class_inserted_id);
                                            //     print_r($class_inserted_data);
                                            // die();
                                            }
                                        }

                                       

                                        $classes_data[] = $class_inserted_id_row;
                                    }
                                }
                                // Add the row to the classes data array
                            }
                        }
                        // die;

                        if (!empty($classes_data)) {

                            // $this->db->insert_batch('classes', $classes_data);

                            create_log('Has been created a school : ' . $data['school_name']);

                            success($this->lang->line('insert_success'));
                            redirect('administrator/school/index');
                            // echo "<pre>";
                            // print_r($last_inserted_ids);
                            // die();

                            // if ($this->db->affected_rows() > 0) {


                            // } else {
                            //     error($this->lang->line('insert_failed'));
                            //     redirect('administrator/school/add');
                            // }
                        } else {
                            error('classes data not found');
                            redirect('administrator/school/add',$this->data);
                        }
                    }
                } else {
                    error($this->lang->line('insert_failed'));
                    redirect('administrator/school/add',$this->data);
                }
            } else {
                error($this->lang->line('insert_failed'));
                $this->data['post'] = $_POST;
            }
        }

        $this->data['add'] = TRUE;
        $this->layout->title($this->lang->line('add') . ' | ' . SMS);
        $this->layout->view('school/index', $this->data);
    }


    /*****************Function edit**********************************
     * @type            : Function
     * @function name   : edit
     * @description     : Load Update "Academic School" user interface                 
     *                    with populated "Academic School" value 
     *                    and update "Academic School" database    
     * @param           : $id integer value
     * @return          : null 
     * ********************************************************** */
    public function edit($id = null)
    {

        check_permission(EDIT);

        if ($_POST) {
            $this->_prepare_school_validation();
            if ($this->form_validation->run() === TRUE) {
                $data = $this->_get_posted_school_data();


                $updated = $this->school->update('schools', $data, array('id' => $this->input->post('id')));

                if ($updated) {
                    $inserted_row = $this->db->get_where('schools', ['id' => $this->input->post('id')])->row_array();
                    if ($inserted_row) {
                        // echo "<pre>";
                        // print_r($inserted_row);
                        // die();
                        
                            $dactiveClass = $this->school->dactive_class( $inserted_row['id']);
                            // echo "<pre>";
                            //         print_r($dactiveClass);
                            //         die();
                        
                

                        
                            $school_id = $inserted_row['id']; // Assuming 'id' is the primary key of the schools table
                            $course_ids = explode(',', $inserted_row['course_id']);
    
                            // echo "<pre>";
                            // print_r($course_ids);
                            // die();
                            $classes_data = [];
                            foreach ($course_ids as $course_id) {
    
                                if ($course_id) {
                                    $grade_row =  $this->db->get_where('m_grade', ['course_id' => $course_id])->row_array();
                                }
                                // echo "<pre>";
                                // print_r($grade_row);
                                // die();
                                if ($grade_row) {
                                    $class_row = [
                                        'school_id' => $school_id,
                                        'teacher_id' => 0,
                                        'name' => $grade_row['title'],
                                        'numeric_name' => 1,
                                        'course_id' => $grade_row['course_id'],
                                        'grade_id' => $grade_row['id'],
                                        'note' => '',
                                        'status' => 1,
                                        'created_at' => date('Y-m-d H:i:s'),
                                        'created_by' => logged_in_user_id(),
                                    ];
                                    // echo "lll<pre>";
                                    // print_r($class_row);
                                    // die();
                                    $checkData=$this->school->get_single('classes', array('grade_id' =>  $grade_row['id'], 'school_id' => $school_id, ));
                                    // echo "lll<pre>";
                                    // print_r($checkData->id);
                                    // die();
                                    if($checkData){
                                        $class_inserted_id = $this->school->update('classes', $class_row, array('id' => $checkData->id));

                                    }
                                    else{$class_inserted_id =  $this->school->insert('classes', $class_row);}
    
                                    if ($class_inserted_id) {
                                    //     echo "class<pre>";
                                    // print_r($class_inserted_id);
                                    // die();
    
                                    $class_inserted_id_row = $this->db->get_where('classes', array('grade_id' => $grade_row['id'], 'school_id' => $school_id))->row_array();
                                    // echo "class<pre>";
                                    // print_r($class_inserted_id_row);
                                    // die();
                                        if ($class_inserted_id_row) {
    
                                            $this->db->select('classes.*, m_section.title as m_section_title, m_section.id as m_section_id');
                                            $this->db->from('classes');
                                            $this->db->join('m_section', 'classes.grade_id = m_section.grade_id');
                                            $this->db->where('classes.id', $class_inserted_id_row['id']); // Replace 
    
                                            $query = $this->db->get();
    
                                            $mSection_and_section_rows = $query->result();
    
                                            // 
                                            // echo "<pre>";
                                            // print_r($mSection_and_section_rows);
                                            // die();
    
    
                                            // Fetch all rows based on the condition
                                            // $section_rows = $this->db->get_where('m_section', ['id' => $grade_id])->result_array();
    
                                            foreach ($mSection_and_section_rows as $s_row) {
    
                                              
    
                                                $section_data = array(
                                                    'school_id' => $school_id,
                                                    'class_id' => $class_inserted_id_row['id'],
                                                    'course_id' => $class_inserted_id_row['course_id'],
                                                    'teacher_id' => 0,
                                                    'm_section_id' => $s_row->m_section_id,
                                                    'name' => $s_row->m_section_title,
                                                    'note' => '',
                                                    'status' => 1,
                                                    'created_at' => date('Y-m-d H:i:s'),
                                                    'created_by' =>  logged_in_user_id(),
    
                                                    // 'modified_by' => $s_row['modified_by']
                                                );
                                                // echo "<pre>";
                                                // print_r($section_data);
                                                // die();
                                                $checkDataSec=$this->school->get_single('sections', array('class_id' => $class_inserted_id_row['id'], 'school_id' => $school_id, 'm_section_id' => $s_row->m_section_id ));
                                  
                                                if($checkDataSec){
                                                    $section_inserted = $this->school->update('sections', $section_data, array('id' => $checkDataSec->id));
            
                                                }
                                                else{$section_inserted =  $this->school->insert('sections', $section_data);}
                                                // echo "<pre>";
                                                // print_r($checkDataSec);
                                                // print_r($section_inserted);
                                                // die();
                
    
                                               // $class_inserted_id =  $this->school->insert('sections', $section_data);
                                                
    
                                                if ($section_inserted) {
                                                    $class_inserted_data= $this->school->get_single('sections', array('id' => $checkDataSec->id));
                                                //     echo "lll<pre>";
                                                //     print_r($class_inserted_data);
                                                // die();
                                                    $get_subject_list=$this->school->get_subject_list($class_inserted_data);
                                                //     echo "lll<pre>";
                                                //     print_r($get_subject_list);
                                                // die();
                                                    if($get_subject_list){
                                                        foreach ($get_subject_list as $obj) {            
                                                            $sub_data = array(
                                                                'school_id' => $school_id,
                                                                'class_id' => $class_inserted_id_row['id'],
                                                                'course_id' =>  $obj->course_id,
                                                                'teacher_id' =>0,
                                                                'm_section_id' => $obj->section_id,
                                                                'm_subjects_id' => $obj->id,
                                                                'name' => $obj->title,
                                                                'note' => '',
                                                                'status' => 1,
                                                                'created_at' => date('Y-m-d H:i:s'),
                                                                'created_by' => logged_in_user_id()
                                                            );
                                                        //     echo "<pre>";
                                                        //     // print_r($get_subject_list);
                                                        //     // print_r($class_inserted_data);
                                                        //     print_r($sub_data);
                                                        // die();
                                                        $checkDataSub=$this->school->get_single('subjects', array('class_id' => $class_inserted_id_row['id'], 'school_id' => $school_id,'m_subjects_id' => $obj->id ));
                                  
                                                        if($checkDataSub){
                                                            $section_inserted = $this->school->update('subjects', $sub_data, array('id' => $checkDataSub->id));
                    
                                                        }
                                                        else{$section_inserted =  $this->school->insert('subjects', $sub_data);}
    
                                                            // $class_sub_id =  $this->school->insert('subjects', $sub_data);
                                                            }
                                                            // echo "<pre>";
                                                            //     print_r($checkDataSub);echo "kkk\n";
                                                            //     print_r($sub_data);echo ";;;\n";
                                                            //     print_r($section_inserted);echo "hhh\n";
                                                            // die();
    
                                                    }
                                                    // $class_inserted_data->m_section_id;
                                                    // $class_inserted_data->course_id;
    
                                                //     echo "<pre>";
                                                //     print_r($class_inserted_id);
                                                //     print_r($class_inserted_data);
                                                // die();
                                                }
                                            }
    
                                           
    
                                            $classes_data[] = $class_inserted_id_row;
                                        }
                                    }
                                    // Add the row to the classes data array
                                }
                            }
                            // die;
    
                            if (!empty($classes_data)) {
    
                                // $this->db->insert_batch('classes', $classes_data);
    
                                create_log('Has been created a school : ' . $data['school_name']);
    
                                success($this->lang->line('insert_success'));
                                redirect('administrator/school/index');
                                // echo "<pre>";
                                // print_r($last_inserted_ids);
                                // die();
    
                                // if ($this->db->affected_rows() > 0) {
    
    
                                // } else {
                                //     error($this->lang->line('insert_failed'));
                                //     redirect('administrator/school/add');
                                // }
                            } else {
                                error('classes data not found');
                                redirect('administrator/school/add',$this->data);
                            }


                        // $school_id = $inserted_row['id'];

                        // $classesGradeData =   $this->db->get_where('classes', ['school_id' => $school_id])->result_array();

                        // if (!empty($classesGradeData)) {

                        //     $classGradeLength = explode(',', $inserted_row['grade_id']);
                        //     // $schoolGradeLength = count($classesGradeData);

                        //     // if (count($classGradeLength) === $schoolGradeLength) {
                        //     foreach ($classesGradeData as $key => $classRow) {
                        //         if (in_array($classRow['grade_id'], $classGradeLength)) {

                        //             $data = [
                        //                 'modified_by' => 1,
                        //                 'status' => 1,
                        //             ];

                        //             $updated = $this->school->update('classes', $data, array('grade_id' => $classRow['grade_id'], 'school_id' => $classRow['school_id']));
                        //         } else {

                        //             $data = [
                        //                 'modified_by' => 1,
                        //                 'status' => 0,
                        //             ];

                        //             $updated = $this->school->update('classes', $data, array('grade_id' => $classRow['grade_id'], 'school_id' => $classRow['school_id']));
                        //         }
                        //     }
                        // }



                        // $grade_ids = explode(',', $inserted_row['grade_id']);

                        // $classes_data = [];
                        // foreach ($grade_ids as $grade_id) {

                        //     if ($grade_id) {
                        //         $grade_row =  $this->db->get_where('m_grade', ['id' => $grade_id])->row_array();
                        //     }

                        //     $class_row = [
                        //         'grade_id' => $grade_row['id'],
                        //         'status' => 1,
                        //         'modified_at' => $inserted_row['created_at'],
                        //         'modified_by' => $inserted_row['modified_by'],
                        //     ];

                        //     // Add the row to the classes data array
                        //     $classes_data[] = $class_row;
                        // }
                    } else {
                    }


                    create_log('Has been updated a school : ' . $data['school_name']);
                    success($this->lang->line('update_success'));
                    redirect('administrator/school/index');
                } else {

                    error($this->lang->line('update_failed'));
                    redirect('administrator/school/edit/' . $this->input->post('id'));
                }
            } else {
                error($this->lang->line('update_failed'));
                $this->data['school'] = $this->school->get_single('schools', array('id' => $this->input->post('id')));
            }
        } else {
            if ($id) {
                $this->data['school'] = $this->school->get_single('schools', array('id' => $id));

                if (!$this->data['school']) {
                    redirect('administrator/school/index');
                }
            }
        }

        $this->data['edit'] = TRUE;
        $this->layout->title($this->lang->line('edit') . ' | ' . SMS);
        $this->layout->view('school/index', $this->data);
    }


    /*****************Function get_single_school**********************************
     * @type            : Function
     * @function name   : get_single_school
     * @description     : "Load single school information" from database                  
     *                    to the user interface   
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    public function get_single_school()
    {

        $school_id = $this->input->post('school_id');
        $this->data['school'] = $this->school->get_single_school($school_id);
        echo $this->load->view('school/get-single-school', $this->data);
    }


    /*****************Function _prepare_school_validation**********************************
     * @type            : Function
     * @function name   : _prepare_school_validation
     * @description     : Process "Academic School" user input data validation                 
     *                       
     * @param           : null
     * @return          : null 
     * ********************************************************** */
    private function _prepare_school_validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error-message" style="color: red;">', '</div>');

        $this->form_validation->set_rules('school_name', $this->lang->line('school_name'), 'trim|required|callback_school_name');
        $this->form_validation->set_rules('school_url', $this->lang->line('school_url'), 'trim|required');
        $this->form_validation->set_rules('address', $this->lang->line('address'), 'trim|required');
        $this->form_validation->set_rules('phone', $this->lang->line('phone'), 'trim|required|min_length[6]|max_length[20]');
        $this->form_validation->set_rules('email', $this->lang->line('email'), 'trim|required|valid_email');
        $this->form_validation->set_rules('currency', $this->lang->line('currency'), 'trim');
        // $this->form_validation->set_rules('currency_symbol', $this->lang->line('currency_symbol'), 'trim|required');
        $this->form_validation->set_rules('language', $this->lang->line('language'), 'trim|required');
        $this->form_validation->set_rules('theme_name', $this->lang->line('theme'), 'trim|required');
        $this->form_validation->set_rules('footer', $this->lang->line('footer'), 'trim');
        $this->form_validation->set_rules('logo', $this->lang->line('admin_logo'), 'trim|callback_logo');
        $this->form_validation->set_rules('frontend_logo', $this->lang->line('frontend_logo'), 'trim|callback_frontend_logo');
    }


    /*****************Function session_school**********************************
     * @type            : Function
     * @function name   : session_school
     * @description     : Unique check for "academic school" data/value                  
     *                       
     * @param           : null
     * @return          : boolean true/false 
     * ********************************************************** */
    public function school_name()
    {
        if ($this->input->post('id') == '') {
            $school = $this->school->duplicate_check($this->input->post('school_name'));
            if ($school) {
                $this->form_validation->set_message('school_name', $this->lang->line('already_exist'));
                return FALSE;
            } else {
                return TRUE;
            }
        } else if ($this->input->post('id') != '') {
            $school = $this->school->duplicate_check($this->input->post('school_name'), $this->input->post('id'));
            if ($school) {
                $this->form_validation->set_message('school_name', $this->lang->line('already_exist'));
                return FALSE;
            } else {
                return TRUE;
            }
        } else {
            return TRUE;
        }
    }


    /*****************Function logo**********************************
     * @type            : Function
     * @function name   : logo
     * @description     : validate school admin logo                  
     *                       
     * @param           : null
     * @return          : boolean true/false 
     * ********************************************************** */
    public function logo()
    {
        if ($_FILES['logo']['name']) {

            list($width, $height) = getimagesize($_FILES['logo']['tmp_name']);
            if ((!empty($width)) && $width > 100 || $height > 110) {
                $this->form_validation->set_message('logo', $this->lang->line('please_check_image_dimension'));
                return FALSE;
            }

            $name = $_FILES['logo']['name'];
            $ext = pathinfo($name, PATHINFO_EXTENSION);
            if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png' || $ext == 'gif') {
                return TRUE;
            } else {
                $this->form_validation->set_message('logo', $this->lang->line('select_valid_file_format'));
                return FALSE;
            }
        }
    }

    /*****************Function frontend_logo**********************************
     * @type            : Function
     * @function name   : frontend_logo
     * @description     : validate school  frontend_logo                  
     *                       
     * @param           : null
     * @return          : boolean true/false 
     * ********************************************************** */
    public function frontend_logo()
    {
        if ($_FILES['frontend_logo']['name']) {


            list($width, $height) = getimagesize($_FILES['frontend_logo']['tmp_name']);
            if ((!empty($width)) && $width > 150 || $height > 90) {
                $this->form_validation->set_message('frontend_logo', $this->lang->line('please_check_image_dimension'));
                return FALSE;
            }

            $name = $_FILES['frontend_logo']['name'];
            $ext = pathinfo($name, PATHINFO_EXTENSION);
            if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png' || $ext == 'gif') {
                return TRUE;
            } else {
                $this->form_validation->set_message('frontend_logo', $this->lang->line('select_valid_file_format'));
                return FALSE;
            }
        }
    }



    /*****************Function _get_posted_school_data**********************************
     * @type            : Function
     * @function name   : _get_posted_school_data
     * @description     : Prepare "Academic School" user input data to save into database                  
     *                       
     * @param           : null
     * @return          : $data array(); value 
     * ********************************************************** */
    private function _get_posted_school_data()
    {

        $items = array();

        $items[] = 'school_url';
        $items[] = 'school_code';
        $items[] = 'school_name';
        $items[] = 'address';
        $items[] = 'phone';
        $items[] = 'email';
        // $items[] = 'currency';
        // $items[] = 'currency_symbol';
        $items[] = 'school_fax';
        $items[] = 'zoom_api_key';
        $items[] = 'zoom_secret';
        $items[] = 'enable_frontend';
        $items[] = 'final_result_type';
        $items[] = 'registration_date';
        $items[] = 'footer';
        $items[] = 'google_map';
        $items[] = 'theme_name';
        $items[] = 'language';
        $items[] = 'enable_online_admission';
        // $items[] = 'enable_rtl';
        $items[] = 'facebook_url';
        $items[] = 'twitter_url';
        $items[] = 'linkedin_url';
        $items[] = 'youtube_url';
        $items[] = 'instagram_url';
        $items[] = 'pinterest_url';
        $items[] = 'state_id';
        $items[] = 'board_id';

        $data = elements($items, $_POST);

        if ($this->input->post('id')) {
            $data['status'] = $this->input->post('status');
            $data['modified_at'] = date('Y-m-d H:i:s');
            $data['modified_by'] = logged_in_user_id();
            $data['course_id'] = implode(',', $this->input->post('course_id'));
        } else {

            $data['about_text'] = 'Lorem ipsum dolor sit amet, consecte- tur adipisicing elit, We create Premium WordPress themes & plugins for more than three years. ';
            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            $data['course_id'] = implode(',', $this->input->post('course_id'));;
        }

        if ($_FILES['logo']['name']) {
            $data['logo'] = $this->_upload_logo();
        }
        if ($_FILES['frontend_logo']['name']) {
            $data['frontend_logo'] = $this->_upload_frontend_logo();
        }
        // print_r( $data);
        // die();

        return $data;
    }



    /*****************Function _upload_logo**********************************
     * @type            : Function
     * @function name   : _upload_logo
     * @description     : Process to upload institute logo in the server                  
     *                     and return logo name   
     * @param           : null
     * @return          : $logo string value 
     * ********************************************************** */
    private function _upload_logo()
    {

        $prevoius_logo = @$_POST['logo_prev'];
        $logo_name = $_FILES['logo']['name'];
        $logo_type = $_FILES['logo']['type'];
        $logo = '';


        if ($logo_name != "") {
            if (
                $logo_type == 'image/jpeg' || $logo_type == 'image/pjpeg' ||
                $logo_type == 'image/jpg' || $logo_type == 'image/png' ||
                $logo_type == 'image/x-png' || $logo_type == 'image/gif'
            ) {

                $destination = 'assets/uploads/logo/';

                $file_type = explode(".", $logo_name);
                $extension = strtolower($file_type[count($file_type) - 1]);
                $logo_path = time() . '-school-admin-logo.' . $extension;

                copy($_FILES['logo']['tmp_name'], $destination . $logo_path);

                if ($prevoius_logo != "") {
                    // need to unlink previous image
                    if (file_exists($destination . $prevoius_logo)) {
                        @unlink($destination . $prevoius_logo);
                    }
                }

                $logo = $logo_path;
            }
        } else {
            $logo = $prevoius_logo;
        }

        return $logo;
    }

    /*****************Function _upload_frontend_logo**********************************
     * @type            : Function
     * @function name   : _upload_frontend_logo
     * @description     : Process to upload school front end logo in the server                  
     *                     and return logo name   
     * @param           : null
     * @return          : $logo string value 
     * ********************************************************** */
    private function _upload_frontend_logo()
    {

        $prevoius_logo = @$_POST['frontend_logo_prev'];
        $logo_name = $_FILES['frontend_logo']['name'];
        $logo_type = $_FILES['frontend_logo']['type'];
        $logo = '';


        if ($logo_name != "") {
            if (
                $logo_type == 'image/jpeg' || $logo_type == 'image/pjpeg' ||
                $logo_type == 'image/jpg' || $logo_type == 'image/png' ||
                $logo_type == 'image/x-png' || $logo_type == 'image/gif'
            ) {

                $destination = 'assets/uploads/logo/';

                $file_type = explode(".", $logo_name);
                $extension = strtolower($file_type[count($file_type) - 1]);
                $logo_path = time() . '-school-front-logo.' . $extension;

                copy($_FILES['frontend_logo']['tmp_name'], $destination . $logo_path);

                if ($prevoius_logo != "") {
                    // need to unlink previous image
                    if (file_exists($destination . $prevoius_logo)) {
                        @unlink($destination . $prevoius_logo);
                    }
                }

                $logo = $logo_path;
            }
        } else {
            $logo = $prevoius_logo;
        }

        return $logo;
    }


    /* @type            : Function
     * @function name   : update_subscription_status
     * @description     : update_subscription_status               
     *                    
     * @param           : null
     * @return          : null 
     * ********************************************************** */

    public function update_subscription_status()
    {

        $school_id = $this->input->post('school_id');
        $subscription_id     = $this->input->post('subscription_id');

        $exist = $this->school->get_single('schools', array('subscription_id' => $subscription_id));

        if (empty($exist)) {
            echo $this->school->update('schools', array('modified_at' => date('Y-m-d H:i:s'), 'subscription_id' => $subscription_id), array('id' => $school_id));
        } else if ($exist->id == $school_id && $exist->subscription_id == $subscription_id) {
            echo TRUE;
        } else {
            echo FALSE;
        }
    }


    /* @type            : Function
     * @function name   : set_demo_school
     * @description     : set_demo_school for brand demo               
     *                    
     * @param           : null
     * @return          : null 
     * ********************************************************** */

    public function set_demo_school()
    {

        $school_id = $this->input->post('school_id');

        $this->school->update('schools', array('modified_at' => date('Y-m-d H:i:s'), 'is_demo' => 0), array());
        if ($this->school->update('schools', array('modified_at' => date('Y-m-d H:i:s'), 'is_demo' => 1), array('id' => $school_id))) {
            echo TRUE;
        } else {
            echo FALSE;
        }
    }


    /*****************Function delete**********************************
     * @type            : Function
     * @function name   : delete
     * @description     : delete "Academic School" from database                  
     *                       
     * @param           : $id integer value
     * @return          : null 
     * ********************************************************** */
    public function delete($id = null)
    {




        check_permission(DELETE);
        if (!is_numeric($id)) {
            error($this->lang->line('unexpected_error'));
            redirect('administrator/school/index');
        }

        // need to find all child data from database 
        $skips = array(
            'global_setting', 'gmsms_sessions', 'languages', 'modules', 'operations', 'privileges', 'purchase',
            'roles', 'schools', 'system_admin', 'themes',
            'saas_faqs', 'saas_plans', 'saas_settings', 'saas_sliders', 'saas_subscriptions'
        );
        $tables = $this->db->list_tables();

        foreach ($tables as $table) {

            if (in_array($table, $skips)) {
                continue;
            }

            // $child_exist =$this->school->get_list($table, array('school_id'=>$id), '','', '', 'id', 'ASC');
            $child_exist = $this->school->delete($table, array('school_id' => $id));
            /*if(!empty($child_exist)){
                 error($this->lang->line('pls_remove_child_data'));
                 redirect('administrator/school/index');
            }*/
        }


        $school = $this->school->get_single('schools', array('id' => $id));

        if ($this->school->delete('schools', array('id' => $id))) {

            // delete syllabus file
            $destination = 'assets/uploads/logo/';
            if (file_exists($destination . $school->frontend_logo)) {
                @unlink($destination . $school->frontend_logo);
            }
            if (file_exists($destination . $school->logo)) {
                @unlink($destination . $school->logo);
            }

            create_log('Has been deleted a school : ' . $school->school_name);
            success($this->lang->line('delete_success'));
        } else {
            error($this->lang->line('delete_failed'));
        }
        redirect('administrator/school/index');
    }
}