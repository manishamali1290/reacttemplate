<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* * *****************Report.php**********************************
 * @product name    : Global Multi School Management System Express
 * @type            : Class
 * @class name      : Report
 * @description     : Manage all reports of the system.  
 * @author          : Codetroopers Team 	
 * @url             : https://themeforest.net/user/codetroopers      
 * @support         : yousuf361@gmail.com	
 * @copyright       : Codetroopers Team	 	
 * ********************************************************** */

 class Report_all extends My_Controller {

    public function __construct() {
        parent::__construct();
        if($this->session->userdata('role_id') != SUPER_ADMIN){
            $school_id = $this->session->userdata('school_id');
       }
        $this->load->model('Report_all_Model', 'report_model', true);
    }

    public function index() {
        // echo "<pre>";
        // print_r($this->session);die;
        $g_id = $this->session->userdata('profile_id');
    
        if ($g_id) {
            $data['list_student'] = $this->report_model->get_student_g_id($g_id);
        }
    //     echo "<pre>";
    // print_r($data['list_student']);die;
        $selected_student_id = $this->input->post('student_id');
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($this->input->post('student_id')) {
                // die;
                // $this->session->unset_userdata('G_student_id');                
                // $this->session->set_userdata('G_student_id',$this->input->post('student_id')); 

                $student_id = $this->input->post('student_id');
                //  print_r($student_id);die;
                $data_r = $this->report_model->get_student_data($student_id);
                // print_r($data_r);die;
                if (!empty($data_r)) {
                    $class_id = $data_r[0]->class_id;
                    $school_id = $data_r[0]->school_id;
                    $subject_id = $data_r[0]->subject_id;
                    $student_user_id= $this->report_model->get_single('students', array('id' => $student_id));
                    // print_r($student_user_id);die;
    
                    $subjects = $this->report_model->get_subjects_by_class($class_id, $student_user_id->user_id);
    
                    // Calculate the total number of chakras
                    $totalChakras = 0;
                    foreach ($subjects as $subject) {
                        $totalChakras += $subject->chakra_count;
                    }
    
                    $data['subjects'] = $subjects;
                    $data['totalChakras'] = $totalChakras;
                    $data['selected_student_id'] = $selected_student_id;
                } 
            } else {
                $dataFilter['school_id'] = $this->input->post('school_id');
                $dataFilter['class_id'] = $this->input->post('class_id');
            }
    
            if ($this->session->userdata('role_id') == STUDENT) {
                $dataFilter['school_id'] = $this->session->userdata('school_id');
                $dataFilter['class_id'] = $this->session->userdata('class_id');
                $dataFilter['student_id'] = $this->session->userdata('id');
            }
        }
    
        $this->data['list'] = TRUE;
        $data['school_list'] = $this->report_model->get_school();
        $data['course_results'] = $this->report_model->report($dataFilter);
    
        $this->layout->title($this->lang->line('manage_report') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $data);
    }
    
    

    public function get_class($id) {
        $class_list = $this->report_model->get_class($id);
        echo json_encode($class_list);
    }
    

    public function get_students($id) {
        $class_list = $this->report_model->get_students($id);
        echo json_encode($students_list);
    }

    public function chakras($subject_id) {
        // print_r('nfjn');die;
         $school_id = $this->session->userdata('school_id');
         $student_id = $this->session->userdata('G_student_id');
         $student_user_data= $this->report_model->get_single('students', array('id' => $student_id));
         $student_user_id = $student_user_data->user_id;
        $chakras = $this->report_model->get_chakras_list($subject_id, $school_id,$student_user_id);       
    //    echo"<pre>";
    //     print_r($chakras);
    //     die;
        
    
        if (!empty($chakras)) {
            $data['chakras'] = $chakras;
        } else {
            $data['chakras'] = array(); 
        }
    
        $this->layout->title($this->lang->line('chakras_title') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $data);
    }
    public function getChakras($subject_id){
        //  error_reporting(E_ALL);

        //     // Display errors in output
        //     ini_set('display_errors', 1);
         $school_id = $this->session->userdata('school_id');
         $student_id = $this->session->userdata('G_student_id'); 
         $sub_id_data= $this->report_model->get_single('subjects', array('id' => $subject_id));
        $sub_id=$sub_id_data->m_subjects_id;       
        
         $student_user_data= $this->report_model->get_single('students', array('user_id' => $student_id));
         
         $student_user_id = $student_user_data->user_id;
         $chakras = $this->report_model->get_chakras_list($sub_id, $school_id,$student_user_id);       
        //  print_r($chakras)
        
         $data['chakras'] = [];
        if (!empty($chakras)) {
            $data['chakras'] = $chakras;
        }
        // echo "<pre>";
        // print_r($data);
        //     die;
        $this->layout->title($this->lang->line('chakras_title') . ' | ' . SMS);
        $this->load->view('administrator/report_all/ajaxgetchakras.php', $data);
    }
    
    public function chakra_details($chakra_id) {
        $chakra = $this->report_model->get_chakra_details($chakra_id);
    
        if (!empty($chakra)) {
            $this->layout->title($chakra->course_name . ' Details | ' . SMS);
            $this->layout->view('administrator/report_all/chakra_details', ['chakra' => $chakra]);
        } else {
            // Chakra details not found, show an error message or redirect
            // Redirect or show an error message
            redirect(site_url('administrator/report_all'));
        }
    }

    public function student_progress($student_id)
    {
    //     echo "<pre>";
    //     print_r($student_id);die;
    //  $student_userid = $this->get->get_student_g_id($g_id);
        // $this->session->unset_userdata('G_student_id');                
        // $this->session->set_userdata('G_student_id',);
        $g_id = $this->session->userdata('profile_id');

        if ($g_id) {
            $data['list_student'] = $this->report_model->get_student_g_id($g_id);
        }

        // echo "<pre>";
        // print_r( $data['list_student']);die;

        $selected_student_id = $student_id;


        // print_r("kjhkjh");die;

        if ($selected_student_id) {
            $student_id = $student_id;
            // print_r($student_id);die;

            $data_r = $this->report_model->get_student_data($student_id);

            if (!empty($data_r)) {
                // print_r($data_r);die;
                $class_id = $data_r[0]->class_id;
                $school_id = $data_r[0]->school_id;
                $subject_id = $data_r[0]->subject_id;
                $student_user_data = $this->report_model->get_single('students', array('id' => $student_id));
 // echo "<pre>";    print_r($class_id);die;

                $subjects = $this->report_model->get_subjects_by_class($class_id, $student_user_data->user_id);
           // echo "<pre>";    print_r($subjects);die;
                $this->session->unset_userdata('G_student_id');                
                $this->session->set_userdata('G_student_id',$student_user_data->user_id);
                // echo "<pre>";
                // print_r($student_user_data->user_id);
                // exit();
                $this->data['subjects'] = $subjects;
                $data['selected_student_id'] = $selected_student_id;
            }
        } else {
            // $dataFilter['school_id'] = $this->input->post('school_id');
            // $dataFilter['class_id'] = $this->input->post('class_id');
        }
       
     
        if ($this->session->userdata('role_id') == STUDENT) {
            // print_r($this->session);die;
            $dataFilter['school_id'] = $this->session->userdata('school_id');
            $dataFilter['class_id'] = $this->session->userdata('class_id');
            $dataFilter['student_id'] = $this->session->userdata('id');
        }


        $this->data['list'] = TRUE;
        $data['school_list'] = $this->report_model->get_school();
        $data['course_results'] = $this->report_model->report($dataFilter);
        // echo "<pre>";
        // print_r($data['course_results']);
        // die;

        // Load the view with the data
        $this->data['new_progress'] = TRUE;
        $this->layout->title($this->lang->line('manage_report') . ' | ' . SMS);
        $this->layout->view('administrator/report_all/index', $this->data);
    }

    
}