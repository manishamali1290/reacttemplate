<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Chakra_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    
    public function get_satate_list() {

        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();
        
    }    
    
    public function get_chakra_list() {
        $this->db->select('m_state.title AS state_title,  m_grade.title AS grade_title, m_board.title AS board_title, m_section.title AS section_title, m_subject.title AS subject_title, m_volume.title AS volume_title,m_unit.title AS  unit_title, m_lessons.title AS  lessons_title, m_chakra.*');
        $this->db->from('m_chakra');
        $this->db->join('m_state', 'm_chakra.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_chakra.board_id = m_board.id', 'left');
        $this->db->join('m_grade', 'm_chakra.grade_id = m_grade.id', 'left');
        $this->db->join('m_section', 'm_chakra.section_id = m_section.id', 'left');
        $this->db->join('m_subject', 'm_chakra.subject_id = m_subject.id', 'left');
        $this->db->join('m_volume', 'm_chakra.volume_id = m_volume.id', 'left');
        $this->db->join('m_unit', 'm_chakra.unit_id = m_unit.id', 'left');
        $this->db->join('m_lessons', 'm_chakra.lessons_id = m_lessons.id', 'left');
        return $this->db->get()->result();
        
    }
  
    public function insert_data($data){
        $this->db->insert('m_chakra',$data);
        return $this->db->insert_id();
    } 
    public function delete_data($id){
        
        $this->db->where('id', $id);
        $this->db->delete('m_chakra');
        return $this->db->delete();
    }
    public function update_data($data) {
       
        $this->db->where('id', $data['id']);
        $this->db->update('m_chakra', $data);
        return $this->db->affected_rows();
    }
}
