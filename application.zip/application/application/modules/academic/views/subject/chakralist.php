<style>
    .button-link {
        display: inline-block;
        padding: 10px 20px;
        background-color: #800080; /* Green background color */
        color: white; /* White text color */
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 20px;
    }
    </style>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-folder-open"></i><small>
                        <?php echo $this->lang->line('manage_subject'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content quick-link">
                <?php $this->load->view('quick-link'); ?>
            </div>
           
                    <div class="x_panel">
                        <h3 class="head-title">
                    <a href="javascript:history.go(-1);" class="button-link">
                        <strong>&lt; Previous</strong>
                    </a>
                </h3><br><br>
                        <div class="row">
                            <div class="col-sm-12">
                                <h2 class="text-center">Chakra List</h2>
                                <div class="main-container">
                                    <div class="content-section">
                                        <?php
                                        foreach ($list_chakra_by_sub as $obj) { ?>
                                            <a href="<?php echo site_url('academic/subject/viewchakra/' . $obj->chakra_id); ?>">
                                                <div class="rounded-div">
                                                    <div class="itemWrap">
                                                        <div class="topdata">
                                                            <h2 style="font-size: 22px;"><?= $obj->course_name; ?></h2>
                                                        </div>
                                                        <div class="btmData">
                                                            <div class="itemWrap">
                                                                <?php if ($total_com_chakra == $obj->total_students) { ?>
                                                                    <img src="<?= base_url(); ?>/assets/images/ico-1.png" alt="Icon 1">
                                                                <?php } else { ?>
                                                                    <img src="<?= base_url(); ?>/assets/images/redicon.png" alt="Red Icon">
                                                                <?php } ?>
                                                            </div>
                                                            <div class="dataWrap">
                                                                <?php if ($obj->total_students > 0) { ?>
                                                                    <h3 style="color:#08c;"><?= $total_com_chakra; ?>/<?= $obj->total_students; ?> Students</h3>
                                                                    <p>Have completed the task</p>
                                                                <?php } else { ?>
                                                                    <p>In progress.</p>
                                                                <?php } ?>
                                                                <!-- Display total_students here -->
                                                                <!--<p>Total Students: <?= $obj->total_students; ?></p>-->
                                                                <a href></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-subject-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
            </div>
            <div class="modal-body fn_subject_data">
            </div>
        </div>
    </div>
</div>




<style>
    .topdata {
    min-height: 75px;
}
    img.chakra_img {
    height: 72px;
}
.room {
    color: black;
}

h3 {
    color: #2c3e50;
    text-align: center;

}


.make_center {
    align-items: center !important;
    text-align: center !important;
}


.ribbon-container {
    position: relative;
    width: 100px;
    height: auto;

}

.ribbon {
    position: absolute;
    top: -14px;
    left: -36px;
    width: 107px;
    padding: 5px;
    background-color: #e74c3c;
    color: #fff;
    text-align: center;
    transform: rotate(-44deg);
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
}

.progress-bar-container {
    width: 200px;
    height: 20px;
    background-color: #f0f0f0;
    border-radius: 30px;
    overflow: hidden;


}

.progress-bar {
    width: 30%;
    height: 20px;
    background-color: #2ecc71;
    animation: progressAnimation 2s ease-out forwards;

}


@keyframes progressAnimation {
    from {
        width: 0%;
    }

    to {
        width: 30%;
    }
}

.view-progress {
    text-decoration: none;
    color: #2ecc71;
    text-align: center;
    font-weight: 700;
}
</style>

<!-- subjects -->
<style>
.main-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;

}

.profile-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.profile-info {
    display: flex;
    align-items: center;
}

.profile-icon {
    float: right;
    margin-left: 5px;
}

.badge {
    display: inline-block;
    padding: 5px 10px;

    background-color: rgb(255 255 255 / 34%);
    /* Green background color with 50% opacity */
    color: white;
    font-size: 12px;
    border-radius: 5px;
}

.profile-image {
    width: 50px;
    height: 50px;
    margin-right: 5px;
    margin-top: -5px;
    border-radius: 50%;
    overflow: hidden;
    border: solid 1px yellowgreen;

}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-name {
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.profile-grade {
    font-size: 14px;
    color: white;
}

.action-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
}



.action-buttons a:hover {
    color: #fff;
}

.content-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.center-icon {
    font-size: 24px;
    color: white;
    margin-bottom: 5px;
}

.rounded-div {
    width: calc(33.33% - 20px);
    margin: 10px;
    padding: 20px;
    border-radius: 17px;
     background-color: #E5E4E2; 
    text-align: center;
    transition: transform 0.3s;
}

.rounded-div img {
    max-width: 55%;
    max-height: 55%;
    border-radius: 50%;
    margin-bottom: 5px;
}

.subject-name {
    font-size: 14px;
    font-weight: bold;
    color: black;
}

.student-name {
    font-size: 12px;
    color: lightgray;
}

.rounded-div:hover {
    transform: scale(1.05);
}


.rounded-div:nth-child(1) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(2) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(3) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(4) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(5) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(6) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(7) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(8) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(9) {
    background-color: #E5E4E2;
}
</style>
<!-- subjects -->
<?php
// $placeholder = base_url() . "assets/images/sunflower.jpg";

// function generateRandomColor()
// {
//     return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
// }

?>