<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-folder-open"></i><small>
                        <?php echo $this->lang->line('manage_subject'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content quick-link">
                <?php $this->load->view('quick-link'); ?>
            </div>
            <?php if($this->session->userdata('role_id') != TEACHER) { ?>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    <ul class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_subject_list" role="tab"
                                data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i>
                                <?php echo $this->lang->line('list'); ?></a> </li>
                        <?php if(has_permission(ADD, 'academic', 'subject')){ ?>
                        <?php if(isset($edit)){ ?>
                        <li class="<?php if(isset($add)){ echo 'active'; }?>"><a
                                href="<?php echo site_url('academic/subject/add'); ?>" aria-expanded="false"><i
                                    class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('add'); ?></a> </li>
                        <?php }else{ ?>
                        <li class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_subject" role="tab"
                                data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i>
                                <?php echo $this->lang->line('add'); ?></a> </li>
                        <?php } ?>
                        <?php } ?>
                        <?php if(isset($edit)){ ?>
                        <li class="active"><a href="#tab_edit_subject" role="tab" data-toggle="tab"
                                aria-expanded="false"><i class="fa fa-pencil-square-o"></i>
                                <?php echo $this->lang->line('edit'); ?></a> </li>
                        <?php } ?>

                        <li class="li-class-list">
                            <?php if($this->session->userdata('role_id') == SUPER_ADMIN){  ?>

                            <?php echo form_open(site_url('academic/subject/index'), array('name' => 'filter', 'id' => 'filter', 'class'=>'form-horizontal form-label-left'), ''); ?>
                            <select class="form-control col-md-7 col-xs-12" style="width:auto;" name="school_id"
                                onchange="get_class_by_school(this.value, '');">
                                <option value="">--<?php echo $this->lang->line('select_school'); ?>--</option>
                                <?php foreach($schools as $obj ){ ?>
                                <option value="<?php echo $obj->id; ?>"
                                    <?php if(isset($filter_school_id) && $filter_school_id == $obj->id){ echo 'selected="selected"';} ?>>
                                    <?php echo $obj->school_name; ?></option>
                                <?php } ?>
                            </select>
                            <select class="form-control col-md-7 col-xs-12" id="filter_class_id" name="class_id"
                                style="width:auto;" onchange="this.form.submit();">
                                <option value="">--<?php echo $this->lang->line('class'); ?>--</option>
                                <?php if(isset($class_list) && !empty($class_list)){ ?>
                                <?php foreach($class_list as $obj ){ ?>
                                <option value="<?php echo $obj->id; ?>"><?php echo $obj->name; ?></option>
                                <?php } ?>
                                <?php } ?>
                            </select>
                            <?php echo form_close(); ?>

                            <?php }elseif($this->session->userdata('role_id') == TEACHER){  ?>
                            <?php }else{  ?>
                            <select class="form-control col-md-7 col-xs-12"
                                onchange="get_subject_by_class(this.value);">
                                <?php if($this->session->userdata('role_id') != STUDENT){ ?>
                                <option value="<?php echo site_url('academic/subject/index'); ?>">
                                    --<?php echo $this->lang->line('select'); ?>--</option>
                                <?php } ?>

                                <?php $guardian_class_data = get_guardian_access_data('class'); ?>
                                <?php foreach($classes as $obj ){ ?>
                                <?php if($this->session->userdata('role_id') == STUDENT){ ?>
                                <?php if ($obj->id != $this->session->userdata('class_id')){ continue; } ?>
                                <option value="<?php echo site_url('academic/subject/index/'.$obj->id); ?>"
                                    <?php if(isset($class_id) && $class_id == $obj->id){ echo 'selected="selected"';} ?>>
                                    <?php echo $obj->name; ?></option>
                                <?php }elseif($this->session->userdata('role_id') == GUARDIAN){ ?>
                                <?php if (!in_array($obj->id, $guardian_class_data)) { continue; } ?>
                                <option value="<?php echo site_url('academic/subject/index/'.$obj->id); ?>"
                                    <?php if(isset($class_id) && $class_id == $obj->id){ echo 'selected="selected"';} ?>>
                                    <?php echo $obj->name; ?></option>
                                <?php }else{ ?>
                                <option value="<?php echo site_url('academic/subject/index/'.$obj->id); ?>"
                                    <?php if(isset($class_id) && $class_id == $obj->id){ echo 'selected="selected"';} ?>>
                                    <?php echo $obj->name; ?></option>
                                <?php } ?>
                                <?php } ?>
                            </select>
                            <?php } ?>
                        </li>
                    </ul>
                    <br />

                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_subject_list">
                            <div class="x_content">
                                <table id="datatable-responsive"
                                    class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?></th>
                                            <?php if($this->session->userdata('role_id') == SUPER_ADMIN){ ?>
                                            <th><?php echo $this->lang->line('school'); ?></th>
                                            <?php } ?>
                                            <th><?php echo $this->lang->line('name'); ?></th>
                                            <th><?php echo $this->lang->line('subject_code'); ?></th>
                                            <th><?php echo $this->lang->line('class'); ?></th>
                                            <th><?php echo $this->lang->line('teacher'); ?></th>
                                            <th><?php echo $this->lang->line('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1; if(isset($subjects) && !empty($subjects)){ ?>
                                        <?php foreach($subjects as $obj){ ?>
                                        <?php 
                                            if($this->session->userdata('role_id') == GUARDIAN){
                                                if (!in_array($obj->class_id, $guardian_class_data)) {continue; }
                                            }elseif($this->session->userdata('role_id') == STUDENT){
                                                if ($obj->class_id != $this->session->userdata('class_id')){ continue; }
                                            }
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <?php if($this->session->userdata('role_id') == SUPER_ADMIN){ ?>
                                            <td><?php echo $obj->school_name; ?></td>
                                            <?php } ?>
                                            <td><?php echo $obj->name; ?></td>
                                            <td><?php echo $obj->code; ?></td>
                                            <td><?php echo $obj->class_name; ?></td>
                                            <td><?php echo $obj->teacher; ?></td>
                                            <td>
                                                <?php if(has_permission(EDIT, 'academic', 'subject')){ ?>
                                                <a href="<?php echo site_url('academic/subject/edit/'.$obj->id); ?>"
                                                    class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i>
                                                    <?php echo $this->lang->line('edit'); ?> </a>
                                                <?php } ?>
                                                <?php if(has_permission(VIEW, 'academic', 'subject')){ ?>
                                                <a onclick="get_subject_modal(<?php echo $obj->id; ?>);"
                                                    data-toggle="modal" data-target=".bs-subject-modal-lg"
                                                    class="btn btn-success btn-xs"><i class="fa fa-eye"></i>
                                                    <?php echo $this->lang->line('view'); ?> </a>
                                                <?php } ?>
                                                <?php if(has_permission(DELETE, 'academic', 'subject')){ ?>
                                                <a href="<?php echo site_url('academic/subject/delete/'.$obj->id); ?>"
                                                    onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');"
                                                    class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                                                    <?php echo $this->lang->line('delete'); ?> </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_subject">
                            <div class="x_content">
                                <?php echo form_open(site_url('academic/subject/add'), array('name' => 'add', 'id' => 'add', 'class'=>'form-horizontal form-label-left'), ''); ?>
                                <?php $this->load->view('layout/school_list_form'); ?>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="name"><?php echo $this->lang->line('name'); ?><span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="name" id="name"
                                            value="<?php echo isset($post['name']) ?  $post['name'] : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('name'); ?>" required="required"
                                            type="text" autocomplete="off">
                                        <div class="help-block"><?php echo form_error('name'); ?></div>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="code"><?php echo $this->lang->line('subject_code'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="code" id="code"
                                            value="<?php echo isset($post['code']) ?  $post['code'] : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('subject_code'); ?>" type="text"
                                            autocomplete="off">
                                        <div class="help-block"><?php echo form_error('code'); ?></div>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="author"><?php echo $this->lang->line('author'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="author" id="author"
                                            value="<?php echo isset($post['author']) ?  $post['author'] : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('author'); ?>" type="text"
                                            autocomplete="off">
                                        <div class="help-block"><?php echo form_error('author'); ?></div>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="type"><?php echo $this->lang->line('type'); ?> </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="type" id="type">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php $types = get_subject_type(); ?>
                                            <?php foreach($types as $key=>$value){ ?>
                                            <option value="<?php echo $key; ?>"
                                                <?php echo isset($post['type']) && $post['type'] == $key ?  'selected="selected"' : ''; ?>>
                                                <?php echo $value; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('type'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="class_id"><?php echo $this->lang->line('class'); ?> <span
                                            class="required">*</span> </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="class_id"
                                            id="add_class_id" required="required">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php foreach($classes as $obj ){ ?>
                                            <option value="<?php echo $obj->id; ?>"
                                                <?php echo (isset($post['class_id']) && $post['class_id'] == $obj->id) || isset($class_id) && $class_id == $obj->id ?  'selected="selected"' : ''; ?>>
                                                <?php echo $obj->name; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('class_id'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="teacher_id"><?php echo $this->lang->line('teacher'); ?> <span
                                            class="required">*</span> </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="teacher_id"
                                            id="add_teacher_id" required="required">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php foreach($teachers as $obj ){ ?>
                                            <option value="<?php echo $obj->id; ?>"
                                                <?php echo isset($post['teacher_id']) && $post['teacher_id'] == $obj->id ?  'selected="selected"' : ''; ?>>
                                                <?php echo $obj->name; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('teacher_id'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="note"><?php echo $this->lang->line('note'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea class="form-control col-md-7 col-xs-12" name="note" id="note"
                                            placeholder="<?php echo $this->lang->line('note'); ?>"><?php echo isset($post['note']) ?  $post['note'] : ''; ?></textarea>
                                        <div class="help-block"><?php echo form_error('note'); ?></div>
                                    </div>
                                </div>

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('academic/subject/index'); ?>"
                                            class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit"
                                            class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_subject">
                            <div class="x_content">
                                <?php echo form_open(site_url('academic/subject/edit/'.$subject->id), array('name' => 'edit', 'id' => 'edit', 'class'=>'form-horizontal form-label-left'), ''); ?>
                                <?php $this->load->view('layout/school_list_edit_form'); ?>

                                <!-- <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                                        <?php echo $this->lang->line('name'); ?> <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="name" id="name"
                                            value="<?php echo isset($subject->name) ?  $subject->name : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('name'); ?>" type="text"
                                            autocomplete="off">
                                        <div class="help-block">
                                            <?php echo form_error('name'); ?>
                                        </div>
                                    </div>
                                </div> -->
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                                        <?php echo $this->lang->line('name'); ?> <span class="">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="name" id="name"
                                            value="<?php echo isset($subject->name) ?  $subject->name : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('name'); ?>" type="text"
                                            autocomplete="off">
                                        <div class="help-block">
                                            <?php echo form_error('name'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="code"><?php echo $this->lang->line('subject_code'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="code" id="code"
                                            value="<?php echo isset($subject->code) ?  $subject->code : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('subject'); ?> <?php echo $this->lang->line('code'); ?>"
                                            type="text" autocomplete="off">
                                        <div class="help-block"><?php echo form_error('code'); ?></div>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="author"><?php echo $this->lang->line('author'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input class="form-control col-md-7 col-xs-12" name="author" id="author"
                                            value="<?php echo isset($subject->author) ?  $subject->author : ''; ?>"
                                            placeholder="<?php echo $this->lang->line('author'); ?>" type="text"
                                            autocomplete="off">
                                        <div class="help-block"><?php echo form_error('author'); ?></div>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="type"><?php echo $this->lang->line('type'); ?> </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="type" id="type">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php $types = get_subject_type(); ?>
                                            <?php foreach($types as $key=>$value){ ?>
                                            <option value="<?php echo $key; ?>"
                                                <?php if($subject->type == $key){ echo 'selected="selected"';} ?>>
                                                <?php echo $value; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('type'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="class_id"><?php echo $this->lang->line('class'); ?> <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="class_id"
                                            id="edit_class_id" required="required">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php foreach($classes as $obj ){ ?>
                                            <option value="<?php echo $obj->id; ?>"
                                                <?php if($subject->class_id == $obj->id){ echo 'selected="selected"';} ?>>
                                                <?php echo $obj->name; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('class_id'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="teacher_id"><?php echo $this->lang->line('teacher'); ?> <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" name="teacher_id"
                                            id="edit_teacher_id" required="required">
                                            <option value="">--<?php echo $this->lang->line('select'); ?>--</option>
                                            <?php foreach($teachers as $obj ){ ?>
                                            <option value="<?php echo $obj->id; ?>"
                                                <?php if($subject->teacher_id == $obj->id){ echo 'selected="selected"';} ?>>
                                                <?php echo $obj->name; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php echo form_error('teacher_id'); ?></div>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                        for="note"><?php echo $this->lang->line('note'); ?></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea class="form-control col-md-7 col-xs-12" name="note" id="note"
                                            placeholder="<?php echo $this->lang->line('note'); ?>"><?php echo isset($subject->note) ?  $subject->note : ''; ?></textarea>
                                        <div class="help-block"><?php echo form_error('note'); ?></div>
                                    </div>
                                </div>

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($subject) ? $subject->id : $id; ?>"
                                            name="id" />
                                        <a href="<?php echo site_url('academic/subject/index'); ?>"
                                            class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit"
                                            class="btn btn-success"><?php echo $this->lang->line('update'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <?php } else { ?>
                    <div class="x_panel">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="main-container">
                                    <div class="content-section">
                                        <?php foreach ($subjects as $obj) {
                                                $content = $obj->name;
                                                $contentWithoutTags = strip_tags($content);
                                                $words = explode(' ', $contentWithoutTags);
                                                $limitedDescription = implode(' ', array_slice($words, 0, 70));
                                            ?>

                                      <!--<a href="<?php echo site_url('academic/subject/chakralist/' . $obj->m_subjects_id); ?>">  -->
                                         <a href="<?php echo ($obj->total_students > 0) ? site_url('academic/subject/chakralist/' . $obj->m_subjects_id) : 'javascript:void(0)'; ?>" class="rounded-link">
                                        <div class="rounded-div">
                                            <div class="itemWrap">
                                                <div class="topdata">
                                                    <h2 style="font-size: 22px;"><?= $obj->name; ?></h2><p><?= $obj->class_name; ?></p>

                                                </div>
                                                <div class="" btmData>
                                                     <div class="itemWrap">
                                                          <img src="<?php echo base_url(); ?>/assets/images/ico-1.png" alt="Icon 1">
                                                        
                                                        <!--<?php if ($obj->total_com_chakra == $obj->total_students) { ?>-->
                                                        <!--    <img src="<?php echo base_url(); ?>/assets/images/ico-1.png" alt="Icon 1">-->
                                                        <!--<?php } else { ?>-->
                                                        <!--    <img src="<?php echo base_url(); ?>/assets/images/redicon.png" alt="Red Icon">-->
                                                        <!--<?php } ?>-->
                                                    </div>
                                                    <div class="dataWrap" >                                                     
                                                       <!--<?php if ($obj->total_students > 0) { ?>-->
                                                       <!--     <h3 style="color:#08c;"><?= $obj->total_com_chakra; ?>/<?= $obj->total_students; ?> Students</h3>-->
                                                       <!--     <p>Have completed the task</p>-->
                                                       <!-- <?php } else { ?>-->
                                                       <!--     <p>No students available</p>-->
                                                       <!-- <?php } ?>-->
                                                        <h3 style="color:#08c;">Progress in Chakra</h3>
                                                         <!--<h3 style="color:#08c;"><?=  $obj->total_com_chakra; ?>/<?= $obj->total_students; ?> Students</h3>-->
                                                           <a href></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                        <!-- <div class="rounded-div">
                                                <a href="<?= site_url('/academic/subject/progress'); ?>">
                                                  
                                                    <div class="subject-name"><?= $limitedDescription; ?></div>
                                                </a>
                                                <p class="room"><?= $obj->class_name; ?></p>
                                                <p class="room">Total Students: <?= $obj->total_students; ?>
                                                </p>
                                            </div> -->

                                        <?php
                                                }
                                                ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-subject-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
            </div>
            <div class="modal-body fn_subject_data">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
function get_subject_modal(subject_id) {

    $('.fn_subject_data').html(
        '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loading.gif" /></p>'
    );
    $.ajax({
        type: "POST",
        url: "<?php echo site_url('academic/subject/get_single_subject'); ?>",
        data: {
            subject_id: subject_id
        },
        success: function(response) {
            if (response) {
                $('.fn_subject_data').html(response);
            }
        }
    });
}
</script>

<!-- Super admin js START  -->
<script type="text/javascript">
var edit = false;
<?php if(isset($school_id)){ ?>
edit = true;
<?php } ?>

$("document").ready(function() {
    <?php if(isset($school_id) && !empty($school_id)){ ?>
    $("#edit_school_id").trigger('change');
    <?php } ?>
});

$('.fn_school_id').on('change', function() {

    var school_id = $(this).val();
    var class_id = '';
    var teacher_id = '';

    <?php if(isset($subject) && !empty($subject)){ ?>
    class_id = '<?php echo $subject->class_id; ?>';
    teacher_id = '<?php echo $subject->teacher_id; ?>';
    <?php } ?>

    if (!school_id) {
        toastr.error('<?php echo $this->lang->line("select_school"); ?>');
        return false;
    }

    $.ajax({
        type: "POST",
        url: "<?php echo site_url('ajax/get_class_by_school'); ?>",
        data: {
            school_id: school_id,
            class_id: class_id
        },
        async: false,
        success: function(response) {
            if (response) {
                if (edit) {
                    $('#edit_class_id').html(response);
                } else {
                    $('#add_class_id').html(response);
                }

                get_teacher_by_school(school_id, teacher_id);
            }
        }
    });
});

function get_teacher_by_school(school_id, teacher_id) {

    $.ajax({
        type: "POST",
        url: "<?php echo site_url('ajax/get_teacher_by_school'); ?>",
        data: {
            school_id: school_id,
            teacher_id: teacher_id
        },
        async: false,
        success: function(response) {
            if (response) {
                if (edit) {
                    $('#edit_teacher_id').html(response);
                } else {
                    $('#add_teacher_id').html(response);
                }
            }
        }
    });
}
</script>
<!-- Super admin js end -->

<!-- datatable with buttons -->
<script type="text/javascript">
$(document).ready(function() {
    $('#datatable-responsive').DataTable({
        dom: 'Bfrtip',
        iDisplayLength: 15,
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
            'pageLength'
        ],
        search: true,
        responsive: true
    });
});

<?php if(isset($filter_class_id)){ ?>
get_class_by_school('<?php echo $filter_school_id; ?>', '<?php echo $filter_class_id; ?>');
<?php } ?>

function get_class_by_school(school_id, class_id) {

    $.ajax({
        type: "POST",
        url: "<?php echo site_url('ajax/get_class_by_school'); ?>",
        data: {
            school_id: school_id,
            class_id: class_id
        },
        async: false,
        success: function(response) {
            if (response) {
                $('#filter_class_id').html(response);
            }
        }
    });
}

function get_subject_by_class(url) {

    if (url) {
        window.location.href = url;
    }
}

$("#add").validate();
$("#edit").validate();
</script>
<script>
function generateRandomColor() {
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}
</script>


<!-- <style>
/* .bg {
    background-color: #8fd3f4;
    /* background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"%3E%3Cpath fill="%23ffffff" d="M0 192l48-5.3C96 181 192 171 288 181.3c96 10.7 192 42.7 288 58.7C672 267 768 267 864 261.3c96-5.7 192-21.7 288-37.4s192-32.7 240-37.4l48-5.3v320H0z"%3E%3C/path%3E%3C/svg%3E'); */
    background-image: url('/school-lms/assets/images/down.png');
    background-size: cover;
} */
</style> -->


<style>
.room {
    color: black;
}

h3 {
    color: #2c3e50;
    text-align: center;

}


.make_center {
    align-items: center !important;
    text-align: center !important;
}


.ribbon-container {
    position: relative;
    width: 100px;
    height: auto;

}

.ribbon {
    position: absolute;
    top: -14px;
    left: -36px;
    width: 107px;
    padding: 5px;
    background-color: #e74c3c;
    color: #fff;
    text-align: center;
    transform: rotate(-44deg);
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
}

.progress-bar-container {
    width: 200px;
    height: 20px;
    background-color: #f0f0f0;
    border-radius: 30px;
    overflow: hidden;


}

.progress-bar {
    width: 30%;
    height: 20px;
    background-color: #2ecc71;
    animation: progressAnimation 2s ease-out forwards;

}


@keyframes progressAnimation {
    from {
        width: 0%;
    }

    to {
        width: 30%;
    }
}

.view-progress {
    text-decoration: none;
    color: #2ecc71;
    text-align: center;
    font-weight: 700;
}
</style>

<!-- subjects -->
<style>
.main-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;

}

.profile-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.profile-info {
    display: flex;
    align-items: center;
}

.profile-icon {
    float: right;
    margin-left: 5px;
}

.badge {
    display: inline-block;
    padding: 5px 10px;

    background-color: rgb(255 255 255 / 34%);
    /* Green background color with 50% opacity */
    color: white;
    font-size: 12px;
    border-radius: 5px;
}

.profile-image {
    width: 50px;
    height: 50px;
    margin-right: 5px;
    margin-top: -5px;
    border-radius: 50%;
    overflow: hidden;
    border: solid 1px yellowgreen;

}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-name {
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.profile-grade {
    font-size: 14px;
    color: white;
}

.action-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
}



.action-buttons a:hover {
    color: #fff;
}

.content-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.center-icon {
    font-size: 24px;
    color: white;
    margin-bottom: 5px;
}

.rounded-div {
    width: calc(33.33% - 20px);
    margin: 10px;
    padding: 20px;
    border-radius: 17px;
     background-color:#E5E4E2; 
    text-align: center;
    transition: transform 0.3s;
}

.rounded-div img {
    max-width: 55%;
    max-height: 55%;
    border-radius: 50%;
    margin-bottom: 5px;
}

.subject-name {
    font-size: 14px;
    font-weight: bold;
    color: black;
}

.student-name {
    font-size: 12px;
    color: lightgray;
}

.rounded-div:hover {
    transform: scale(1.05);
}


.rounded-div:nth-child(1) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(2) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(3) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(4) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(5) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(6) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(7) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(8) {
    background-color: #E5E4E2;
}

.rounded-div:nth-child(9) {
    background-color: #E5E4E2;
}

.x_panel {
            position: relative;
            width: 100%;
            min-height:100vh;
            margin-bottom: 10px;
            padding: 5px 17px;
            display: inline-block;
            background: #fff;
            border: 1px solid #E6E9ED;
            -webkit-column-break-inside: avoid;
            -moz-column-break-inside: avoid;
            column-break-inside: avoid;
            opacity: 1;
            transition: all .2s ease;
        }
</style>
<!-- subjects -->
<?php
// $placeholder = base_url() . "assets/images/sunflower.jpg";

// function generateRandomColor()
// {
//     return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
// }

?>