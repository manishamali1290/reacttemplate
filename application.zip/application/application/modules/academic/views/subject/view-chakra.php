<!-- datepicker -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.9/dist/flatpickr.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.9/dist/flatpickr.min.css">

<style>
    #studentTable{
        display: none;
    }
    .chart-item {
    min-height: 50px;
}
    .calendar-input {
        /* width: 60%;
        padding: 14px;
        border: 1px solid #ccc;
        border-radius: 50px;
        margin-top: 10px;
        box-sizing: border-box;
        display: inline-block;
        background-color: #f8f8f8;
        cursor: pointer;
        margin-left: 10px;
        font-weight: 600; */

        max-width: 100%;
        width: 60%;
        text-align: center;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border: 2px solid #ddd;
        border-radius: 50px;
        padding: 10px;
        background-color: #f4f4f4;
        color: black;
        font-weight: 600;
        margin-top: 10px;
        margin-left: 5px;
    }

    .calendar-input:focus {
        outline: none;
        box-shadow: 0 0 5px rgba(52, 152, 219, 0.7);
        border-color: #3498db;
    }
</style>

<!-- datepicker -->


<style>
    .charting_card {
        background-color: #f4f4f4;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 10px;
        margin-left: 10px;

    }

    .title-section {
        text-align: center;
        margin-bottom: 20px;
    }

    /* .chart {
        display: flex;
        justify-content: space-around;
        align-items: flex-end;
        border-bottom: 2px solid #ccc;
        margin-top: 100px;

    }

    .chart-item {
        width: 120px;
        background-color: #3498db;
        text-align: center;
       

    } */



    .top-right-section {
        margin-left: 20px;
        color: white;
        font-weight: 600;
        margin-top: 10px;
        font-family: 'Times New Roman', Times, serif;

    }


    .top-left-section {

        max-width: 100%;
        width: 35%;
        text-align: center;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border: 2px solid #ddd;
        border-radius: 50px;
        padding: 10px;
        background-color: #f4f4f4;
        color: black;
        float: right;
        color: #5A738E;
        font-weight: 600;
        margin-top: 10px;
    }

    /* .candle-status {
        font-size: 14px;
        margin-bottom: 5px;
        color: #fff;
       
       

    } */

    /* .candle-status p {
        font-weight: 600;
    } */


    .chart {
        display: flex;
        justify-content: space-around;
        align-items: flex-end;

        height: 300px;

    }

    .chart-item {
        width: 25%;
        background-color: #3498db;
        border: 1px solid #ccc;
        box-sizing: border-box;
        overflow: hidden;
        position: relative;
        text-align: center;
    }

    .candle-status {
        padding: 10px;
        text-align: center;
        position: absolute;
        top: 0;
        width: 100%;
        box-sizing: border-box;
        font-weight: 600;
        color: white;

    }

    .edit-icon {
        font-size: 14px;
        color: #2ecc71;
        /* Green color, change as needed */
        float: right;
    }

    .bg {
        background: linear-gradient(45deg, #3498db, #f2f2f2);
    }

    #view_list_btn {
        background: #f4f4f4 !important;
        float: right;
        height: 42px;
        margin-right: 139px;
        width: 159px;
            margin-top: 30px;
        border-radius: 40px;
        color: white;

    }
</style>

<!-- table -->
<style>
    .status-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        /* background-color: #3498db; */
        color: #fff;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    .status-title {
        margin: 0;
    }

    .send-reminder-btn {
        background-color: #f61f1f;
        width: 150px;
        color: #fff;
        border: none;
        padding: 10px;
        border-radius: 40px;
        cursor: pointer;
        display: flex;
        text-align: center;
    }

    .send-reminder-btn i {
        margin-right: 5px;
    }

    .status-table {
        width: 100%;
        border-collapse: collapse;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 5px;
    }

    .status-table th,
    .status-table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }

    .status-table th {
        background-color: #5eace0;
        color: #fff;
    }

    @media (max-width: 768px) {

        .status-table th,
        .status-table td {
            font-size: 14px;
        }
    }
</style>

<style>
    .chakras_card {
        position: relative;
        background-color: #d5d0eb;
        border-radius: 10px;
        overflow: hidden;
        height: 300px;
        margin-left: 20px;
        margin-top: 20px;
        /* Set a fixed height for the card */
    }

    .video-button {
        margin-top: 5px;
        margin-left: 9px;
        background: transparent;
        border: 0px;
        color: #9d95c2;
    }


    .btn_settings {
        position: absolute;
        width: 50px;
        height: 50px;
        background-color: #ffffff;
        bottom: 10px;
        right: 10px;
        font-size: 24px;
        cursor: pointer;
        border-radius: 50px;
        align-items: center;
        text-align: center;
    }

    .help-button {
        background: transparent;
        border: none;
        color: #fff;
        font-size: 24px;
        cursor: pointer;
        margin-top: 3px;
        margin-left: 6px;

    }

    .tutorial_btn {
        width: 40px;
        height: 40px;
        background-color: #a54484;
        font-size: 24px;
        cursor: pointer;
        border-radius: 50px;
        align-items: center;
        text-align: center;
        float: right;
    }

    .content-section {
        text-align: left;
        margin-top: 20px;
    }

    .content-section h2 {
        color: #333;
    }

    .content-section p {
        color: #777;
    }

    .buttons-inline {
        margin-top: 10px;
    }

    .button {
        background-color: #3498db;
        color: #fff;
        width: 140px;
        border-radius: 50px !important;
        padding: 10px;
        border: none;
        border-radius: 5px;
        margin-right: 10px;
        cursor: pointer;
    }

    .button a {
        color: white;
    }
    .button a:hover {
        color: white;
    }

    .button:last-child {
        margin-right: 0;
    }

    .top-section {
        max-width: 100%;
        width: 60%;
        text-align: center;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border: 2px solid #ddd;
        border-radius: 50px;
        padding: 10px;
        background-color: #f4f4f4;
        color: black;
        float: right;
        color: #5A738E;
        font-weight: 600;
        margin-top: 10px;
    }
</style>


<!-- box-contianer -->
<style>
    .title-box {
        font-size: 24px;
        font-weight: bold;
        margin-top: 10px;
        margin-left: 5px;
        color: white;
    }

    .content-box {
        border: 2px solid #87CEEB;
        /* Light Blue color */
        border-radius: 20px;
        padding: 20px;
        background-color: #fff;
        height: 400px;
    }
</style>
<!-- box container -->

<!-- lets discuss section -->
<style>
    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        max-width: 1200px;
        margin: 0 auto;
    }

    .card {
        width: 31%;
        margin-bottom: 20px;
        background-color: #f8f8f8;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        transition: transform 0.3s ease-in-out;
        height: auto;
    }

    .card:hover {
        transform: scale(1.05);
    }

    .profile-image {
        width: 100%;
        height: 100px;
        background-color: #3498db;
    }

    .user-info {
        display: flex;
        align-items: center;
        padding: 10px;
    }

    .user-image {
        width: 30px;
        height: 30px;
        background-color: #3498db;
        border-radius: 5px;
        margin-right: 10px;
    }

    .user-name-section {
        flex-grow: 1;
        overflow: hidden;
    }

    .user-name {
        font-weight: bold;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .lesson-title-comment {
        font-size: 18px;
        font-weight: bold;
        margin: 10px 0;
        overflow: hidden;
        text-overflow: ellipsis;

    }

    .text-content {

        color: #555;
    }

    .date {
        text-align: right;
        padding: 10px;
        color: #888;
    }

    @media (max-width: 768px) {
        .card {
            width: 48%;
        }
    }

    @media (max-width: 480px) {
        .card {
            width: 100%;
        }
    }
</style>
<!-- lets discuss section ends -->

<!-- chat section css -->
<style>
    .main-container {
        max-width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .info-container {
        width: 100%;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
        box-sizing: border-box;
        margin-bottom: 20px;
    }

    .user-info {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
    }

    .user-profile {
        width: 40px;
        height: 40px;
        overflow: hidden;
        margin-right: 10px;

    }

    .user-profile img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 5px;
    }

    .lesson-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 15px;

    }

    .lesson-content {
        margin-bottom: 15px;
        text-align: justify;
    }

    .comment-section {
        width: 100%;
        display: flex;
        align-items: center;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 10px;
        box-sizing: border-box;
    }

    .comment-profile {
        width: 30px;
        height: 30px;
        overflow: hidden;
        margin-right: 10px;

    }

    .comment-profile img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .comment-input {
        flex: 1;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 10px;
    }

    .send-button {
        padding: 8px 15px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
</style>
<!-- chat section ends -->

<!-- saylubs report -->
<style>
    .report_table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: #f2f2f2;
    }

    .report_table th,
    td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;

    }

    .report_table td {
        height: 80px;
    }

    .report_table th {
        background-color: #f2f2f2;
    }


    .report_table .col1 {
        width: 10%;

    }
    .button-link {
        display: inline-block;
        padding: 10px 20px;
        background-color: #800080; /* Green background color */
        color: white; /* White text color */
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 20px;
    }
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
             <h3 class="head-title">
                <a href="javascript:history.go(-1);" class="button-link">
                    <strong>&lt; Previous</strong>
                </a>
            </h3><br><br>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    <div class="tab-content">
                        <div class="tab-pane fade in <?php if (isset($add)) {
                                                            echo 'active';
                                                        } ?>" id="tab_add_state">
                            <div class="x_content">
                                <form method="post" action="<?php echo site_url('administrator/course_access/add') ?>" enctype="multipart/form-data">
                                    <div class="x_content">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong>Select <?php echo $this->lang->line('school'); ?>:</strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- Your form fields here -->
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="school_id"><?php echo $this->lang->line('school'); ?>
                                                        <span class="required">*</span></label>
                                                    <select class="form-control col-md-7 col-xs-12 status-type" name="school_id" id="school_id" style="float: left;" required="required">
                                                        <option value="">--<?php echo $this->lang->line('select'); ?>--
                                                        </option>
                                                        <?php foreach ($schools as $sp) { ?>
                                                            <option value="<?php echo $sp->id; ?>">
                                                                <?php echo $sp->school_name; ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>

                                                    <div class="help-block"><?php echo form_error('school_id'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course_access/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit" class="btn btn-success">Synchronous
                                                    Course</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <?php echo form_close(); ?>
                                <?php echo form_close(); ?>
                            </div>
                        </div>

                        

                        <div class="tab-pane fade in  <?php if (isset($list_chakra_info)) {
                                                            echo 'active';
                                                        } ?> " id="tab_chakra">
                            <div class="x_content ">
                                    <div style="">
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6 col-xl-6">
                                                <div class="top-right-section">
                                                    <div>
                                                        <h1 style="color: black;"><?php echo $list_chakra_info->course_name;?></h1>
                                                       <!--  <h4><?php echo $no_of_std['chak']['grade_title'] ?></h4> -->
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="row">
                                            <div class="col-sm-4 col-md-4 col-xl-4">
                                                <div class="charting_card">
                                                    <h2><?php echo $list_chakra_info->class_name;?></h2>
                                                    <h3><?= $list_chakra_info->unit_name;?></h3>
                                                    <h4><?php echo $list_chakra_info->subject_name;?></h4>
                                                    <!-- <h3><?php echo $list_chakra_info->class_name;?></h3> -->
                                                   <!--  <p>chakra_description</p> -->
                                                </div>
                                                <div class="charting_card">

                                                    <b>Completed Date</b>
                                                    <b><a href="<?php echo site_url('administrator/course_access/edit_chakra/' . $list_chakra_info->id); ?>" class="edit-icon" title="Edit Task">Edit &#9998;</a></b>
                                                    <p><?php echo  "<b>Start:</b> " . date('d/m/Y',strtotime($list_chakra_info->active_time)). "</br><b>End:</b> " . date('d/m/Y',strtotime($list_chakra_info->inactive_time)); ?></p>
                                                </div>
                                            </div>

                                            <?php
                                            $completedStudents = 0;
                                            $incompletedStudents = 0;
                                            foreach ($list_student as $obj) {

                                                if ($obj->result_id) {
                                                $completedStudents++;
                                                } else {
                                                $incompletedStudents++;
                                                }
                                            }
                                            
                                            ?>

                                            <div class="col-sm-8 col-md-8 col-xl-8">
                                                <div class="chart">
                                                    <!-- <h1>complete <?= $completedStudents; ?> incoplete <?= $incompletedStudents;?></h1> -->
                                                    <?php $total_students = $completedStudents + $incompletedStudents;

                                                        $percentage_completed = ($completedStudents / $total_students) * 100;
                                                        $percentage_incompleted = ($incompletedStudents / $total_students) * 100;?>                                                  

                                                    <div class="chart-item" style="height: <?= $percentage_incompleted ?>%;background-color:red">
                                                        <div class="candle-status">InCompleted <p><?= $incompletedStudents ?> Students</p>
                                                        </div>
                                                    </div>
                                                    <div class="chart-item" style="height: <?= $percentage_completed ?>%;">
                                                        <div class="candle-status">Completed <p><?= $completedStudents ?> Students</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-12">
                                                <button class="btn btn-primary " id="view_list_btn">View List</button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row " id="studentTable" style="" >
                                        <div class="col-sm-12">
                                          <!--   <div class="status-header">
                                                <h2 class="status-title">Status Title</h2>
                                                <button class="send-reminder-btn">
                                                    <b> &nbsp; Send Reminder &#x1F514;</b>
                                                </button>
                                            </div> -->

                                            <table class="status-table">
                                                <thead>
                                                    <tr>
                                                        <th>Student Name</th>
                                                        <th>Completed</th>
                                                        <th>Score</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                        <?php foreach ($list_student as $obj) {?>
                                                    <tr>
                                                        <td><?=  $obj->name; ?> </td>
                                                        <td><?php  if($obj->result_id){ 
                                                           echo date('d/m/Y H:m:s',strtotime($obj->result_C_date));
                                                       } ?></td>
                                                        <td><?php  if($obj->result_get_number){ 
                                                           echo $obj->result_get_number;} else{echo "0";} echo '/100';
                                                        ?></td>
                                                        <td><?php if($obj->result_id){echo "Completed";}else{echo "Pending";}?></td>
                                                    </tr>
                                                         <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                    <div class="row" style="display:none ;">
                                        <div class="col-sm-12 col-md-12 col-xl-12">

                                            <div class="page-container">
                                                <div class="title-box">Evidence of Learning</div>
                                                <br>
                                                <div class="content-box">


                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row" style="display:none;">
                                        <div class="col-sm-12 col-md-12 col-xl-12">
                                            <div class="card-container">

                                                <?php

                                                for ($i = 1; $i <= 9; $i++) {
                                                ?>
                                                    <div class="card">
                                                        <!-- <div class="profile-image"></div> -->
                                                        <div class="user-info">
                                                            <div class="user-image"></div>
                                                            <div class="user-name-section">
                                                                <div class="user-name">Name</div>
                                                                <div>Class Section</div>
                                                            </div>
                                                        </div>
                                                        <div class="lesson-title">Unable To Understand</div>
                                                        <div class="text-content">

                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. ...
                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. ... Lorem ipsum dolor sit amet, consectetur adipiscing elit. ... Lorem ipsum dolor sit amet, consectetur adipiscing elit. ...
                                                        </div>
                                                        <div class="date"><?php echo date('Y-m-d') ?></div>
                                                    </div>
                                                <?php
                                                }

                                                ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row" style="display: none;">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="main-container">
                                                <div class="info-container">
                                                    <div class="user-info">
                                                        <div class="user-profile">
                                                            <img src="https://via.placeholder.com/30" alt="User Profile">
                                                        </div>
                                                        <div>
                                                            <div>Name</div>
                                                            <div>Class Section</div>
                                                        </div>
                                                    </div>
                                                    <div class="lesson-title-comment">Title goes Here...</div>
                                                    <div class="lesson-content">
                                                        <p>
                                                            In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.
                                                            In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="comment-section">
                                                    <div class="comment-profile">
                                                        <img src="https://via.placeholder.com/30" alt="User Profile">
                                                    </div>
                                                    <input type="text" class="comment-input" placeholder="Type Your Reply Here...">
                                                    <button class="send-button">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                        </div>


                        <div class="tab-pane fade in  <?php if (isset($student_status)) {
                                                            echo 'active'; 
                                                        } ?> " id="tab_chakra">

                            <div class="x_content">
                                <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <tbody>

                                        <tr>
                                            <th><?php echo $this->lang->line('sl_no'); ?> </th>
                                            <th><?php echo $this->lang->line('student'); ?></th>

                                            <th><?php echo $this->lang->line('quiz_name'); ?></th>
                                            <th><?php echo $this->lang->line('total_questions'); ?></th>
                                            <th><?php echo $this->lang->line('passing_score'); ?></th>
                                            <th><?php echo $this->lang->line('score'); ?></th>
                                            <th><?php echo $this->lang->line('done_on'); ?></th>
                                            <th><?php echo $this->lang->line('status'); ?></th>

                                        </tr>

                                        <?php $count = 1;
                                        if ($student_status_list != 0 && !empty($student_status_list['students'])) {
                                            $student_status_list['completed'];

                                            $userIds = array_column($student_status_list['completed'], 'user_id');

                                            $done_on_array = array_column($student_status_list['completed'], 'done_on');

                                            $passing_score_d = array_column($student_status_list['completed'], 'passing_score');

                                            $pt_score_d = array_column($student_status_list['completed'], 'pt_score');

                                            $score_d = array_column($student_status_list['completed'], 'score');

                                            $time_finished_d = array_column(
                                                $student_status_list['completed'],
                                                'time_finished'
                                            );

                                            $totalq_d = array_column($student_status_list['completed'], 'total_q');

                                            $quiz_name_d = array_column($student_status_list['completed'], 'quiz_name');


                                        ?>

                                            <?php
                                            $i = 0;
                                            foreach ($student_status_list['students'] as $obj) {
                                               

                                                $status = (in_array($obj->user_id, $userIds) ? 'completed' : 'pending');

                                                $style = '';
                                                if ($status == 'pending') {
                                                    $style = 'style="color:red"';
                                                }
                                                $index = array_search($obj->user_id, $userIds);
                                                $completed_date = 'N/A';

                                                $score = 'N/A';
                                                $passing_score = 'N/A';
                                                $time_finished = 'N/A';
                                                $quiz_name = 'N/A';
                                                $totalq = 'N/A';
                                                if (isset($done_on_array[$index]) && $status == 'completed') {
                                                    $completed_date = date('Y-m-d ', strtotime($done_on_array[$index]));
                                                    $score = $score_d[$index];
                                                    $passing_score = $passing_score_d[$index];
                                                    $score = $score_d[$index];
                                                    $time_finished =  date('h:i:s-Y-m-d ', strtotime($time_finished_d[$index]));
                                                    $quiz_name = $quiz_name_d[$index];

                                                    $totalq = $totalq_d[$index];
                                                }

                                                // echo "<pre>";
                                                //print_r($userIds);
                                                //print_r($index);
                                                // print_r($obj->user_id);
                                                // print_r($completed_date);
                                                //print_r($done_on_array);



                                                $i++;
                                            ?>


                                                <tr>
                                                    <td><?php echo $count++; ?></td>
                                                    <td <?php echo $style ?>><?php echo $obj->name ?></td>
                                                    <td><?php echo $quiz_name; ?></td>
                                                    <td><?php echo $totalq ?></td>
                                                    <td><?php echo $passing_score ?></td>
                                                    <td><?php echo $score; ?></td>
                                                    <td><?php echo $completed_date; ?></td>
                                                    <td><?php echo $status; ?></td>




                                                </tr>
                                            <?php } ?>
                                        <?php } ?>


                                    </tbody>
                                </table>

                            </div>
                        </div>

                        <?php if (isset($edit_chakra)) { ?>
                            <div class="tab-pane fade in active" id="tab_edit_state">
                                <div class="x_content bg">

                                    <div style="">
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6 col-xl-6">
                                                <div class="top-right-section">
                                                    <div>
                                                        <h3> <?php echo $no_of_std['chak']['section_title'] ?></h3>
                                                        <h4><?php echo $no_of_std['chak']['grade_title'] ?></h4>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="col-sm-6 col-md-6 col-xl-6">
                                                <div class="top-left-section">
                                                    <?php echo $no_of_std['chak']['subject_title'] ?>
                                                    <div></div>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="row">

                                            <div class="col-sm-6 col-md-6 col-xl-6">

                                                <div class="charting_card">
                                                    <!-- <h2>Current Unit</h2> -->
                                                    <b><?php echo $no_of_std['chak']['unit_title'] ?></b>
                                                    <p><?php echo $no_of_std['chak']['section_title'] ?></p>
                                                    <b><?php echo $no_of_std['chak']['chakra_title'] ?></b>
                                                    <p><?php echo $no_of_std['chak']['chakra_description'] ?></p>
                                                </div>
                                                <div class="charting_card">

                                                    <!-- <b>Completed Date</b>
                                                    <b><a href="#" class="edit-icon" title="Edit Task">Edit &#9998;</a></b> -->
                                                    <p><?php echo "<b>Start:</b> " . date('h:i Y-m-d ', strtotime($no_of_std['chak']['active_time'])) . "<b>End:</b> " . date('h:i Y-m-d ', strtotime($no_of_std['chak']['active_time'])); ?></p>
                                                </div>
                                            </div>

                                            <?php

                                            $completedStudents = $no_of_std['completed_std'];
                                            $incompletedStudents = $no_of_std['incompleted_std'];
                                            ?>

                                            <div class="col-sm-6 col-md-6 col-xl-6">
                                                <div class="chart">

                                                    <div class="chart-item">

                                                    </div>

                                                    <div class="chart-item" style="height: <?= $incompletedStudents * 30 ?>px;background-color:red">
                                                        <div class="candle-status">InCompleted <p><?= $incompletedStudents ?> Students</p>
                                                        </div>
                                                    </div>
                                                    <div class="chart-item" style="height: <?= $completedStudents * 30 ?>px;">
                                                        <div class="candle-status">Completed <p><?= $completedStudents ?> Students</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- <button class="btn btn-primary view_list_btn">View List</button> -->
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row" style="display:none;">
                                        <div class="col-sm-12">
                                            <div class="status-header">
                                                <h2 class="status-title">Status Title</h2>
                                                <button class="send-reminder-btn">
                                                    <b> &nbsp; Send Reminder &#x1F514;</b>
                                                </button>
                                            </div>

                                            <table class="status-table">
                                                <thead>
                                                    <tr>
                                                        <th>Student Name</th>
                                                        <th>Date</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>Imran Nasir</td>
                                                        <td>2024-01-01</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Ali Usman</td>
                                                        <td>2024-01-02</td>
                                                        <td>Inactive</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                    <div class="row" style="display:none ;">
                                        <div class="col-sm-12 col-md-12 col-xl-12">

                                            <div class="page-container">
                                                <div class="title-box">Evidence of Learning</div>
                                                <br>
                                                <div class="content-box">


                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row" style="display:none;">
                                        <div class="col-sm-12 col-md-12 col-xl-12">
                                            <div class="card-container">

                                                <?php

                                                for ($i = 1; $i <= 9; $i++) {
                                                ?>
                                                    <div class="card">
                                                        <!-- <div class="profile-image"></div> -->
                                                        <div class="user-info">
                                                            <div class="user-image"></div>
                                                            <div class="user-name-section">
                                                                <div class="user-name">Name</div>
                                                                <div>Class Section</div>
                                                            </div>
                                                        </div>
                                                        <div class="lesson-title">Unable To Understand</div>
                                                        <div class="text-content">

                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. ...
                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. ... Lorem ipsum dolor sit amet, consectetur adipiscing elit. ... Lorem ipsum dolor sit amet, consectetur adipiscing elit. ...
                                                        </div>
                                                        <div class="date"><?php echo date('Y-m-d') ?></div>
                                                    </div>
                                                <?php
                                                }

                                                ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row" style="display: none;">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="main-container">
                                                <div class="info-container">
                                                    <div class="user-info">
                                                        <div class="user-profile">
                                                            <img src="https://via.placeholder.com/30" alt="User Profile">
                                                        </div>
                                                        <div>
                                                            <div>Name</div>
                                                            <div>Class Section</div>
                                                        </div>
                                                    </div>
                                                    <div class="lesson-title-comment">Title goes Here...</div>
                                                    <div class="lesson-content">
                                                        <p>
                                                            In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.
                                                            In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="comment-section">
                                                    <div class="comment-profile">
                                                        <img src="https://via.placeholder.com/30" alt="User Profile">
                                                    </div>
                                                    <input type="text" class="comment-input" placeholder="Type Your Reply Here...">
                                                    <button class="send-button">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                </div>
                            </div>

                            <div class="row" style="display: none;">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <table class="report_table">
                                        <thead>
                                            <tr>
                                                <th class="col1">Column 1</th>
                                                <th class="col1">Column 2</th>
                                                <th class="col1">Column 3</th>
                                                <th class="col1">Column 4</th>
                                                <th class="col1">Column 5</th>
                                                <th class="col1">Column 6</th>
                                                <th class="col1">Column 7</th>
                                                <th class="col1">Column 8</th>
                                                <th class="col1">Column 9</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                                <td>Row 1</td>
                                            </tr>
                                            <tr>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                                <td>Row 2</td>
                                            </tr>
                                            <tr>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                                <td>Row 3</td>
                                            </tr>
                                            <tr>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                                <td>Row 4</td>
                                            </tr>
                                            <tr>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                                <td>Row 5</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>

                            <?php if (isset($edit_chakra)) { ?>
                                <div class="tab-pane fade in active" id="tab_edit_state">
                                    <div class="x_content">
                                        <?php echo form_open_multipart(site_url('administrator/course_access/edit_chakra/' . $chakra->id), array('name' => 'edit', 'id' => 'edit', 'class' => 'form-horizontal form-label-left'), ''); ?>

                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <h5 class="column-title">
                                                    <strong>Name:
                                                        <?php echo isset($chakra) ? $chakra->course_name : ''; ?></strong>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="item form-group">
                                            <label for="chakra_title">Name:
                                                <span><?php echo isset($chakra) ? $chakra->course_name : ''; ?></span></label>
                                        </div>
                                    </div> -->
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="active_time">Active Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="active_time" id="active_time" value="<?php echo isset($chakra) ? $chakra->active_time : ''; ?>" type="datetime-local" required="required">

                                                    <div class="help-block"><?php echo form_error('active_time'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="inactive_time">Inactive Time</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="inactive_time" id="inactive_time" type="datetime-local" value="<?php echo isset($chakra) ? $chakra->inactive_time : ''; ?>" required="required">

                                                    <div class="help-block"><?php echo form_error('inactive_time'); ?></div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-3 col-sm-3 col-xs-12">
                                                <div class="item form-group">
                                                    <label for="status">Status</label>
                                                    <input class="form-control col-md-7 col-xs-12" name="status" id="status" value="1" checked="checked" placeholder="state status" type="checkbox" autocomplete="off">

                                                    <div class="help-block"><?php echo form_error('status'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <a href="<?php echo site_url('administrator/course/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                                <button id="send" type="submit" class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                            </div>
                                        </div>

                                    <?php } ?>
                                    </div>
                                </div>

                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade bs-school-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo $this->lang->line('detail_information'); ?></h4>
                    </div>
                    <div class="modal-body fn_school_data">
                    </div>
                </div>
            </div>
        </div>

        <link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
        <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
        <script type="text/javascript">
            function get_chakra_modal(course_id) {
                if (course_id) {
                    $('.fn_school_data').html(
                        '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                    );
                    $.ajax({
                        type: "POST",
                        url: "<?php echo site_url('administrator/course_access/get_chakra_modal'); ?>/" + course_id,
                        //    data   : {course_id : course_id},  
                        success: function(response) {
                            if (response) {
                                $('.fn_school_data').html(response);
                            }
                        }
                    });
                }
            }

            function get_course_update(school_id) {
                if (school_id) {
                    $('.fn_school_data').html(
                        '<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo IMG_URL; ?>loader.gif" /></p>'
                    );
                    $.ajax({
                        type: "POST",
                        url: "<?php echo site_url('administrator/course_access/get_course_update'); ?>/" +
                            school_id,
                        //    data   : {course_id : course_id},  
                        success: function(response) {
                            if (response) {

                                location.reload();

                            }
                        }
                    });
                }
            }
        </script>


        <script>
            flatpickr('#dateRange', {
                mode: 'range',
                dateFormat: 'Y-m-d',
            });


        $(document).ready(function(){
            $("#studentTable").hide();
        $("#view_list_btn").click(function(){
            var viewListBtn = document.getElementById("view_list_btn");


        $("#studentTable").show();
         viewListBtn.style.display = "none";
        });
        });
        </script>