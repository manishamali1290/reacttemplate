<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Subject_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
      public function get_satate_list()
    {
        $this->db->select('*');
        $this->db->from('m_state');
        return $this->db->get()->result();
    }
      public function get_subjects_new_list()
    {
        $this->db->select('m_state.title AS state_title, m_grade.title AS grade_title, m_board.title AS board_title, m_course.title AS course_title, m_section.title AS section_title, m_subject.*');
        $this->db->from('m_subject');
        $this->db->join('m_state', 'm_subject.state_id = m_state.id', 'left');
        $this->db->join('m_board', 'm_subject.board_id = m_board.id', 'left');
        $this->db->join('m_course', 'm_subject.course_id = m_course.id', 'left');
        $this->db->join('m_grade', 'm_subject.grade_id = m_grade.id', 'left');
        $this->db->join('m_section', 'm_subject.section_id = m_section.id', 'left');
        return $this->db->get()->result();
    }

     public function get_subject_list($class_id = null , $school_id = null){
       
        if(!$class_id){
           $class_id = $this->session->userdata('class_id');
        }
        
        if($this->session->userdata('role_id') == TEACHER){
             $this->db->select('s.*, sc.school_name, c.name AS class_name, t.name AS teacher , COUNT(e.student_id) AS total_students');
        }
        else{
            $this->db->select('s.*, sc.school_name, c.name AS class_name, t.name AS teacher ');
       
        }

        $this->db->from('subjects AS s');
        $this->db->join('teachers AS t', 't.id = s.teacher_id', 'left');
        $this->db->join('classes AS c', 'c.id = s.class_id', 'left');
        $this->db->join('schools AS sc', 'sc.id = s.school_id', 'left');
        
        $this->db->where('c.status', 1); 
        if($this->session->userdata('role_id') == TEACHER){
            $this->db->where('s.teacher_id', $this->session->userdata('profile_id'));
             $this->db->join('enrollments AS e', 'e.school_id = s.school_id AND e.class_id = s.class_id', 'left');
             
        $this->db->group_by('s.id');
        }
        
        if($class_id > 0){
            $this->db->where('s.class_id', $class_id);
        }
        
        if($this->session->userdata('role_id') != SUPER_ADMIN){
            $this->db->where('s.school_id', $this->session->userdata('school_id'));
        }
        if($school_id && $this->session->userdata('role_id') == SUPER_ADMIN){
            $this->db->where('s.school_id', $school_id); 
        }        
        $this->db->where('sc.status', 1);
        $this->db->order_by('s.id', 'DESC');
        return $this->db->get()->result();
        
    }
    /* public function get_subject_list($class_id = null , $school_id = null){
       
        if(!$class_id){
           $class_id = $this->session->userdata('class_id');
        }
        
        $this->db->select('S.*, SC.school_name, C.name AS class_name, T.name AS teacher,COUNT(E.student_id) AS total_students');
        $this->db->from('subjects AS S');
        $this->db->join('teachers AS T', 'T.id = S.teacher_id', 'left');
        $this->db->join('classes AS C', 'C.id = S.class_id', 'left');
        $this->db->join('schools AS SC', 'SC.id = S.school_id', 'left');
        
        $this->db->where('C.status', 1); 
        if($this->session->userdata('role_id') == TEACHER){

            $this->db->where('S.teacher_id', $this->session->userdata('profile_id'));

        }
        
        if($class_id > 0){
            $this->db->where('S.class_id', $class_id);
        }
        
        if($this->session->userdata('role_id') != SUPER_ADMIN){
            $this->db->where('S.school_id', $this->session->userdata('school_id'));
        }
        if($school_id && $this->session->userdata('role_id') == SUPER_ADMIN){
            $this->db->where('S.school_id', $school_id); 
        }        
        $this->db->where('SC.status', 1);
        $this->db->order_by('S.id', 'DESC');

        $this->db->join('enrollments AS E', 'E.school_id = S.school_id AND E.class_id = S.class_id', 'left');
      

        return $this->db->get()->result();
        
    }*/
    
    public function get_single_subject($id){
        
        $this->db->select('S.*, SC.school_name, C.name AS class_name, T.name AS teacher');
        $this->db->from('subjects AS S');
        $this->db->join('teachers AS T', 'T.id = S.teacher_id', 'left');
        $this->db->join('classes AS C', 'C.id = S.class_id', 'left');
        $this->db->join('schools AS SC', 'SC.id = S.school_id', 'left');
        $this->db->where('S.id', $id);
        return $this->db->get()->row();
        
    }
    
    function duplicate_check($school_id, $class_id, $name, $id = null ){   
        
        if($id){
            $this->db->where_not_in('id', $id);
        }
        $this->db->where('class_id', $class_id);
        $this->db->where('name', $name);
        $this->db->where('school_id', $school_id);
        return $this->db->get('subjects')->num_rows();        
    } 
    
    // public function get_student_count($class_id, $school_id){
    //     // print_r($school_id);die;
    //     $this->db->select('*');
    //     $this->db->from('classes');
    //     $this->db->where('school_id', $school_id);
    //     $this->db->where('id', $class_id);
    //     // $this->db->where('S.teacher_id', $teacher_id);
        
    //     $query = $this->db->get();
        
    //     // Print the result for debugging
    //     // echo "<pre>";
    //     $var = count($query->result());
    //     // print_r($var);die;
        
    //     return $query->row()->student_count;
    // } 


    public function get_chakra_list($school_id, $subject_id){
        $countS=0;
        $this->db->select('count(MC.id) as ChakraCount');
        $this->db->from('m_course_relation AS MC');
      //  $this->db->join('m_course_result AS MCR', 'MCR.school_id = MC.school_id AND MCR.subject_id = MC.subject_id', 'left');      
        $this->db->where('MC.school_id', $school_id);
        $this->db->where('MC.subject_id', $subject_id);
        
        $datsChackra= $this->db->get()->result();
        foreach ($datsChackra as $obj) {
            $this->db->select('count(MR.id) as ChakraResultCount');
            $this->db->from('m_course_result AS MR');
           //$this->db->join('m_course_result AS MCR', 'MCR.school_id = MR.school_id AND MCR.subject_id = MR.subject_id', 'left');
            $this->db->where('MR.school_id', $school_id);
            $this->db->where('MR.subject_id', $subject_id);
            $this->db->group_by('MR.student_id');
            $datsStudentChackra= $this->db->get()->result();
            foreach ($datsStudentChackra as $obj1) {
            if($obj->ChakraCount==$obj1->ChakraResultCount)
            {
                $countS= $countS+1;
            }
            // print_r($datsStudentChackra);
            // print_r("ll");

            // print_r($obj->ChakraCount);
            }
        }
        // print_r("kkkk".$countS);
        return $countS;

    }
    // public function list_chakra_by_sub($subject_id, $school_id){
       
    //      $this->db->select('m_course_relation.*');
    //     //  $this->db->select('m_course_relation.*,classes.id as class_id');
    //     $this->db->from('m_course_relation');
    //     //  $this->db->join('classes','classes.school_id=m_course_relation.school_id AND classes.grade_id= m_course_relation.grade_id','left');
    //     $this->db->where('subject_id', $subject_id);
    //     $this->db->where('school_id', $school_id);
        
    //     //   echo "<pre>";
    //     // print_r(  $this->db->get()->result());die;
    //     return $this->db->get()->result();
    // }
    //  public function list_chakra_by_sub($subject_id, $school_id) {
    //     $this->db->select('m_course_relation.*, classes.id as class_id, COUNT(e.student_id) AS total_students');
    //     $this->db->from('m_course_relation');
    //     $this->db->join('classes', 'classes.school_id = m_course_relation.school_id AND classes.grade_id = m_course_relation.grade_id', 'left');
    //     $this->db->join('enrollments AS e', 'e.school_id = m_course_relation.school_id AND e.class_id = classes.id', 'left');
    //     $this->db->where('m_course_relation.subject_id', $subject_id);
    //     $this->db->where('m_course_relation.school_id', $school_id);
    //     $this->db->group_by('m_course_relation.id'); 
    //     return $this->db->get()->result();
    // }
    public function list_chakra_by_sub($subject_id, $school_id) {
        $this->db->select('m_course_relation.*, classes.id as class_id, COUNT(e.student_id) AS total_students, COUNT(result.student_id) AS completed_chakras');
        $this->db->from('m_course_relation');
        $this->db->join('classes', 'classes.school_id = m_course_relation.school_id AND classes.grade_id = m_course_relation.grade_id', 'left');
        $this->db->join('enrollments AS e', 'e.school_id = m_course_relation.school_id AND e.class_id = classes.id', 'left');
        $this->db->join('m_course_result AS result', 'result.student_id = e.student_id AND result.chakra_id = m_course_relation.chakra_id', 'left');
        $this->db->where('m_course_relation.subject_id', $subject_id);
        $this->db->where('m_course_relation.school_id', $school_id);
        $this->db->group_by('m_course_relation.id'); 
    
        return $this->db->get()->result();
    }

    public function get_chakra($chakra_id, $school_id){
        $this->db->select('m_course_relation.*,classes.id as class_id,classes.name as class_name,m_unit.title as unit_name ,m_subject.title as subject_name');
        $this->db->from('m_course_relation');
        $this->db->join('classes','classes.school_id=m_course_relation.school_id AND classes.grade_id= m_course_relation.grade_id','left');
        $this->db->join('m_unit','m_unit.id= m_course_relation.unit_id','left');
        $this->db->join('m_subject','m_subject.id= m_course_relation.subject_id','left');

        $this->db->where('m_course_relation.chakra_id', $chakra_id);
        $this->db->where('m_course_relation.school_id', $school_id);
          return $this->db->get()->row();
    }
     public function get_student($data){
   
        $this->db->select(' students.*,m_course_result.id as result_id, m_course_result.time_finished as result_C_date,m_course_result.pt_score as result_get_number');
        $this->db->from('enrollments');
        $this->db->join('students','students.id=enrollments.student_id AND students.school_id= enrollments.school_id','left');
        $this->db->join('m_course_result','m_course_result.student_id = students.user_id AND m_course_result.chakra_id='.$data->chakra_id,'left');
        $this->db->where('enrollments.class_id', $data->class_id);
        $this->db->where('enrollments.school_id', $data->school_id);
      
      $this->db->group_by('enrollments.student_id');
      //  $this->db->where('m_course_result.user_id', $data->user_id);
        //   echo "<pre>";
        // print_r($this->db->get()->result());
        // die();
        return $this->db->get()->result();
    }

}
