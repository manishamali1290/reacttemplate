<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Auth_Model
 *
 * @author Nafeesa
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Auth_Model extends MY_Model {
    
    function __construct() {
        parent::__construct();
    }
    
    public function get_single_student($user_id) {
        $this->db->select('S.*, E.roll_no, E.class_id, E.section_id, U.role_id, C.name AS class_name, C.grade_id AS grade_id, SE.name AS section, CL.status AS class_status');
        $this->db->from('enrollments AS E');
        $this->db->join('students AS S', 'S.id = E.student_id', 'left');
        $this->db->join('users AS U', 'U.id = S.user_id', 'left');
        $this->db->join('classes AS C', 'C.id = E.class_id', 'left');
        $this->db->join('sections AS SE', 'SE.id = E.section_id', 'left');
        $this->db->join('classes AS CL', 'CL.id = E.class_id', 'left');
        $this->db->where('S.user_id', $user_id);
        return $this->db->get()->row();
    }
    public function get_single_tech($id){
        $this->db->select('course_id');
        $this->db->from('classes');
        $this->db->where('teacher_id', $id);
        $this->db->where('status',1);
        return $this->db->get()->result();
    }
}
