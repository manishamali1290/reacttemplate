(function ($)
  { "use strict"

  // Scroll Up
    $('#back-top a').on("click", function () {
      $('body,html').animate({
        scrollTop: 0
      }, 800);
      return false;
    });

    /* Custom Dragula JS */
    dragula([
      document.getElementById("complete"),
      document.getElementById("inprogress"),
      document.getElementById("todo")
    ]);
    removeOnSpill: false
      .on("drag", function(el) {
        el.className.replace("ex-moved", "");
      })
      .on("drop", function(el) {
        el.className += "ex-moved";
      })
      .on("over", function(el, container) {
        container.className += "ex-over";
      })
      .on("out", function(el, container) {
        container.className.replace("ex-over", "");
      });

})(jQuery);


