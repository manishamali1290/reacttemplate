<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Models\User;
use App\Models\Event;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Mail;
use View;
use Yajra\DataTables\DataTables;

class EventController extends Controller {

    public function index(Request $request) {
        if ($request->ajax()) {
            $data = Event::whereDate('start', '>=', $request->start)
                    ->whereDate('end', '<=', $request->end)
                    ->get(['id', 'title', 'start', 'end']);
            return response()->json($data);
        }

        return view('event.list');
    }
    public function fullCalender(Request $request) {
        if ($request->ajax()) {
            $data = Event::whereDate('start', '>=', $request->start)
                    ->whereDate('end', '<=', $request->end)
                    ->get(['id', 'title', 'start', 'end']);
            return response()->json($data);
        }

        return view('event.list');
    }

    public function ajax(Request $request) {

        switch ($request->type) {
            case 'add':
//                $event = Event::create([
//                            'title' => $request->title,
//                            'start' => $request->start,
//                            'end' => $request->end,
//                ]);
                $event_insert = new Event();
                $event_insert->title = $request->title ? $request->title : null;
                $event_insert->start = $request->start ? $request->start : null;
                $event_insert->end = $request->end ? $request->end : null;
                $event_insert->save();
                return response()->json($event_insert);
                break;

            case 'update':
                $event = Event::find($request->id)->update([
                    'title' => $request->title,
                    'start' => $request->start,
                    'end' => $request->end,
                ]);

                return response()->json($event);
                break;

            case 'delete':
                $event = Event::find($request->id)->delete();

                return response()->json($event);
                break;

            default:
                # code...
                break;
        }
    }

}
