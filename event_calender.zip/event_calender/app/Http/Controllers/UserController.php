<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Mail;
use DataTables;
use DB;
use App\Mail\ForgotPasswordEmail;

class UserController extends Controller {

    public function login() {
        $data = [];
        $data['title'] = 'Login';
        $data['menu_active_tab'] = 'login';
        return view('login')->with($data);
    }

}
