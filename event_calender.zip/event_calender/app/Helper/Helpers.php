<?php

function getStoragePath() {
//    return url('/') . '/public' . \Storage::url('');
    return url('/') . \Storage::url('');
    // return asset('storage/');
}
