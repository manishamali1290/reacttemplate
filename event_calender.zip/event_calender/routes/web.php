<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventController;

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider and all of them will
  | be assigned to the "web" middleware group. Make something great!
  |
 */

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', [EventController::class, 'index']);
Route::get('/full-calender', [EventController::class, 'fullCalender'])->name('full-calender');
Route::post('/full-calender-ajax', [EventController::class, 'ajax'])->name('full-calender-ajax');

