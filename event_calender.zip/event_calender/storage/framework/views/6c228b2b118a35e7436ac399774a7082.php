<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.bootstrap5.css">
<style>
/*    .dataTables_length {
        float: left;
        margin-bottom: 10px;
    }
    .dataTables_filter {
        float: right;
        margin-bottom: 10px;
    }*/
    /*
        .dataTables_paginate paging_simple_numbers {text-align: right;}
        .paginate_button current {

        }
       .paginate_button , .paginate_button next, .paginate_button current{

        background-color: rgba(124, 125, 182, 0.08);
        padding: 0.625rem 0.5125rem;
      min-width: calc( 2rem + 0px );
      font-size: 0.75rem;
      line-height: 1;
        }
        .paginate_button .current {

      background-color: #016EAF;
     border-color: #016EAF;
      color: #fff;
      box-shadow: 0 0.125rem 0.25rem rgba(105, 108, 255, 0.4);
        }*/
</style>
<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo (isset($title)) ? $title : ''; ?></h5>
            

            <table class="dt-multilingual table border-top" id="event_table" >
                <thead>
                    <tr>
                        <th width="10%">Sr. No</th>
                        <th width="20%">Name</th>
                        <th width="20%">venue</th>
                        <th width="10%">start date</th>
                        <th width="10%">end date</th>
                        <th width="10%">event date</th>
                        <th width="10%">Actions</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!--
<script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js"></script>
-->
<script src="<?php echo e(asset('admin/assets/vendor/libs/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
<script>
$(document).ready(function () {
    var table = $('#event_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('json-event')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: "name", name: 'name'},
            {data: "venue", name: 'venue'},
            {data: "start_date", name: 'start_date'},
            {data: "end_date", name: 'end_date'},
            {data: "event_date", name: 'event_date'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ],
        searching: true,
        paging: true,
        info: true,
        pageLength: 10,
        order: [[0, 'desc']]
    });

        $(document).on('click', '.btnDelete', function (e) {
            e.preventDefault();
            let id = $(this).attr('data-id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                customClass: {
                    confirmButton: 'btn btn-primary me-3',
                    cancelButton: 'btn btn-label-secondary'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                        url: admin_path + "/delete-event",
                        type: "POST",
                        data: {delete_id: id},
                        success: function (data) {
                            var data = jQuery.parseJSON(data);
                            var status = data.status;
                            var message = data.message;
                            if (status == false) {
                                // getToastMessage(message, 'error', 'Error');
                            } else {
                                // getToastMessage(message, 'success', 'Success');
                            }
                            table.draw();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: 'Record has been deleted.',
                                customClass: {confirmButton: 'btn btn-success'}
                            });
                        }
                    });
                }
            });
        });});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/event/list.blade.php ENDPATH**/ ?>