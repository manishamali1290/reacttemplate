<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <title> Login </title>
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Favicons -->
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.gstatic.com" rel="preconnect">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" />

        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/boxicons/css/boxicons.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/quill/quill.snow.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/quill/quill.bubble.css')); ?>" />

        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/remixicon/remixicon.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/simple-datatables/style.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/css/style.css')); ?>">
    </head>

    <body>

        <main>
            <div class="container">

                <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

                                <div class="d-flex justify-content-center py-4">
                                    <a href="index.html" class="logo d-flex align-items-center w-auto">
                                        <!--<img src="admin/assets/img/logo.png" alt="">-->
                                        <span class="d-none d-lg-block">India Achievement</span>
                                    </a>
                                </div><!-- End Logo -->

                                <div class="card mb-3">

                                    <div class="card-body">

                                        <div class="pt-4 pb-2">
                                            <h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
                                            <p class="text-center small">Enter your email & password to login</p>

                                            <?php if($message = Session::get('success')): ?>

                                            <div class="alert alert-success  alert-dismissible" role="alert">
                                                <?php echo e($message); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                            </div>
                                            <?php endif; ?>

                                            <?php if($message = Session::get('failed')): ?>
                                            <div class="alert alert-danger  alert-dismissible" role="alert">
                                                <?php echo e($message); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                            </div>
                                            <?php endif; ?>
                                        </div>

                                        <form class="row g-3 needs-validation" method="POST" action="<?php echo e(route('login-post')); ?>" novalidate>
                                            <?php echo e(csrf_field()); ?>

                                            <div class="col-12">
                                                <label for="email" class="form-label">Email</label>
                                                <div class="input-group has-validation">
                                                    <span class="input-group-text" id="inputGroupPrepend">@</span>
                                                    <input type="text" name="email" class="form-control" id="email" required>
                                                    <div class="invalid-feedback">Please enter your email.</div>
                                                    <?php if($errors->has('email')): ?>
                                                    <div class="error"><?php echo e($errors->first('email')); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <label for="yourPassword" class="form-label">Password</label>
                                                <input type="password" name="password" class="form-control" id="password" required>
                                                <div class="invalid-feedback">Please enter your password!</div>
                                                <?php if($errors->has('password')): ?>
                                                <div class="error"><?php echo e($errors->first('password')); ?></div>
                                                <?php endif; ?>
                                            </div>

                                            <div class="col-12">
                                                <!--                                                <div class="form-check">
                                                                                                    <input class="form-check-input" type="checkbox" name="remember" value="true" id="rememberMe">
                                                                                                    <label class="form-check-label" for="rememberMe">Remember me</label>
                                                                                                </div>-->
                                            </div>
                                            <div class="col-12">
                                                <button class="btn btn-primary w-100" type="submit">Login</button>
                                            </div>
                                            <div class="col-12">
                                                <!--<p class="small mb-0">Don't have account? <a href="#">Create an account</a></p>-->
                                            </div>
                                        </form>

                                    </div>
                                </div>

                                <div class="credits">
                                    Designed by <a href="#">Ingenious Systems</a>
                                </div>

                            </div>
                        </div>
                    </div>

                </section>

            </div>
        </main><!-- End #main -->

        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.min.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

    </body>

</html><?php /**PATH D:\xampp\htdocs\codesystem\eventcalendar\resources\views/login.blade.php ENDPATH**/ ?>