<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"></h5>

            <form id="form_add_event" method="POST" action="<?php echo e(route('update-event')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="event_id" id="event_id" value="<?php echo $event->id ?>" />
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Event Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $event->name)); ?>" />
                        <?php if($errors->has('name')): ?>
                        <div class="error"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Venue </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="venue" name="venue" value="<?php echo e(old('venue', $event->venue)); ?>" />
                        <?php if($errors->has('venue')): ?>
                        <div class="error"><?php echo e($errors->first('venue')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event Start Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e($event->start_date); ?>" />
                        <?php if($errors->has('start_date')): ?>
                        <div class="error"><?php echo e($errors->first('start_date')); ?></div>
                        <?php endif; ?>
                    </div>

                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event End Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo e($event->end_date); ?>" />
                        <?php if($errors->has('end_date')): ?>
                        <div class="error"><?php echo e($errors->first('end_date')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="event_date" name="event_date" value="<?php echo e($event->event_date); ?>" />
                        <?php if($errors->has('event_date')): ?>
                        <div class="error"><?php echo e($errors->first('event_date')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Image</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" id="image" name="image" />
                         <?php if($event->image_path !=null): ?>
                            <img src="<?php echo e(getStoragePath() . $event->image_path); ?>" alt="user-avatar" class="d-block rounded mt-2" height="100"  id="uploadedAvatar">
                            <!--<label class="col-sm-2 col-form-label text-light small fw-semibold mb-2" for="basic-default-title">-->
                            <!--    <a target="_blank" href="<?php echo e(getStoragePath() . $event->profile_image_path); ?>" title="Profile Image">Image</a>-->
                            <!--</label>-->
                            <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Description</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" id="description" name="description" rows="5"><?php echo e($event->description); ?></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Register Price</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="price" name="price" value="<?php echo e($event->price); ?>" />
                        <?php if($errors->has('price')): ?>
                        <div class="error"><?php echo e($errors->first('price')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form><!-- End Horizontal Form -->

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/event/edit.blade.php ENDPATH**/ ?>