<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
        <?php (!isset($title)) ? $title = '' : $title; ?>
        <title><?php echo e($title); ?> </title>
        <meta content="" name="description">
        <meta content="" name="keywords">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Favicon -->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/img/favicon/favicon.ico')); ?>" />

        <!-- Google Fonts -->
        <link href="https://fonts.gstatic.com" rel="preconnect" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/boxicons/css/boxicons.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/remixicon/remixicon.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/simple-datatables/style.css')); ?>">

        <!-- Template Main CSS File -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/css/style.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/vendor/libs/sweetalert2/sweetalert2.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('/admin/assets/css/admin_style.css')); ?>" />
    <body>
        <?php
        $role_id = null;
        if (Auth::check()) {
            $role_id = Auth::user()->role_id;
        }
        if (!isset($menu_active_tab)) {
            $menu_active_tab = '';
        }
        // Master
        $master_li_menu_active = '';
        $master_menu_list_arr = array(
            "event-list",
        );
        if (in_array($menu_active_tab, $master_menu_list_arr)) {
            $master_li_menu_active = "active open";
        } else {
            $master_li_menu_active = "";
        }
        ?>

        <!-- ======= Header ======= -->
        <header id="header" class="header fixed-top d-flex align-items-center">

            <div class="d-flex align-items-center justify-content-between">
                <a href="<?php echo e(URL::route('dashboard')); ?>" class="logo d-flex align-items-center">
                    <img src="admin/assets/img/logo.png" alt="">
                    <span class="d-none d-lg-block">LOGO</span>
                </a>
                <i class="bi bi-list toggle-sidebar-btn"></i>
            </div><!-- End Logo -->


            <nav class="header-nav ms-auto">
                <ul class="d-flex align-items-center">

                    <li class="nav-item d-block d-lg-none">
                        <a class="nav-link nav-icon search-bar-toggle" href="#">
                            <i class="bi bi-search"></i>
                        </a>
                    </li><!-- End Search Icon-->

                    <li class="nav-item dropdown pe-3">

                        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                            <?php if(Session::has('profile_image_path')): ?>
                            <img src="<?php echo e(getStoragePath() . Session::get('profile_image_path')); ?>" alt="Profile" class="rounded-circle">
                            <?php endif; ?>
                            <?php if(Session::has('first_name')): ?>
                            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(Session::get('first_name')); ?> <?php echo e(Session::get('last_name')); ?></span>
                            <?php endif; ?>
                        </a><!-- End Profile Iamge Icon -->

                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                            <li class="dropdown-header">
                                <?php if(Session::has('profile_image_path')): ?>
                                <img src="<?php echo e(getStoragePath() . Session::get('profile_image_path')); ?>" alt="Profile" class="rounded-circle profile-img ">
                                <?php endif; ?>
                                <?php if(Session::has('first_name')): ?>
                                <h6><?php echo e(Session::get('first_name')); ?> <?php echo e(Session::get('last_name')); ?></h6>
                                <?php endif; ?>
                                <span></span>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(URL::route('edit-user-profile')); ?>">
                                    <i class="bi bi-person"></i>
                                    <span>My Profile</span>
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <!--                            <li>
                                                            <a class="dropdown-item d-flex align-items-center" href="">
                                                                <i class="bi bi-gear"></i>
                                                                <span>Account Settings</span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <hr class="dropdown-divider">
                                                        </li>-->


                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>">
                                    <i class="bi bi-box-arrow-right"></i>
                                    <span>Sign Out</span>
                                </a>
                            </li>

                        </ul><!-- End Profile Dropdown Items -->
                    </li><!-- End Profile Nav -->

                </ul>
            </nav><!-- End Icons Navigation -->

        </header><!-- End Header -->

        <!-- ======= Sidebar ======= -->
        <aside id="sidebar" class="sidebar">

            <ul class="sidebar-nav" id="sidebar-nav">

                <li class="nav-item">
                    <a class="nav-link collapsed" href="<?php echo e(URL::route('dashboard')); ?>">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                </li><!-- End Dashboard Nav -->


                <li class="nav-item">
                    <a class="nav-link " data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
                        <i class="bi bi-journal-text"></i><span>Event</span><i class="bi bi-chevron-down ms-auto"></i>
                    </a>
                    <ul id="forms-nav" class="nav-content collapse show" data-bs-parent="#sidebar-nav">
                        <li>
                            <a href="<?php echo e(URL::route('event-list')); ?>">
                                <i class="bi bi-circle"></i><span>List</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(URL::route('add-event')); ?>">
                                <i class="bi bi-circle"></i><span>Add</span>
                            </a>
                        </li>
                    </ul>
                </li><!-- End Forms Nav -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(URL::route('register-user-list')); ?>">
                        <i class="bi bi-journal-text"></i><span>Register User</span>
                    </a>
                </li><!-- End Forms Nav -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(URL::route('register-user-list')); ?>">
                        <i class="bi bi-journal-text"></i><span>Event User</span>
                    </a>
                </li><!-- End Forms Nav -->
            </ul>

        </aside><!-- End Sidebar-->

        <main id="main" class="main">

            <div class="pagetitle">
                <!--<h1>Form Layouts</h1>-->
                <h1><?php echo (isset($title)) ? $title : ''; ?></h1>
                <!--                <nav>
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(URL::route('dashboard')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item">Forms</li>
                                        <li class="breadcrumb-item active">Layouts</li>
                                    </ol>
                                </nav>-->
            </div><!-- End Page Title -->
            <section class="section">
                <div class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </section>

        </main><!-- End #main -->

        <!-- ======= Footer ======= -->
        <!--        <footer id="footer" class="footer">
                    <div class="copyright">
                        &copy; Copyright <strong><span> Admin</span></strong>. All Rights Reserved
                    </div>
                    <div class="credits"></div>
                </footer>-->
        <!-- End Footer -->

        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
        <script>
            var admin_path = "<?php echo e(url('/admin')); ?>";
        </script>
        <!-- Vendor JS Files -->
        <script src="<?php echo e(asset('admin/assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/chart.js/chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/echarts/echarts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/php-email-form/validate.js')); ?>"></script>

        <!-- Template Main JS File -->
        <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>

        <script src="<?php echo e(asset('admin/assets/vendor/libs/sweetalert2/sweetalert2.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/libs/sweetalert2/sweetalert2.all.js')); ?>"></script>
    </body>

</html>
<?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>