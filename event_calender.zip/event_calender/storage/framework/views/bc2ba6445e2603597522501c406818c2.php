<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>
<!--<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo (isset($title)) ? $title : ''; ?></h5>
            
        </div>
    </div>

</div>-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>