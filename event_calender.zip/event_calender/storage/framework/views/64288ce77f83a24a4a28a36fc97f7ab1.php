<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"></h5>

            <form id="form_add_event" method="POST" action="<?php echo e(route('store-event')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>       <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Event Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="name" name="name">
                        <?php if($errors->has('name')): ?>
                        <div class="error"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Venue </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="venue" name="venue">
                        <?php if($errors->has('venue')): ?>
                        <div class="error"><?php echo e($errors->first('venue')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event Start Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="start_date" name="start_date" />
                        <?php if($errors->has('start_date')): ?>
                        <div class="error"><?php echo e($errors->first('start_date')); ?></div>
                        <?php endif; ?>
                    </div>

                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event End Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="end_date" name="end_date" />
                        <?php if($errors->has('end_date')): ?>
                        <div class="error"><?php echo e($errors->first('end_date')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Event Date</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" id="event_date" name="event_date" />
                        <?php if($errors->has('event_date')): ?>
                        <div class="error"><?php echo e($errors->first('event_date')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Image</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" id="image" name="image" />
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Description</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" id="description" name="description" rows="5"></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Register Price</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="price" name="price" />
                           <?php if($errors->has('price')): ?>
                        <div class="error"><?php echo e($errors->first('price')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                 
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form><!-- End Horizontal Form -->

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/event/add.blade.php ENDPATH**/ ?>