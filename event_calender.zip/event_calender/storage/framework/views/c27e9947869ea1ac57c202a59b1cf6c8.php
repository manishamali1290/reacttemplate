<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"></h5>
            <form id="update_user" method="POST"  action="<?php echo e(route('update-user-profile')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">First Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($user->first_name); ?>" />
                        <?php if($errors->has('first_name')): ?>
                        <div class="error"><?php echo e($errors->first('first_name')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Last name </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e($user->last_name); ?>" />
                        <?php if($errors->has('last_name')): ?>
                        <div class="error"><?php echo e($errors->first('last_name')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Email </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" />
                        <?php if($errors->has('email')): ?>
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Image</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" id="profile_image" name="profile_image" />
                        <?php if($user->profile_image_path !=null): ?>
                        <img src="<?php echo e(getStoragePath() . $user->profile_image_path); ?>" alt="user-avatar" class="d-block rounded mt-2" height="100" id="uploadedAvatar">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form><!-- End Horizontal Form -->

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\codesystem\eventregister\resources\views/admin/edit-user-profile.blade.php ENDPATH**/ ?>